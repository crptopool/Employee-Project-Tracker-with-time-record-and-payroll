<?php

use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\DependencyInjection\Exception\InactiveScopeException;
use Symfony\Component\DependencyInjection\Exception\InvalidArgumentException;
use Symfony\Component\DependencyInjection\Exception\LogicException;
use Symfony\Component\DependencyInjection\Exception\RuntimeException;
use Symfony\Component\DependencyInjection\ParameterBag\FrozenParameterBag;

/**
 * appDevDebugProjectContainer.
 *
 * This class has been auto-generated
 * by the Symfony Dependency Injection Component.
 */
class appDevDebugProjectContainer extends Container
{
    private $parameters;
    private $targetDirs = array();

    /**
     * Constructor.
     */
    public function __construct()
    {
        $dir = __DIR__;
        for ($i = 1; $i <= 4; ++$i) {
            $this->targetDirs[$i] = $dir = dirname($dir);
        }
        $this->parameters = $this->getDefaultParameters();

        $this->services =
        $this->scopedServices =
        $this->scopeStacks = array();
        $this->scopes = array('request' => 'container');
        $this->scopeChildren = array('request' => array());
        $this->methodMap = array(
            'admin.department' => 'getAdmin_DepartmentService',
            'admin.project' => 'getAdmin_ProjectService',
            'annotation_reader' => 'getAnnotationReaderService',
            'app.form.profile' => 'getApp_Form_ProfileService',
            'app.form.registration' => 'getApp_Form_RegistrationService',
            'assetic.asset_factory' => 'getAssetic_AssetFactoryService',
            'assetic.asset_manager' => 'getAssetic_AssetManagerService',
            'assetic.controller' => 'getAssetic_ControllerService',
            'assetic.filter.cssrewrite' => 'getAssetic_Filter_CssrewriteService',
            'assetic.filter_manager' => 'getAssetic_FilterManagerService',
            'assetic.request_listener' => 'getAssetic_RequestListenerService',
            'assets.context' => 'getAssets_ContextService',
            'assets.packages' => 'getAssets_PackagesService',
            'cache_clearer' => 'getCacheClearerService',
            'cache_warmer' => 'getCacheWarmerService',
            'controller_name_converter' => 'getControllerNameConverterService',
            'data_collector.dump' => 'getDataCollector_DumpService',
            'data_collector.form' => 'getDataCollector_FormService',
            'data_collector.form.extractor' => 'getDataCollector_Form_ExtractorService',
            'data_collector.request' => 'getDataCollector_RequestService',
            'data_collector.router' => 'getDataCollector_RouterService',
            'data_collector.translation' => 'getDataCollector_TranslationService',
            'debug.controller_resolver' => 'getDebug_ControllerResolverService',
            'debug.debug_handlers_listener' => 'getDebug_DebugHandlersListenerService',
            'debug.dump_listener' => 'getDebug_DumpListenerService',
            'debug.event_dispatcher' => 'getDebug_EventDispatcherService',
            'debug.stopwatch' => 'getDebug_StopwatchService',
            'doctrine' => 'getDoctrineService',
            'doctrine.dbal.connection_factory' => 'getDoctrine_Dbal_ConnectionFactoryService',
            'doctrine.dbal.default_connection' => 'getDoctrine_Dbal_DefaultConnectionService',
            'doctrine.dbal.logger.profiling.default' => 'getDoctrine_Dbal_Logger_Profiling_DefaultService',
            'doctrine.orm.default_entity_listener_resolver' => 'getDoctrine_Orm_DefaultEntityListenerResolverService',
            'doctrine.orm.default_entity_manager' => 'getDoctrine_Orm_DefaultEntityManagerService',
            'doctrine.orm.default_listeners.attach_entity_listeners' => 'getDoctrine_Orm_DefaultListeners_AttachEntityListenersService',
            'doctrine.orm.default_manager_configurator' => 'getDoctrine_Orm_DefaultManagerConfiguratorService',
            'doctrine.orm.validator.unique' => 'getDoctrine_Orm_Validator_UniqueService',
            'doctrine.orm.validator_initializer' => 'getDoctrine_Orm_ValidatorInitializerService',
            'doctrine_cache.providers.doctrine.orm.default_metadata_cache' => 'getDoctrineCache_Providers_Doctrine_Orm_DefaultMetadataCacheService',
            'doctrine_cache.providers.doctrine.orm.default_query_cache' => 'getDoctrineCache_Providers_Doctrine_Orm_DefaultQueryCacheService',
            'doctrine_cache.providers.doctrine.orm.default_result_cache' => 'getDoctrineCache_Providers_Doctrine_Orm_DefaultResultCacheService',
            'easyadmin.configurator' => 'getEasyadmin_ConfiguratorService',
            'easyadmin.form.type' => 'getEasyadmin_Form_TypeService',
            'easyadmin.form.type.extension' => 'getEasyadmin_Form_Type_ExtensionService',
            'easyadmin.listener.request_post_initialize' => 'getEasyadmin_Listener_RequestPostInitializeService',
            'easyadmin.paginator' => 'getEasyadmin_PaginatorService',
            'easyadmin.query_builder' => 'getEasyadmin_QueryBuilderService',
            'employee.alreadytimedin_extension' => 'getEmployee_AlreadytimedinExtensionService',
            'employee.currentidproject_extension' => 'getEmployee_CurrentidprojectExtensionService',
            'employee.projectname_extension' => 'getEmployee_ProjectnameExtensionService',
            'employee.projecttask_extension' => 'getEmployee_ProjecttaskExtensionService',
            'employee.twig.number_work_extension' => 'getEmployee_Twig_NumberWorkExtensionService',
            'file_locator' => 'getFileLocatorService',
            'filesystem' => 'getFilesystemService',
            'form.csrf_provider' => 'getForm_CsrfProviderService',
            'form.factory' => 'getForm_FactoryService',
            'form.registry' => 'getForm_RegistryService',
            'form.resolved_type_factory' => 'getForm_ResolvedTypeFactoryService',
            'form.type.birthday' => 'getForm_Type_BirthdayService',
            'form.type.button' => 'getForm_Type_ButtonService',
            'form.type.checkbox' => 'getForm_Type_CheckboxService',
            'form.type.choice' => 'getForm_Type_ChoiceService',
            'form.type.collection' => 'getForm_Type_CollectionService',
            'form.type.country' => 'getForm_Type_CountryService',
            'form.type.currency' => 'getForm_Type_CurrencyService',
            'form.type.date' => 'getForm_Type_DateService',
            'form.type.datetime' => 'getForm_Type_DatetimeService',
            'form.type.email' => 'getForm_Type_EmailService',
            'form.type.entity' => 'getForm_Type_EntityService',
            'form.type.file' => 'getForm_Type_FileService',
            'form.type.form' => 'getForm_Type_FormService',
            'form.type.hidden' => 'getForm_Type_HiddenService',
            'form.type.integer' => 'getForm_Type_IntegerService',
            'form.type.language' => 'getForm_Type_LanguageService',
            'form.type.locale' => 'getForm_Type_LocaleService',
            'form.type.money' => 'getForm_Type_MoneyService',
            'form.type.number' => 'getForm_Type_NumberService',
            'form.type.password' => 'getForm_Type_PasswordService',
            'form.type.percent' => 'getForm_Type_PercentService',
            'form.type.radio' => 'getForm_Type_RadioService',
            'form.type.repeated' => 'getForm_Type_RepeatedService',
            'form.type.reset' => 'getForm_Type_ResetService',
            'form.type.search' => 'getForm_Type_SearchService',
            'form.type.submit' => 'getForm_Type_SubmitService',
            'form.type.text' => 'getForm_Type_TextService',
            'form.type.textarea' => 'getForm_Type_TextareaService',
            'form.type.time' => 'getForm_Type_TimeService',
            'form.type.timezone' => 'getForm_Type_TimezoneService',
            'form.type.url' => 'getForm_Type_UrlService',
            'form.type_extension.csrf' => 'getForm_TypeExtension_CsrfService',
            'form.type_extension.form.data_collector' => 'getForm_TypeExtension_Form_DataCollectorService',
            'form.type_extension.form.http_foundation' => 'getForm_TypeExtension_Form_HttpFoundationService',
            'form.type_extension.form.validator' => 'getForm_TypeExtension_Form_ValidatorService',
            'form.type_extension.repeated.validator' => 'getForm_TypeExtension_Repeated_ValidatorService',
            'form.type_extension.submit.validator' => 'getForm_TypeExtension_Submit_ValidatorService',
            'form.type_guesser.doctrine' => 'getForm_TypeGuesser_DoctrineService',
            'form.type_guesser.validator' => 'getForm_TypeGuesser_ValidatorService',
            'fos_user.change_password.form.factory' => 'getFosUser_ChangePassword_Form_FactoryService',
            'fos_user.change_password.form.type' => 'getFosUser_ChangePassword_Form_TypeService',
            'fos_user.listener.authentication' => 'getFosUser_Listener_AuthenticationService',
            'fos_user.listener.flash' => 'getFosUser_Listener_FlashService',
            'fos_user.listener.resetting' => 'getFosUser_Listener_ResettingService',
            'fos_user.mailer' => 'getFosUser_MailerService',
            'fos_user.profile.form.factory' => 'getFosUser_Profile_Form_FactoryService',
            'fos_user.profile.form.type' => 'getFosUser_Profile_Form_TypeService',
            'fos_user.registration.form.factory' => 'getFosUser_Registration_Form_FactoryService',
            'fos_user.registration.form.type' => 'getFosUser_Registration_Form_TypeService',
            'fos_user.resetting.form.factory' => 'getFosUser_Resetting_Form_FactoryService',
            'fos_user.resetting.form.type' => 'getFosUser_Resetting_Form_TypeService',
            'fos_user.security.interactive_login_listener' => 'getFosUser_Security_InteractiveLoginListenerService',
            'fos_user.security.login_manager' => 'getFosUser_Security_LoginManagerService',
            'fos_user.user_manager' => 'getFosUser_UserManagerService',
            'fos_user.user_provider.username' => 'getFosUser_UserProvider_UsernameService',
            'fos_user.username_form_type' => 'getFosUser_UsernameFormTypeService',
            'fos_user.util.email_canonicalizer' => 'getFosUser_Util_EmailCanonicalizerService',
            'fos_user.util.token_generator' => 'getFosUser_Util_TokenGeneratorService',
            'fos_user.util.user_manipulator' => 'getFosUser_Util_UserManipulatorService',
            'fragment.handler' => 'getFragment_HandlerService',
            'fragment.listener' => 'getFragment_ListenerService',
            'fragment.renderer.esi' => 'getFragment_Renderer_EsiService',
            'fragment.renderer.hinclude' => 'getFragment_Renderer_HincludeService',
            'fragment.renderer.inline' => 'getFragment_Renderer_InlineService',
            'fragment.renderer.ssi' => 'getFragment_Renderer_SsiService',
            'http_kernel' => 'getHttpKernelService',
            'jms_serializer' => 'getJmsSerializerService',
            'jms_serializer.array_collection_handler' => 'getJmsSerializer_ArrayCollectionHandlerService',
            'jms_serializer.constraint_violation_handler' => 'getJmsSerializer_ConstraintViolationHandlerService',
            'jms_serializer.datetime_handler' => 'getJmsSerializer_DatetimeHandlerService',
            'jms_serializer.doctrine_proxy_subscriber' => 'getJmsSerializer_DoctrineProxySubscriberService',
            'jms_serializer.form_error_handler' => 'getJmsSerializer_FormErrorHandlerService',
            'jms_serializer.handler_registry' => 'getJmsSerializer_HandlerRegistryService',
            'jms_serializer.json_deserialization_visitor' => 'getJmsSerializer_JsonDeserializationVisitorService',
            'jms_serializer.json_serialization_visitor' => 'getJmsSerializer_JsonSerializationVisitorService',
            'jms_serializer.metadata_driver' => 'getJmsSerializer_MetadataDriverService',
            'jms_serializer.naming_strategy' => 'getJmsSerializer_NamingStrategyService',
            'jms_serializer.object_constructor' => 'getJmsSerializer_ObjectConstructorService',
            'jms_serializer.php_collection_handler' => 'getJmsSerializer_PhpCollectionHandlerService',
            'jms_serializer.stopwatch_subscriber' => 'getJmsSerializer_StopwatchSubscriberService',
            'jms_serializer.templating.helper.serializer' => 'getJmsSerializer_Templating_Helper_SerializerService',
            'jms_serializer.unserialize_object_constructor' => 'getJmsSerializer_UnserializeObjectConstructorService',
            'jms_serializer.xml_deserialization_visitor' => 'getJmsSerializer_XmlDeserializationVisitorService',
            'jms_serializer.xml_serialization_visitor' => 'getJmsSerializer_XmlSerializationVisitorService',
            'jms_serializer.yaml_serialization_visitor' => 'getJmsSerializer_YamlSerializationVisitorService',
            'kernel' => 'getKernelService',
            'knp_menu.factory' => 'getKnpMenu_FactoryService',
            'knp_menu.listener.voters' => 'getKnpMenu_Listener_VotersService',
            'knp_menu.matcher' => 'getKnpMenu_MatcherService',
            'knp_menu.menu_provider' => 'getKnpMenu_MenuProviderService',
            'knp_menu.renderer.list' => 'getKnpMenu_Renderer_ListService',
            'knp_menu.renderer.twig' => 'getKnpMenu_Renderer_TwigService',
            'knp_menu.renderer_provider' => 'getKnpMenu_RendererProviderService',
            'knp_menu.voter.router' => 'getKnpMenu_Voter_RouterService',
            'knp_paginator' => 'getKnpPaginatorService',
            'knp_paginator.helper.processor' => 'getKnpPaginator_Helper_ProcessorService',
            'knp_paginator.subscriber.filtration' => 'getKnpPaginator_Subscriber_FiltrationService',
            'knp_paginator.subscriber.paginate' => 'getKnpPaginator_Subscriber_PaginateService',
            'knp_paginator.subscriber.sliding_pagination' => 'getKnpPaginator_Subscriber_SlidingPaginationService',
            'knp_paginator.subscriber.sortable' => 'getKnpPaginator_Subscriber_SortableService',
            'knp_paginator.twig.extension.pagination' => 'getKnpPaginator_Twig_Extension_PaginationService',
            'locale_listener' => 'getLocaleListenerService',
            'logger' => 'getLoggerService',
            'monolog.handler.console' => 'getMonolog_Handler_ConsoleService',
            'monolog.handler.console_very_verbose' => 'getMonolog_Handler_ConsoleVeryVerboseService',
            'monolog.handler.debug' => 'getMonolog_Handler_DebugService',
            'monolog.handler.main' => 'getMonolog_Handler_MainService',
            'monolog.logger.assetic' => 'getMonolog_Logger_AsseticService',
            'monolog.logger.doctrine' => 'getMonolog_Logger_DoctrineService',
            'monolog.logger.event' => 'getMonolog_Logger_EventService',
            'monolog.logger.php' => 'getMonolog_Logger_PhpService',
            'monolog.logger.profiler' => 'getMonolog_Logger_ProfilerService',
            'monolog.logger.request' => 'getMonolog_Logger_RequestService',
            'monolog.logger.router' => 'getMonolog_Logger_RouterService',
            'monolog.logger.security' => 'getMonolog_Logger_SecurityService',
            'monolog.logger.templating' => 'getMonolog_Logger_TemplatingService',
            'monolog.logger.translation' => 'getMonolog_Logger_TranslationService',
            'profiler' => 'getProfilerService',
            'profiler_listener' => 'getProfilerListenerService',
            'property_accessor' => 'getPropertyAccessorService',
            'request' => 'getRequestService',
            'request_stack' => 'getRequestStackService',
            'response_listener' => 'getResponseListenerService',
            'router' => 'getRouterService',
            'router.request_context' => 'getRouter_RequestContextService',
            'router_listener' => 'getRouterListenerService',
            'routing.loader' => 'getRouting_LoaderService',
            'security.access.decision_manager' => 'getSecurity_Access_DecisionManagerService',
            'security.acl.dbal.schema' => 'getSecurity_Acl_Dbal_SchemaService',
            'security.acl.dbal.schema_listener' => 'getSecurity_Acl_Dbal_SchemaListenerService',
            'security.acl.provider' => 'getSecurity_Acl_ProviderService',
            'security.authentication.manager' => 'getSecurity_Authentication_ManagerService',
            'security.authentication.session_strategy' => 'getSecurity_Authentication_SessionStrategyService',
            'security.authentication.trust_resolver' => 'getSecurity_Authentication_TrustResolverService',
            'security.authentication_utils' => 'getSecurity_AuthenticationUtilsService',
            'security.authorization_checker' => 'getSecurity_AuthorizationCheckerService',
            'security.context' => 'getSecurity_ContextService',
            'security.csrf.token_manager' => 'getSecurity_Csrf_TokenManagerService',
            'security.encoder_factory' => 'getSecurity_EncoderFactoryService',
            'security.firewall' => 'getSecurity_FirewallService',
            'security.firewall.map.context.main' => 'getSecurity_Firewall_Map_Context_MainService',
            'security.logout_url_generator' => 'getSecurity_LogoutUrlGeneratorService',
            'security.password_encoder' => 'getSecurity_PasswordEncoderService',
            'security.rememberme.response_listener' => 'getSecurity_Rememberme_ResponseListenerService',
            'security.role_hierarchy' => 'getSecurity_RoleHierarchyService',
            'security.secure_random' => 'getSecurity_SecureRandomService',
            'security.token_storage' => 'getSecurity_TokenStorageService',
            'security.user_checker' => 'getSecurity_UserCheckerService',
            'security.validator.user_password' => 'getSecurity_Validator_UserPasswordService',
            'sensio_distribution.security_checker' => 'getSensioDistribution_SecurityCheckerService',
            'sensio_distribution.security_checker.command' => 'getSensioDistribution_SecurityChecker_CommandService',
            'sensio_distribution.webconfigurator' => 'getSensioDistribution_WebconfiguratorService',
            'sensio_framework_extra.cache.listener' => 'getSensioFrameworkExtra_Cache_ListenerService',
            'sensio_framework_extra.controller.listener' => 'getSensioFrameworkExtra_Controller_ListenerService',
            'sensio_framework_extra.converter.datetime' => 'getSensioFrameworkExtra_Converter_DatetimeService',
            'sensio_framework_extra.converter.doctrine.orm' => 'getSensioFrameworkExtra_Converter_Doctrine_OrmService',
            'sensio_framework_extra.converter.listener' => 'getSensioFrameworkExtra_Converter_ListenerService',
            'sensio_framework_extra.converter.manager' => 'getSensioFrameworkExtra_Converter_ManagerService',
            'sensio_framework_extra.security.listener' => 'getSensioFrameworkExtra_Security_ListenerService',
            'sensio_framework_extra.view.guesser' => 'getSensioFrameworkExtra_View_GuesserService',
            'sensio_framework_extra.view.listener' => 'getSensioFrameworkExtra_View_ListenerService',
            'service_container' => 'getServiceContainerService',
            'session' => 'getSessionService',
            'session.save_listener' => 'getSession_SaveListenerService',
            'session.storage.filesystem' => 'getSession_Storage_FilesystemService',
            'session.storage.metadata_bag' => 'getSession_Storage_MetadataBagService',
            'session.storage.native' => 'getSession_Storage_NativeService',
            'session.storage.php_bridge' => 'getSession_Storage_PhpBridgeService',
            'session_listener' => 'getSessionListenerService',
            'sonata.admin.audit.manager' => 'getSonata_Admin_Audit_ManagerService',
            'sonata.admin.block.admin_list' => 'getSonata_Admin_Block_AdminListService',
            'sonata.admin.block.search_result' => 'getSonata_Admin_Block_SearchResultService',
            'sonata.admin.builder.filter.factory' => 'getSonata_Admin_Builder_Filter_FactoryService',
            'sonata.admin.builder.orm_datagrid' => 'getSonata_Admin_Builder_OrmDatagridService',
            'sonata.admin.builder.orm_form' => 'getSonata_Admin_Builder_OrmFormService',
            'sonata.admin.builder.orm_list' => 'getSonata_Admin_Builder_OrmListService',
            'sonata.admin.builder.orm_show' => 'getSonata_Admin_Builder_OrmShowService',
            'sonata.admin.controller.admin' => 'getSonata_Admin_Controller_AdminService',
            'sonata.admin.event.extension' => 'getSonata_Admin_Event_ExtensionService',
            'sonata.admin.exporter' => 'getSonata_Admin_ExporterService',
            'sonata.admin.form.extension.field' => 'getSonata_Admin_Form_Extension_FieldService',
            'sonata.admin.form.extension.field.mopa' => 'getSonata_Admin_Form_Extension_Field_MopaService',
            'sonata.admin.form.filter.type.choice' => 'getSonata_Admin_Form_Filter_Type_ChoiceService',
            'sonata.admin.form.filter.type.date' => 'getSonata_Admin_Form_Filter_Type_DateService',
            'sonata.admin.form.filter.type.daterange' => 'getSonata_Admin_Form_Filter_Type_DaterangeService',
            'sonata.admin.form.filter.type.datetime' => 'getSonata_Admin_Form_Filter_Type_DatetimeService',
            'sonata.admin.form.filter.type.datetime_range' => 'getSonata_Admin_Form_Filter_Type_DatetimeRangeService',
            'sonata.admin.form.filter.type.default' => 'getSonata_Admin_Form_Filter_Type_DefaultService',
            'sonata.admin.form.filter.type.number' => 'getSonata_Admin_Form_Filter_Type_NumberService',
            'sonata.admin.form.type.admin' => 'getSonata_Admin_Form_Type_AdminService',
            'sonata.admin.form.type.collection' => 'getSonata_Admin_Form_Type_CollectionService',
            'sonata.admin.form.type.model_autocomplete' => 'getSonata_Admin_Form_Type_ModelAutocompleteService',
            'sonata.admin.form.type.model_choice' => 'getSonata_Admin_Form_Type_ModelChoiceService',
            'sonata.admin.form.type.model_hidden' => 'getSonata_Admin_Form_Type_ModelHiddenService',
            'sonata.admin.form.type.model_list' => 'getSonata_Admin_Form_Type_ModelListService',
            'sonata.admin.form.type.model_reference' => 'getSonata_Admin_Form_Type_ModelReferenceService',
            'sonata.admin.guesser.orm_datagrid' => 'getSonata_Admin_Guesser_OrmDatagridService',
            'sonata.admin.guesser.orm_datagrid_chain' => 'getSonata_Admin_Guesser_OrmDatagridChainService',
            'sonata.admin.guesser.orm_list' => 'getSonata_Admin_Guesser_OrmListService',
            'sonata.admin.guesser.orm_list_chain' => 'getSonata_Admin_Guesser_OrmListChainService',
            'sonata.admin.guesser.orm_show' => 'getSonata_Admin_Guesser_OrmShowService',
            'sonata.admin.guesser.orm_show_chain' => 'getSonata_Admin_Guesser_OrmShowChainService',
            'sonata.admin.helper' => 'getSonata_Admin_HelperService',
            'sonata.admin.label.strategy.bc' => 'getSonata_Admin_Label_Strategy_BcService',
            'sonata.admin.label.strategy.form_component' => 'getSonata_Admin_Label_Strategy_FormComponentService',
            'sonata.admin.label.strategy.native' => 'getSonata_Admin_Label_Strategy_NativeService',
            'sonata.admin.label.strategy.noop' => 'getSonata_Admin_Label_Strategy_NoopService',
            'sonata.admin.label.strategy.underscore' => 'getSonata_Admin_Label_Strategy_UnderscoreService',
            'sonata.admin.manager.orm' => 'getSonata_Admin_Manager_OrmService',
            'sonata.admin.manipulator.acl.admin' => 'getSonata_Admin_Manipulator_Acl_AdminService',
            'sonata.admin.manipulator.acl.object.orm' => 'getSonata_Admin_Manipulator_Acl_Object_OrmService',
            'sonata.admin.object.manipulator.acl.admin' => 'getSonata_Admin_Object_Manipulator_Acl_AdminService',
            'sonata.admin.orm.filter.type.boolean' => 'getSonata_Admin_Orm_Filter_Type_BooleanService',
            'sonata.admin.orm.filter.type.callback' => 'getSonata_Admin_Orm_Filter_Type_CallbackService',
            'sonata.admin.orm.filter.type.choice' => 'getSonata_Admin_Orm_Filter_Type_ChoiceService',
            'sonata.admin.orm.filter.type.class' => 'getSonata_Admin_Orm_Filter_Type_ClassService',
            'sonata.admin.orm.filter.type.date' => 'getSonata_Admin_Orm_Filter_Type_DateService',
            'sonata.admin.orm.filter.type.date_range' => 'getSonata_Admin_Orm_Filter_Type_DateRangeService',
            'sonata.admin.orm.filter.type.datetime' => 'getSonata_Admin_Orm_Filter_Type_DatetimeService',
            'sonata.admin.orm.filter.type.datetime_range' => 'getSonata_Admin_Orm_Filter_Type_DatetimeRangeService',
            'sonata.admin.orm.filter.type.model' => 'getSonata_Admin_Orm_Filter_Type_ModelService',
            'sonata.admin.orm.filter.type.number' => 'getSonata_Admin_Orm_Filter_Type_NumberService',
            'sonata.admin.orm.filter.type.string' => 'getSonata_Admin_Orm_Filter_Type_StringService',
            'sonata.admin.orm.filter.type.time' => 'getSonata_Admin_Orm_Filter_Type_TimeService',
            'sonata.admin.pool' => 'getSonata_Admin_PoolService',
            'sonata.admin.route.cache' => 'getSonata_Admin_Route_CacheService',
            'sonata.admin.route.cache_warmup' => 'getSonata_Admin_Route_CacheWarmupService',
            'sonata.admin.route.default_generator' => 'getSonata_Admin_Route_DefaultGeneratorService',
            'sonata.admin.route.path_info' => 'getSonata_Admin_Route_PathInfoService',
            'sonata.admin.route.query_string' => 'getSonata_Admin_Route_QueryStringService',
            'sonata.admin.route_loader' => 'getSonata_Admin_RouteLoaderService',
            'sonata.admin.search.handler' => 'getSonata_Admin_Search_HandlerService',
            'sonata.admin.security.handler' => 'getSonata_Admin_Security_HandlerService',
            'sonata.admin.twig.extension' => 'getSonata_Admin_Twig_ExtensionService',
            'sonata.admin.validator.inline' => 'getSonata_Admin_Validator_InlineService',
            'sonata.block.cache.handler.default' => 'getSonata_Block_Cache_Handler_DefaultService',
            'sonata.block.cache.handler.noop' => 'getSonata_Block_Cache_Handler_NoopService',
            'sonata.block.context_manager.default' => 'getSonata_Block_ContextManager_DefaultService',
            'sonata.block.exception.filter.debug_only' => 'getSonata_Block_Exception_Filter_DebugOnlyService',
            'sonata.block.exception.filter.ignore_block_exception' => 'getSonata_Block_Exception_Filter_IgnoreBlockExceptionService',
            'sonata.block.exception.filter.keep_all' => 'getSonata_Block_Exception_Filter_KeepAllService',
            'sonata.block.exception.filter.keep_none' => 'getSonata_Block_Exception_Filter_KeepNoneService',
            'sonata.block.exception.renderer.inline' => 'getSonata_Block_Exception_Renderer_InlineService',
            'sonata.block.exception.renderer.inline_debug' => 'getSonata_Block_Exception_Renderer_InlineDebugService',
            'sonata.block.exception.renderer.throw' => 'getSonata_Block_Exception_Renderer_ThrowService',
            'sonata.block.exception.strategy.manager' => 'getSonata_Block_Exception_Strategy_ManagerService',
            'sonata.block.form.type.block' => 'getSonata_Block_Form_Type_BlockService',
            'sonata.block.form.type.container_template' => 'getSonata_Block_Form_Type_ContainerTemplateService',
            'sonata.block.loader.chain' => 'getSonata_Block_Loader_ChainService',
            'sonata.block.loader.service' => 'getSonata_Block_Loader_ServiceService',
            'sonata.block.manager' => 'getSonata_Block_ManagerService',
            'sonata.block.renderer.default' => 'getSonata_Block_Renderer_DefaultService',
            'sonata.block.service.container' => 'getSonata_Block_Service_ContainerService',
            'sonata.block.service.empty' => 'getSonata_Block_Service_EmptyService',
            'sonata.block.service.menu' => 'getSonata_Block_Service_MenuService',
            'sonata.block.service.rss' => 'getSonata_Block_Service_RssService',
            'sonata.block.service.template' => 'getSonata_Block_Service_TemplateService',
            'sonata.block.service.text' => 'getSonata_Block_Service_TextService',
            'sonata.block.templating.helper' => 'getSonata_Block_Templating_HelperService',
            'sonata.block.twig.global' => 'getSonata_Block_Twig_GlobalService',
            'sonata.core.date.moment_format_converter' => 'getSonata_Core_Date_MomentFormatConverterService',
            'sonata.core.flashmessage.manager' => 'getSonata_Core_Flashmessage_ManagerService',
            'sonata.core.flashmessage.twig.extension' => 'getSonata_Core_Flashmessage_Twig_ExtensionService',
            'sonata.core.form.type.array' => 'getSonata_Core_Form_Type_ArrayService',
            'sonata.core.form.type.boolean' => 'getSonata_Core_Form_Type_BooleanService',
            'sonata.core.form.type.collection' => 'getSonata_Core_Form_Type_CollectionService',
            'sonata.core.form.type.color_selector' => 'getSonata_Core_Form_Type_ColorSelectorService',
            'sonata.core.form.type.date_picker' => 'getSonata_Core_Form_Type_DatePickerService',
            'sonata.core.form.type.date_range' => 'getSonata_Core_Form_Type_DateRangeService',
            'sonata.core.form.type.date_range_picker' => 'getSonata_Core_Form_Type_DateRangePickerService',
            'sonata.core.form.type.datetime_picker' => 'getSonata_Core_Form_Type_DatetimePickerService',
            'sonata.core.form.type.datetime_range' => 'getSonata_Core_Form_Type_DatetimeRangeService',
            'sonata.core.form.type.datetime_range_picker' => 'getSonata_Core_Form_Type_DatetimeRangePickerService',
            'sonata.core.form.type.equal' => 'getSonata_Core_Form_Type_EqualService',
            'sonata.core.form.type.translatable_choice' => 'getSonata_Core_Form_Type_TranslatableChoiceService',
            'sonata.core.model.adapter.chain' => 'getSonata_Core_Model_Adapter_ChainService',
            'sonata.core.slugify.cocur' => 'getSonata_Core_Slugify_CocurService',
            'sonata.core.slugify.native' => 'getSonata_Core_Slugify_NativeService',
            'sonata.core.twig.extension.text' => 'getSonata_Core_Twig_Extension_TextService',
            'sonata.core.twig.extension.wrapping' => 'getSonata_Core_Twig_Extension_WrappingService',
            'sonata.core.twig.status_extension' => 'getSonata_Core_Twig_StatusExtensionService',
            'sonata.core.twig.template_extension' => 'getSonata_Core_Twig_TemplateExtensionService',
            'sonata.core.validator.inline' => 'getSonata_Core_Validator_InlineService',
            'stof_doctrine_extensions.uploadable.manager' => 'getStofDoctrineExtensions_Uploadable_ManagerService',
            'streamed_response_listener' => 'getStreamedResponseListenerService',
            'swiftmailer.email_sender.listener' => 'getSwiftmailer_EmailSender_ListenerService',
            'swiftmailer.mailer.default' => 'getSwiftmailer_Mailer_DefaultService',
            'swiftmailer.mailer.default.plugin.messagelogger' => 'getSwiftmailer_Mailer_Default_Plugin_MessageloggerService',
            'swiftmailer.mailer.default.spool' => 'getSwiftmailer_Mailer_Default_SpoolService',
            'swiftmailer.mailer.default.transport' => 'getSwiftmailer_Mailer_Default_TransportService',
            'swiftmailer.mailer.default.transport.eventdispatcher' => 'getSwiftmailer_Mailer_Default_Transport_EventdispatcherService',
            'swiftmailer.mailer.default.transport.real' => 'getSwiftmailer_Mailer_Default_Transport_RealService',
            'templating' => 'getTemplatingService',
            'templating.filename_parser' => 'getTemplating_FilenameParserService',
            'templating.helper.assets' => 'getTemplating_Helper_AssetsService',
            'templating.helper.logout_url' => 'getTemplating_Helper_LogoutUrlService',
            'templating.helper.router' => 'getTemplating_Helper_RouterService',
            'templating.helper.security' => 'getTemplating_Helper_SecurityService',
            'templating.loader' => 'getTemplating_LoaderService',
            'templating.locator' => 'getTemplating_LocatorService',
            'templating.name_parser' => 'getTemplating_NameParserService',
            'translation.dumper.csv' => 'getTranslation_Dumper_CsvService',
            'translation.dumper.ini' => 'getTranslation_Dumper_IniService',
            'translation.dumper.json' => 'getTranslation_Dumper_JsonService',
            'translation.dumper.mo' => 'getTranslation_Dumper_MoService',
            'translation.dumper.php' => 'getTranslation_Dumper_PhpService',
            'translation.dumper.po' => 'getTranslation_Dumper_PoService',
            'translation.dumper.qt' => 'getTranslation_Dumper_QtService',
            'translation.dumper.res' => 'getTranslation_Dumper_ResService',
            'translation.dumper.xliff' => 'getTranslation_Dumper_XliffService',
            'translation.dumper.yml' => 'getTranslation_Dumper_YmlService',
            'translation.extractor' => 'getTranslation_ExtractorService',
            'translation.extractor.php' => 'getTranslation_Extractor_PhpService',
            'translation.loader' => 'getTranslation_LoaderService',
            'translation.loader.csv' => 'getTranslation_Loader_CsvService',
            'translation.loader.dat' => 'getTranslation_Loader_DatService',
            'translation.loader.ini' => 'getTranslation_Loader_IniService',
            'translation.loader.json' => 'getTranslation_Loader_JsonService',
            'translation.loader.mo' => 'getTranslation_Loader_MoService',
            'translation.loader.php' => 'getTranslation_Loader_PhpService',
            'translation.loader.po' => 'getTranslation_Loader_PoService',
            'translation.loader.qt' => 'getTranslation_Loader_QtService',
            'translation.loader.res' => 'getTranslation_Loader_ResService',
            'translation.loader.xliff' => 'getTranslation_Loader_XliffService',
            'translation.loader.yml' => 'getTranslation_Loader_YmlService',
            'translation.writer' => 'getTranslation_WriterService',
            'translator' => 'getTranslatorService',
            'translator.default' => 'getTranslator_DefaultService',
            'translator_listener' => 'getTranslatorListenerService',
            'twig' => 'getTwigService',
            'twig.controller.exception' => 'getTwig_Controller_ExceptionService',
            'twig.controller.preview_error' => 'getTwig_Controller_PreviewErrorService',
            'twig.exception_listener' => 'getTwig_ExceptionListenerService',
            'twig.loader' => 'getTwig_LoaderService',
            'twig.profile' => 'getTwig_ProfileService',
            'twig.translation.extractor' => 'getTwig_Translation_ExtractorService',
            'uri_signer' => 'getUriSignerService',
            'validator' => 'getValidatorService',
            'validator.builder' => 'getValidator_BuilderService',
            'validator.email' => 'getValidator_EmailService',
            'validator.expression' => 'getValidator_ExpressionService',
            'validator.validator_factory' => 'getValidator_ValidatorFactoryService',
            'var_dumper.cli_dumper' => 'getVarDumper_CliDumperService',
            'var_dumper.cloner' => 'getVarDumper_ClonerService',
            'web_profiler.controller.exception' => 'getWebProfiler_Controller_ExceptionService',
            'web_profiler.controller.profiler' => 'getWebProfiler_Controller_ProfilerService',
            'web_profiler.controller.router' => 'getWebProfiler_Controller_RouterService',
            'web_profiler.debug_toolbar' => 'getWebProfiler_DebugToolbarService',
        );
        $this->aliases = array(
            'console.command.sensiolabs_security_command_securitycheckercommand' => 'sensio_distribution.security_checker.command',
            'database_connection' => 'doctrine.dbal.default_connection',
            'doctrine.orm.default_metadata_cache' => 'doctrine_cache.providers.doctrine.orm.default_metadata_cache',
            'doctrine.orm.default_query_cache' => 'doctrine_cache.providers.doctrine.orm.default_query_cache',
            'doctrine.orm.default_result_cache' => 'doctrine_cache.providers.doctrine.orm.default_result_cache',
            'doctrine.orm.entity_manager' => 'doctrine.orm.default_entity_manager',
            'event_dispatcher' => 'debug.event_dispatcher',
            'fos_user.util.username_canonicalizer' => 'fos_user.util.email_canonicalizer',
            'mailer' => 'swiftmailer.mailer.default',
            'security.acl.dbal.connection' => 'doctrine.dbal.default_connection',
            'sensio.distribution.webconfigurator' => 'sensio_distribution.webconfigurator',
            'serializer' => 'jms_serializer',
            'session.storage' => 'session.storage.native',
            'sonata.block.cache.handler' => 'sonata.block.cache.handler.default',
            'sonata.block.context_manager' => 'sonata.block.context_manager.default',
            'sonata.block.renderer' => 'sonata.block.renderer.default',
            'swiftmailer.mailer' => 'swiftmailer.mailer.default',
            'swiftmailer.plugin.messagelogger' => 'swiftmailer.mailer.default.plugin.messagelogger',
            'swiftmailer.spool' => 'swiftmailer.mailer.default.spool',
            'swiftmailer.transport' => 'swiftmailer.mailer.default.transport',
            'swiftmailer.transport.real' => 'swiftmailer.mailer.default.transport.real',
        );
    }

    /**
     * {@inheritdoc}
     */
    public function compile()
    {
        throw new LogicException('You cannot compile a dumped frozen container.');
    }

    /**
     * Gets the 'admin.department' service.
     *
     * @return \EdgeWeb\Project\EmployeeBundle\Admin\DepartmentAdmin A EdgeWeb\Project\EmployeeBundle\Admin\DepartmentAdmin instance.
     */
    protected function getAdmin_DepartmentService()
    {
        $instance = new \EdgeWeb\Project\EmployeeBundle\Admin\DepartmentAdmin('admin.department', 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department', 'SonataAdminBundle:CRUD');

        $instance->setFormTheme(array(0 => 'SonataDoctrineORMAdminBundle:Form:form_admin_fields.html.twig'));
        $instance->setFilterTheme(array(0 => 'SonataDoctrineORMAdminBundle:Form:filter_admin_fields.html.twig'));
        $instance->setManagerType('orm');
        $instance->setModelManager($this->get('sonata.admin.manager.orm'));
        $instance->setFormContractor($this->get('sonata.admin.builder.orm_form'));
        $instance->setShowBuilder($this->get('sonata.admin.builder.orm_show'));
        $instance->setListBuilder($this->get('sonata.admin.builder.orm_list'));
        $instance->setDatagridBuilder($this->get('sonata.admin.builder.orm_datagrid'));
        $instance->setTranslator($this->get('translator'));
        $instance->setConfigurationPool($this->get('sonata.admin.pool'));
        $instance->setRouteGenerator($this->get('sonata.admin.route.default_generator'));
        $instance->setValidator($this->get('validator'));
        $instance->setSecurityHandler($this->get('sonata.admin.security.handler'));
        $instance->setMenuFactory($this->get('knp_menu.factory'));
        $instance->setRouteBuilder($this->get('sonata.admin.route.path_info'));
        $instance->setLabelTranslatorStrategy($this->get('sonata.admin.label.strategy.native'));
        $instance->setLabel('Department');
        $instance->setPersistFilters(false);
        $instance->setTemplates(array('user_block' => 'SonataAdminBundle:Core:user_block.html.twig', 'add_block' => 'SonataAdminBundle:Core:add_block.html.twig', 'layout' => 'SonataAdminBundle::standard_layout.html.twig', 'ajax' => 'SonataAdminBundle::ajax_layout.html.twig', 'dashboard' => 'SonataAdminBundle:Core:dashboard.html.twig', 'list' => 'SonataAdminBundle:CRUD:list.html.twig', 'filter' => 'SonataAdminBundle:Form:filter_admin_fields.html.twig', 'show' => 'SonataAdminBundle:CRUD:show.html.twig', 'show_compare' => 'SonataAdminBundle:CRUD:show_compare.html.twig', 'edit' => 'SonataAdminBundle:CRUD:edit.html.twig', 'history' => 'SonataAdminBundle:CRUD:history.html.twig', 'history_revision_timestamp' => 'SonataAdminBundle:CRUD:history_revision_timestamp.html.twig', 'acl' => 'SonataAdminBundle:CRUD:acl.html.twig', 'action' => 'SonataAdminBundle:CRUD:action.html.twig', 'short_object_description' => 'SonataAdminBundle:Helper:short-object-description.html.twig', 'preview' => 'SonataAdminBundle:CRUD:preview.html.twig', 'list_block' => 'SonataAdminBundle:Block:block_admin_list.html.twig', 'delete' => 'SonataAdminBundle:CRUD:delete.html.twig', 'batch' => 'SonataAdminBundle:CRUD:list__batch.html.twig', 'select' => 'SonataAdminBundle:CRUD:list__select.html.twig', 'batch_confirmation' => 'SonataAdminBundle:CRUD:batch_confirmation.html.twig', 'inner_list_row' => 'SonataAdminBundle:CRUD:list_inner_row.html.twig', 'base_list_field' => 'SonataAdminBundle:CRUD:base_list_field.html.twig', 'pager_links' => 'SonataAdminBundle:Pager:links.html.twig', 'pager_results' => 'SonataAdminBundle:Pager:results.html.twig', 'tab_menu_template' => 'SonataAdminBundle:Core:tab_menu_template.html.twig', 'search' => 'SonataAdminBundle:Core:search.html.twig', 'search_result_block' => 'SonataAdminBundle:Block:block_search_result.html.twig'));
        $instance->setSecurityInformation(array());
        $instance->initialize();
        $instance->addExtension($this->get('sonata.admin.event.extension'));

        return $instance;
    }

    /**
     * Gets the 'admin.project' service.
     *
     * @return \EdgeWeb\Project\EmployeeBundle\Admin\ProjectAdmin A EdgeWeb\Project\EmployeeBundle\Admin\ProjectAdmin instance.
     */
    protected function getAdmin_ProjectService()
    {
        $instance = new \EdgeWeb\Project\EmployeeBundle\Admin\ProjectAdmin('admin.project', 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Project', 'SonataAdminBundle:CRUD');

        $instance->setFormTheme(array(0 => 'SonataDoctrineORMAdminBundle:Form:form_admin_fields.html.twig'));
        $instance->setFilterTheme(array(0 => 'SonataDoctrineORMAdminBundle:Form:filter_admin_fields.html.twig'));
        $instance->setManagerType('orm');
        $instance->setModelManager($this->get('sonata.admin.manager.orm'));
        $instance->setFormContractor($this->get('sonata.admin.builder.orm_form'));
        $instance->setShowBuilder($this->get('sonata.admin.builder.orm_show'));
        $instance->setListBuilder($this->get('sonata.admin.builder.orm_list'));
        $instance->setDatagridBuilder($this->get('sonata.admin.builder.orm_datagrid'));
        $instance->setTranslator($this->get('translator'));
        $instance->setConfigurationPool($this->get('sonata.admin.pool'));
        $instance->setRouteGenerator($this->get('sonata.admin.route.default_generator'));
        $instance->setValidator($this->get('validator'));
        $instance->setSecurityHandler($this->get('sonata.admin.security.handler'));
        $instance->setMenuFactory($this->get('knp_menu.factory'));
        $instance->setRouteBuilder($this->get('sonata.admin.route.path_info'));
        $instance->setLabelTranslatorStrategy($this->get('sonata.admin.label.strategy.native'));
        $instance->setLabel('Project');
        $instance->setPersistFilters(false);
        $instance->setTemplates(array('user_block' => 'SonataAdminBundle:Core:user_block.html.twig', 'add_block' => 'SonataAdminBundle:Core:add_block.html.twig', 'layout' => 'SonataAdminBundle::standard_layout.html.twig', 'ajax' => 'SonataAdminBundle::ajax_layout.html.twig', 'dashboard' => 'SonataAdminBundle:Core:dashboard.html.twig', 'list' => 'SonataAdminBundle:CRUD:list.html.twig', 'filter' => 'SonataAdminBundle:Form:filter_admin_fields.html.twig', 'show' => 'SonataAdminBundle:CRUD:show.html.twig', 'show_compare' => 'SonataAdminBundle:CRUD:show_compare.html.twig', 'edit' => 'SonataAdminBundle:CRUD:edit.html.twig', 'history' => 'SonataAdminBundle:CRUD:history.html.twig', 'history_revision_timestamp' => 'SonataAdminBundle:CRUD:history_revision_timestamp.html.twig', 'acl' => 'SonataAdminBundle:CRUD:acl.html.twig', 'action' => 'SonataAdminBundle:CRUD:action.html.twig', 'short_object_description' => 'SonataAdminBundle:Helper:short-object-description.html.twig', 'preview' => 'SonataAdminBundle:CRUD:preview.html.twig', 'list_block' => 'SonataAdminBundle:Block:block_admin_list.html.twig', 'delete' => 'SonataAdminBundle:CRUD:delete.html.twig', 'batch' => 'SonataAdminBundle:CRUD:list__batch.html.twig', 'select' => 'SonataAdminBundle:CRUD:list__select.html.twig', 'batch_confirmation' => 'SonataAdminBundle:CRUD:batch_confirmation.html.twig', 'inner_list_row' => 'SonataAdminBundle:CRUD:list_inner_row.html.twig', 'base_list_field' => 'SonataAdminBundle:CRUD:base_list_field.html.twig', 'pager_links' => 'SonataAdminBundle:Pager:links.html.twig', 'pager_results' => 'SonataAdminBundle:Pager:results.html.twig', 'tab_menu_template' => 'SonataAdminBundle:Core:tab_menu_template.html.twig', 'search' => 'SonataAdminBundle:Core:search.html.twig', 'search_result_block' => 'SonataAdminBundle:Block:block_search_result.html.twig'));
        $instance->setSecurityInformation(array());
        $instance->initialize();
        $instance->addExtension($this->get('sonata.admin.event.extension'));

        return $instance;
    }

    /**
     * Gets the 'annotation_reader' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Doctrine\Common\Annotations\FileCacheReader A Doctrine\Common\Annotations\FileCacheReader instance.
     */
    protected function getAnnotationReaderService()
    {
        return $this->services['annotation_reader'] = new \Doctrine\Common\Annotations\FileCacheReader(new \Doctrine\Common\Annotations\AnnotationReader(), (__DIR__.'/annotations'), true);
    }

    /**
     * Gets the 'app.form.profile' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \EdgeWeb\Project\UserBundle\Form\ProfileFormType A EdgeWeb\Project\UserBundle\Form\ProfileFormType instance.
     */
    protected function getApp_Form_ProfileService()
    {
        return $this->services['app.form.profile'] = new \EdgeWeb\Project\UserBundle\Form\ProfileFormType();
    }

    /**
     * Gets the 'app.form.registration' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \EdgeWeb\Project\UserBundle\Form\RegistrationType A EdgeWeb\Project\UserBundle\Form\RegistrationType instance.
     */
    protected function getApp_Form_RegistrationService()
    {
        return $this->services['app.form.registration'] = new \EdgeWeb\Project\UserBundle\Form\RegistrationType();
    }

    /**
     * Gets the 'assetic.asset_manager' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Assetic\Factory\LazyAssetManager A Assetic\Factory\LazyAssetManager instance.
     */
    protected function getAssetic_AssetManagerService()
    {
        $this->services['assetic.asset_manager'] = $instance = new \Assetic\Factory\LazyAssetManager($this->get('assetic.asset_factory'), array('twig' => new \Assetic\Factory\Loader\CachedFormulaLoader(new \Assetic\Extension\Twig\TwigFormulaLoader($this->get('twig'), $this->get('monolog.logger.assetic', ContainerInterface::NULL_ON_INVALID_REFERENCE)), new \Assetic\Cache\ConfigCache((__DIR__.'/assetic/config')), true)));

        $instance->addResource(new \Symfony\Bundle\AsseticBundle\Factory\Resource\DirectoryResource($this->get('templating.loader'), '', ($this->targetDirs[2].'/Resources/views'), '/\\.[^.]+\\.twig$/'), 'twig');

        return $instance;
    }

    /**
     * Gets the 'assetic.controller' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\AsseticBundle\Controller\AsseticController A Symfony\Bundle\AsseticBundle\Controller\AsseticController instance.
     */
    protected function getAssetic_ControllerService()
    {
        return $this->services['assetic.controller'] = new \Symfony\Bundle\AsseticBundle\Controller\AsseticController($this->get('assetic.asset_manager'), new \Assetic\Cache\FilesystemCache((__DIR__.'/assetic/assets')), false, $this->get('profiler', ContainerInterface::NULL_ON_INVALID_REFERENCE));
    }

    /**
     * Gets the 'assetic.filter.cssrewrite' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Assetic\Filter\CssRewriteFilter A Assetic\Filter\CssRewriteFilter instance.
     */
    protected function getAssetic_Filter_CssrewriteService()
    {
        return $this->services['assetic.filter.cssrewrite'] = new \Assetic\Filter\CssRewriteFilter();
    }

    /**
     * Gets the 'assetic.filter_manager' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\AsseticBundle\FilterManager A Symfony\Bundle\AsseticBundle\FilterManager instance.
     */
    protected function getAssetic_FilterManagerService()
    {
        return $this->services['assetic.filter_manager'] = new \Symfony\Bundle\AsseticBundle\FilterManager($this, array('cssrewrite' => 'assetic.filter.cssrewrite'));
    }

    /**
     * Gets the 'assetic.request_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\AsseticBundle\EventListener\RequestListener A Symfony\Bundle\AsseticBundle\EventListener\RequestListener instance.
     */
    protected function getAssetic_RequestListenerService()
    {
        return $this->services['assetic.request_listener'] = new \Symfony\Bundle\AsseticBundle\EventListener\RequestListener();
    }

    /**
     * Gets the 'assets.context' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Asset\Context\RequestStackContext A Symfony\Component\Asset\Context\RequestStackContext instance.
     */
    protected function getAssets_ContextService()
    {
        return $this->services['assets.context'] = new \Symfony\Component\Asset\Context\RequestStackContext($this->get('request_stack'));
    }

    /**
     * Gets the 'assets.packages' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Asset\Packages A Symfony\Component\Asset\Packages instance.
     */
    protected function getAssets_PackagesService()
    {
        return $this->services['assets.packages'] = new \Symfony\Component\Asset\Packages(new \Symfony\Component\Asset\PathPackage('', new \Symfony\Component\Asset\VersionStrategy\EmptyVersionStrategy(), $this->get('assets.context')), array());
    }

    /**
     * Gets the 'cache_clearer' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\CacheClearer\ChainCacheClearer A Symfony\Component\HttpKernel\CacheClearer\ChainCacheClearer instance.
     */
    protected function getCacheClearerService()
    {
        return $this->services['cache_clearer'] = new \Symfony\Component\HttpKernel\CacheClearer\ChainCacheClearer(array());
    }

    /**
     * Gets the 'cache_warmer' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\CacheWarmer\CacheWarmerAggregate A Symfony\Component\HttpKernel\CacheWarmer\CacheWarmerAggregate instance.
     */
    protected function getCacheWarmerService()
    {
        $a = $this->get('kernel');
        $b = $this->get('templating.filename_parser');

        $c = new \Symfony\Bundle\FrameworkBundle\CacheWarmer\TemplateFinder($a, $b, ($this->targetDirs[2].'/Resources'));

        return $this->services['cache_warmer'] = new \Symfony\Component\HttpKernel\CacheWarmer\CacheWarmerAggregate(array(0 => new \Symfony\Bundle\FrameworkBundle\CacheWarmer\TemplatePathsCacheWarmer($c, $this->get('templating.locator')), 1 => new \Symfony\Bundle\AsseticBundle\CacheWarmer\AssetManagerCacheWarmer($this), 2 => new \Symfony\Bundle\FrameworkBundle\CacheWarmer\TranslationsCacheWarmer($this->get('translator.default')), 3 => new \Symfony\Bundle\FrameworkBundle\CacheWarmer\RouterCacheWarmer($this->get('router')), 4 => new \Symfony\Bundle\TwigBundle\CacheWarmer\TemplateCacheCacheWarmer($this, $c), 5 => new \Symfony\Bridge\Doctrine\CacheWarmer\ProxyCacheWarmer($this->get('doctrine')), 6 => $this->get('sonata.admin.route.cache_warmup')));
    }

    /**
     * Gets the 'data_collector.dump' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\DataCollector\DumpDataCollector A Symfony\Component\HttpKernel\DataCollector\DumpDataCollector instance.
     */
    protected function getDataCollector_DumpService()
    {
        return $this->services['data_collector.dump'] = new \Symfony\Component\HttpKernel\DataCollector\DumpDataCollector($this->get('debug.stopwatch', ContainerInterface::NULL_ON_INVALID_REFERENCE), NULL, 'UTF-8', $this->get('request_stack'), NULL);
    }

    /**
     * Gets the 'data_collector.form' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\DataCollector\FormDataCollector A Symfony\Component\Form\Extension\DataCollector\FormDataCollector instance.
     */
    protected function getDataCollector_FormService()
    {
        return $this->services['data_collector.form'] = new \Symfony\Component\Form\Extension\DataCollector\FormDataCollector($this->get('data_collector.form.extractor'));
    }

    /**
     * Gets the 'data_collector.form.extractor' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\DataCollector\FormDataExtractor A Symfony\Component\Form\Extension\DataCollector\FormDataExtractor instance.
     */
    protected function getDataCollector_Form_ExtractorService()
    {
        return $this->services['data_collector.form.extractor'] = new \Symfony\Component\Form\Extension\DataCollector\FormDataExtractor();
    }

    /**
     * Gets the 'data_collector.request' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\DataCollector\RequestDataCollector A Symfony\Component\HttpKernel\DataCollector\RequestDataCollector instance.
     */
    protected function getDataCollector_RequestService()
    {
        return $this->services['data_collector.request'] = new \Symfony\Component\HttpKernel\DataCollector\RequestDataCollector();
    }

    /**
     * Gets the 'data_collector.router' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\DataCollector\RouterDataCollector A Symfony\Bundle\FrameworkBundle\DataCollector\RouterDataCollector instance.
     */
    protected function getDataCollector_RouterService()
    {
        return $this->services['data_collector.router'] = new \Symfony\Bundle\FrameworkBundle\DataCollector\RouterDataCollector();
    }

    /**
     * Gets the 'data_collector.translation' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\DataCollector\TranslationDataCollector A Symfony\Component\Translation\DataCollector\TranslationDataCollector instance.
     */
    protected function getDataCollector_TranslationService()
    {
        return $this->services['data_collector.translation'] = new \Symfony\Component\Translation\DataCollector\TranslationDataCollector($this->get('translator'));
    }

    /**
     * Gets the 'debug.controller_resolver' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\Controller\TraceableControllerResolver A Symfony\Component\HttpKernel\Controller\TraceableControllerResolver instance.
     */
    protected function getDebug_ControllerResolverService()
    {
        return $this->services['debug.controller_resolver'] = new \Symfony\Component\HttpKernel\Controller\TraceableControllerResolver(new \Symfony\Bundle\FrameworkBundle\Controller\ControllerResolver($this, $this->get('controller_name_converter'), $this->get('monolog.logger.request', ContainerInterface::NULL_ON_INVALID_REFERENCE)), $this->get('debug.stopwatch'));
    }

    /**
     * Gets the 'debug.debug_handlers_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\DebugHandlersListener A Symfony\Component\HttpKernel\EventListener\DebugHandlersListener instance.
     */
    protected function getDebug_DebugHandlersListenerService()
    {
        return $this->services['debug.debug_handlers_listener'] = new \Symfony\Component\HttpKernel\EventListener\DebugHandlersListener(NULL, $this->get('monolog.logger.php', ContainerInterface::NULL_ON_INVALID_REFERENCE), -4182, NULL, true, NULL);
    }

    /**
     * Gets the 'debug.dump_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\DumpListener A Symfony\Component\HttpKernel\EventListener\DumpListener instance.
     */
    protected function getDebug_DumpListenerService()
    {
        return $this->services['debug.dump_listener'] = new \Symfony\Component\HttpKernel\EventListener\DumpListener($this->get('var_dumper.cloner'), $this->get('data_collector.dump'));
    }

    /**
     * Gets the 'debug.event_dispatcher' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\Debug\TraceableEventDispatcher A Symfony\Component\HttpKernel\Debug\TraceableEventDispatcher instance.
     */
    protected function getDebug_EventDispatcherService()
    {
        $this->services['debug.event_dispatcher'] = $instance = new \Symfony\Component\HttpKernel\Debug\TraceableEventDispatcher(new \Symfony\Component\EventDispatcher\ContainerAwareEventDispatcher($this), $this->get('debug.stopwatch'), $this->get('monolog.logger.event', ContainerInterface::NULL_ON_INVALID_REFERENCE));

        $instance->addListenerService('kernel.controller', array(0 => 'data_collector.router', 1 => 'onKernelController'), 0);
        $instance->addListenerService('kernel.request', array(0 => 'assetic.request_listener', 1 => 'onKernelRequest'), 0);
        $instance->addListenerService('easy_admin.post_initialize', array(0 => 'easyadmin.listener.request_post_initialize', 1 => 'initializeRequest'), 0);
        $instance->addListenerService('kernel.response', array(0 => 'sonata.block.cache.handler.default', 1 => 'onKernelResponse'), 0);
        $instance->addListenerService('kernel.request', array(0 => 'knp_menu.listener.voters', 1 => 'onKernelRequest'), 0);
        $instance->addListenerService('kernel.request', array(0 => 'knp_paginator.subscriber.sliding_pagination', 1 => 'onKernelRequest'), 0);
        $instance->addSubscriberService('response_listener', 'Symfony\\Component\\HttpKernel\\EventListener\\ResponseListener');
        $instance->addSubscriberService('streamed_response_listener', 'Symfony\\Component\\HttpKernel\\EventListener\\StreamedResponseListener');
        $instance->addSubscriberService('locale_listener', 'Symfony\\Component\\HttpKernel\\EventListener\\LocaleListener');
        $instance->addSubscriberService('translator_listener', 'Symfony\\Component\\HttpKernel\\EventListener\\TranslatorListener');
        $instance->addSubscriberService('session_listener', 'Symfony\\Bundle\\FrameworkBundle\\EventListener\\SessionListener');
        $instance->addSubscriberService('session.save_listener', 'Symfony\\Component\\HttpKernel\\EventListener\\SaveSessionListener');
        $instance->addSubscriberService('fragment.listener', 'Symfony\\Component\\HttpKernel\\EventListener\\FragmentListener');
        $instance->addSubscriberService('profiler_listener', 'Symfony\\Component\\HttpKernel\\EventListener\\ProfilerListener');
        $instance->addSubscriberService('data_collector.request', 'Symfony\\Component\\HttpKernel\\DataCollector\\RequestDataCollector');
        $instance->addSubscriberService('router_listener', 'Symfony\\Component\\HttpKernel\\EventListener\\RouterListener');
        $instance->addSubscriberService('debug.debug_handlers_listener', 'Symfony\\Component\\HttpKernel\\EventListener\\DebugHandlersListener');
        $instance->addSubscriberService('security.firewall', 'Symfony\\Component\\Security\\Http\\Firewall');
        $instance->addSubscriberService('security.rememberme.response_listener', 'Symfony\\Component\\Security\\Http\\RememberMe\\ResponseListener');
        $instance->addSubscriberService('twig.exception_listener', 'Symfony\\Component\\HttpKernel\\EventListener\\ExceptionListener');
        $instance->addSubscriberService('monolog.handler.console', 'Symfony\\Bridge\\Monolog\\Handler\\ConsoleHandler');
        $instance->addSubscriberService('monolog.handler.console_very_verbose', 'Symfony\\Bridge\\Monolog\\Handler\\ConsoleHandler');
        $instance->addSubscriberService('swiftmailer.email_sender.listener', 'Symfony\\Bundle\\SwiftmailerBundle\\EventListener\\EmailSenderListener');
        $instance->addSubscriberService('sensio_framework_extra.controller.listener', 'Sensio\\Bundle\\FrameworkExtraBundle\\EventListener\\ControllerListener');
        $instance->addSubscriberService('sensio_framework_extra.converter.listener', 'Sensio\\Bundle\\FrameworkExtraBundle\\EventListener\\ParamConverterListener');
        $instance->addSubscriberService('sensio_framework_extra.view.listener', 'Sensio\\Bundle\\FrameworkExtraBundle\\EventListener\\TemplateListener');
        $instance->addSubscriberService('sensio_framework_extra.cache.listener', 'Sensio\\Bundle\\FrameworkExtraBundle\\EventListener\\HttpCacheListener');
        $instance->addSubscriberService('sensio_framework_extra.security.listener', 'Sensio\\Bundle\\FrameworkExtraBundle\\EventListener\\SecurityListener');
        $instance->addSubscriberService('fos_user.security.interactive_login_listener', 'FOS\\UserBundle\\EventListener\\LastLoginListener');
        $instance->addSubscriberService('fos_user.listener.authentication', 'FOS\\UserBundle\\EventListener\\AuthenticationListener');
        $instance->addSubscriberService('fos_user.listener.flash', 'FOS\\UserBundle\\EventListener\\FlashListener');
        $instance->addSubscriberService('fos_user.listener.resetting', 'FOS\\UserBundle\\EventListener\\ResettingListener');
        $instance->addSubscriberService('debug.dump_listener', 'Symfony\\Component\\HttpKernel\\EventListener\\DumpListener');
        $instance->addSubscriberService('web_profiler.debug_toolbar', 'Symfony\\Bundle\\WebProfilerBundle\\EventListener\\WebDebugToolbarListener');
        $instance->addListenerService('knp_pager.before', array(0 => 'knp_paginator.subscriber.paginate', 1 => 'before'), 0);
        $instance->addListenerService('knp_pager.pagination', array(0 => 'knp_paginator.subscriber.paginate', 1 => 'pagination'), 0);
        $instance->addListenerService('knp_pager.before', array(0 => 'knp_paginator.subscriber.sortable', 1 => 'before'), 1);
        $instance->addListenerService('knp_pager.before', array(0 => 'knp_paginator.subscriber.filtration', 1 => 'before'), 1);
        $instance->addListenerService('knp_pager.pagination', array(0 => 'knp_paginator.subscriber.sliding_pagination', 1 => 'pagination'), 1);

        return $instance;
    }

    /**
     * Gets the 'debug.stopwatch' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Stopwatch\Stopwatch A Symfony\Component\Stopwatch\Stopwatch instance.
     */
    protected function getDebug_StopwatchService()
    {
        return $this->services['debug.stopwatch'] = new \Symfony\Component\Stopwatch\Stopwatch();
    }

    /**
     * Gets the 'doctrine' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Registry A Doctrine\Bundle\DoctrineBundle\Registry instance.
     */
    protected function getDoctrineService()
    {
        return $this->services['doctrine'] = new \Doctrine\Bundle\DoctrineBundle\Registry($this, array('default' => 'doctrine.dbal.default_connection'), array('default' => 'doctrine.orm.default_entity_manager'), 'default', 'default');
    }

    /**
     * Gets the 'doctrine.dbal.connection_factory' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\ConnectionFactory A Doctrine\Bundle\DoctrineBundle\ConnectionFactory instance.
     */
    protected function getDoctrine_Dbal_ConnectionFactoryService()
    {
        return $this->services['doctrine.dbal.connection_factory'] = new \Doctrine\Bundle\DoctrineBundle\ConnectionFactory(array());
    }

    /**
     * Gets the 'doctrine.dbal.default_connection' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Doctrine\DBAL\Connection A Doctrine\DBAL\Connection instance.
     */
    protected function getDoctrine_Dbal_DefaultConnectionService()
    {
        $a = new \Doctrine\DBAL\Logging\LoggerChain();
        $a->addLogger(new \Symfony\Bridge\Doctrine\Logger\DbalLogger($this->get('monolog.logger.doctrine', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('debug.stopwatch', ContainerInterface::NULL_ON_INVALID_REFERENCE)));
        $a->addLogger($this->get('doctrine.dbal.logger.profiling.default'));

        $b = new \Doctrine\DBAL\Configuration();
        $b->setSQLLogger($a);

        $c = new \Knp\DoctrineBehaviors\Reflection\ClassAnalyzer();

        $d = new \Symfony\Bridge\Doctrine\ContainerAwareEventManager($this);
        $d->addEventSubscriber(new \Knp\DoctrineBehaviors\ORM\Blameable\BlameableSubscriber($c, true, 'Knp\\DoctrineBehaviors\\Model\\Blameable\\Blameable', new \Knp\DoctrineBehaviors\ORM\Blameable\UserCallable($this), NULL));
        $d->addEventSubscriber(new \FOS\UserBundle\Doctrine\UserListener($this));
        $d->addEventSubscriber(new \Knp\DoctrineBehaviors\ORM\Translatable\TranslatableSubscriber($c, true, new \Knp\DoctrineBehaviors\ORM\Translatable\CurrentLocaleCallable($this), new \Knp\DoctrineBehaviors\ORM\Translatable\DefaultLocaleCallable('en'), 'Knp\\DoctrineBehaviors\\Model\\Translatable\\Translatable', 'Knp\\DoctrineBehaviors\\Model\\Translatable\\Translation', 'LAZY', 'LAZY'));
        $d->addEventSubscriber(new \Knp\DoctrineBehaviors\ORM\Geocodable\GeocodableSubscriber($c, true, 'Knp\\DoctrineBehaviors\\Model\\Geocodable\\Geocodable', NULL));
        $d->addEventSubscriber(new \Knp\DoctrineBehaviors\ORM\SoftDeletable\SoftDeletableSubscriber($c, true, 'Knp\\DoctrineBehaviors\\Model\\SoftDeletable\\SoftDeletable'));
        $d->addEventSubscriber(new \Knp\DoctrineBehaviors\ORM\Sortable\SortableSubscriber($c, true, 'Knp\\DoctrineBehaviors\\Model\\Sortable\\Sortable'));
        $d->addEventSubscriber(new \Knp\DoctrineBehaviors\ORM\Timestampable\TimestampableSubscriber($c, true, 'Knp\\DoctrineBehaviors\\Model\\Timestampable\\Timestampable', 'datetime'));
        $d->addEventSubscriber(new \Knp\DoctrineBehaviors\ORM\Loggable\LoggableSubscriber($c, true, new \Knp\DoctrineBehaviors\ORM\Loggable\LoggerCallable($this->get('logger'))));
        $d->addEventSubscriber(new \Knp\DoctrineBehaviors\ORM\Tree\TreeSubscriber($c, true, 'Knp\\DoctrineBehaviors\\Model\\Tree\\Node'));
        $d->addEventSubscriber(new \Knp\DoctrineBehaviors\ORM\Sluggable\SluggableSubscriber($c, true, 'Knp\\DoctrineBehaviors\\Model\\Sluggable\\Sluggable'));
        $d->addEventListener(array(0 => 'postGenerateSchema'), 'security.acl.dbal.schema_listener');
        $d->addEventListener(array(0 => 'loadClassMetadata'), $this->get('doctrine.orm.default_listeners.attach_entity_listeners'));

        return $this->services['doctrine.dbal.default_connection'] = $this->get('doctrine.dbal.connection_factory')->createConnection(array('driver' => 'pdo_mysql', 'host' => '127.0.0.1', 'port' => NULL, 'dbname' => 'edge', 'user' => 'root', 'password' => NULL, 'charset' => 'UTF8', 'driverOptions' => array(), 'defaultTableOptions' => array()), $b, $d, array());
    }

    /**
     * Gets the 'doctrine.orm.default_entity_listener_resolver' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Doctrine\ORM\Mapping\DefaultEntityListenerResolver A Doctrine\ORM\Mapping\DefaultEntityListenerResolver instance.
     */
    protected function getDoctrine_Orm_DefaultEntityListenerResolverService()
    {
        return $this->services['doctrine.orm.default_entity_listener_resolver'] = new \Doctrine\ORM\Mapping\DefaultEntityListenerResolver();
    }

    /**
     * Gets the 'doctrine.orm.default_entity_manager' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Doctrine\ORM\EntityManager A Doctrine\ORM\EntityManager instance.
     */
    protected function getDoctrine_Orm_DefaultEntityManagerService()
    {
        $a = new \Doctrine\ORM\Mapping\Driver\SimplifiedYamlDriver(array(($this->targetDirs[3].'\\src\\EdgeWeb\\Project\\EmployeeBundle\\Resources\\config\\doctrine') => 'EdgeWeb\\Project\\EmployeeBundle\\Entity', ($this->targetDirs[3].'\\src\\EdgeWeb\\Project\\UserBundle\\Resources\\config\\doctrine') => 'EdgeWeb\\Project\\UserBundle\\Entity', ($this->targetDirs[3].'\\src\\EdgeWeb\\Project\\PaycomBundle\\Resources\\config\\doctrine') => 'EdgeWeb\\Project\\PaycomBundle\\Entity'));
        $a->setGlobalBasename('mapping');

        $b = new \Doctrine\Common\Persistence\Mapping\Driver\MappingDriverChain();
        $b->addDriver($a, 'EdgeWeb\\Project\\EmployeeBundle\\Entity');
        $b->addDriver($a, 'EdgeWeb\\Project\\UserBundle\\Entity');
        $b->addDriver($a, 'EdgeWeb\\Project\\PaycomBundle\\Entity');
        $b->addDriver(new \Doctrine\ORM\Mapping\Driver\XmlDriver(new \Doctrine\Common\Persistence\Mapping\Driver\SymfonyFileLocator(array(($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle\\Resources\\config\\doctrine-mapping') => 'FOS\\UserBundle\\Model'), '.orm.xml')), 'FOS\\UserBundle\\Model');

        $c = new \Doctrine\ORM\Configuration();
        $c->setEntityNamespaces(array('EmployeeBundle' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity', 'UserBundle' => 'EdgeWeb\\Project\\UserBundle\\Entity', 'PaycomBundle' => 'EdgeWeb\\Project\\PaycomBundle\\Entity'));
        $c->setMetadataCacheImpl($this->get('doctrine_cache.providers.doctrine.orm.default_metadata_cache'));
        $c->setQueryCacheImpl($this->get('doctrine_cache.providers.doctrine.orm.default_query_cache'));
        $c->setResultCacheImpl($this->get('doctrine_cache.providers.doctrine.orm.default_result_cache'));
        $c->setMetadataDriverImpl($b);
        $c->setProxyDir((__DIR__.'/doctrine/orm/Proxies'));
        $c->setProxyNamespace('Proxies');
        $c->setAutoGenerateProxyClasses(true);
        $c->setClassMetadataFactoryName('Doctrine\\ORM\\Mapping\\ClassMetadataFactory');
        $c->setDefaultRepositoryClassName('Doctrine\\ORM\\EntityRepository');
        $c->setNamingStrategy(new \Doctrine\ORM\Mapping\UnderscoreNamingStrategy());
        $c->setQuoteStrategy(new \Doctrine\ORM\Mapping\DefaultQuoteStrategy());
        $c->setEntityListenerResolver($this->get('doctrine.orm.default_entity_listener_resolver'));

        $this->services['doctrine.orm.default_entity_manager'] = $instance = \Doctrine\ORM\EntityManager::create($this->get('doctrine.dbal.default_connection'), $c);

        $this->get('doctrine.orm.default_manager_configurator')->configure($instance);

        return $instance;
    }

    /**
     * Gets the 'doctrine.orm.default_listeners.attach_entity_listeners' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Doctrine\ORM\Tools\AttachEntityListenersListener A Doctrine\ORM\Tools\AttachEntityListenersListener instance.
     */
    protected function getDoctrine_Orm_DefaultListeners_AttachEntityListenersService()
    {
        return $this->services['doctrine.orm.default_listeners.attach_entity_listeners'] = new \Doctrine\ORM\Tools\AttachEntityListenersListener();
    }

    /**
     * Gets the 'doctrine.orm.default_manager_configurator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\ManagerConfigurator A Doctrine\Bundle\DoctrineBundle\ManagerConfigurator instance.
     */
    protected function getDoctrine_Orm_DefaultManagerConfiguratorService()
    {
        return $this->services['doctrine.orm.default_manager_configurator'] = new \Doctrine\Bundle\DoctrineBundle\ManagerConfigurator(array(), array());
    }

    /**
     * Gets the 'doctrine.orm.validator.unique' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntityValidator A Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntityValidator instance.
     */
    protected function getDoctrine_Orm_Validator_UniqueService()
    {
        return $this->services['doctrine.orm.validator.unique'] = new \Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntityValidator($this->get('doctrine'));
    }

    /**
     * Gets the 'doctrine.orm.validator_initializer' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Doctrine\Validator\DoctrineInitializer A Symfony\Bridge\Doctrine\Validator\DoctrineInitializer instance.
     */
    protected function getDoctrine_Orm_ValidatorInitializerService()
    {
        return $this->services['doctrine.orm.validator_initializer'] = new \Symfony\Bridge\Doctrine\Validator\DoctrineInitializer($this->get('doctrine'));
    }

    /**
     * Gets the 'doctrine_cache.providers.doctrine.orm.default_metadata_cache' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Doctrine\Common\Cache\ArrayCache A Doctrine\Common\Cache\ArrayCache instance.
     */
    protected function getDoctrineCache_Providers_Doctrine_Orm_DefaultMetadataCacheService()
    {
        $this->services['doctrine_cache.providers.doctrine.orm.default_metadata_cache'] = $instance = new \Doctrine\Common\Cache\ArrayCache();

        $instance->setNamespace('sf2orm_default_3cf4c742d9cc95dd07da28e25b5f2ae3f5c87b9d4e47b1a3ea03612798549434');

        return $instance;
    }

    /**
     * Gets the 'doctrine_cache.providers.doctrine.orm.default_query_cache' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Doctrine\Common\Cache\ArrayCache A Doctrine\Common\Cache\ArrayCache instance.
     */
    protected function getDoctrineCache_Providers_Doctrine_Orm_DefaultQueryCacheService()
    {
        $this->services['doctrine_cache.providers.doctrine.orm.default_query_cache'] = $instance = new \Doctrine\Common\Cache\ArrayCache();

        $instance->setNamespace('sf2orm_default_3cf4c742d9cc95dd07da28e25b5f2ae3f5c87b9d4e47b1a3ea03612798549434');

        return $instance;
    }

    /**
     * Gets the 'doctrine_cache.providers.doctrine.orm.default_result_cache' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Doctrine\Common\Cache\ArrayCache A Doctrine\Common\Cache\ArrayCache instance.
     */
    protected function getDoctrineCache_Providers_Doctrine_Orm_DefaultResultCacheService()
    {
        $this->services['doctrine_cache.providers.doctrine.orm.default_result_cache'] = $instance = new \Doctrine\Common\Cache\ArrayCache();

        $instance->setNamespace('sf2orm_default_3cf4c742d9cc95dd07da28e25b5f2ae3f5c87b9d4e47b1a3ea03612798549434');

        return $instance;
    }

    /**
     * Gets the 'easyadmin.configurator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JavierEguiluz\Bundle\EasyAdminBundle\Configuration\Configurator A JavierEguiluz\Bundle\EasyAdminBundle\Configuration\Configurator instance.
     */
    protected function getEasyadmin_ConfiguratorService()
    {
        return $this->services['easyadmin.configurator'] = new \JavierEguiluz\Bundle\EasyAdminBundle\Configuration\Configurator(array('entities' => array('User' => array('class' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'name' => 'User', 'label' => 'User', 'edit' => array('fields' => array('username' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'username', 'columnName' => 'username', 'length' => 255, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'username'), 'usernameCanonical' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'usernameCanonical', 'columnName' => 'username_canonical', 'length' => 255, 'unique' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'usernameCanonical'), 'email' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'email', 'columnName' => 'email', 'length' => 255, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'email'), 'emailCanonical' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'emailCanonical', 'columnName' => 'email_canonical', 'length' => 255, 'unique' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'emailCanonical'), 'enabled' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'enabled', 'columnName' => 'enabled', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'enabled'), 'salt' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'salt', 'columnName' => 'salt', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'salt'), 'password' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'password', 'columnName' => 'password', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'password'), 'lastLogin' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'lastLogin', 'columnName' => 'last_login', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'lastLogin'), 'locked' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'locked', 'columnName' => 'locked', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'locked'), 'expired' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'expired', 'columnName' => 'expired', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'expired'), 'expiresAt' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'expiresAt', 'columnName' => 'expires_at', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'expiresAt'), 'confirmationToken' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'confirmationToken', 'columnName' => 'confirmation_token', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'confirmationToken'), 'passwordRequestedAt' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'passwordRequestedAt', 'columnName' => 'password_requested_at', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'passwordRequestedAt'), 'roles' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'array', 'fieldType' => 'collection', 'dataType' => 'array', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'roles', 'columnName' => 'roles', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'roles'), 'credentialsExpired' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'credentialsExpired', 'columnName' => 'credentials_expired', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'credentialsExpired'), 'credentialsExpireAt' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'credentialsExpireAt', 'columnName' => 'credentials_expire_at', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'credentialsExpireAt'), 'timerecords' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'timerecords', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Timerecord', 'mappedBy' => 'users', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'timerecords'), 'payrolls' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'payrolls', 'targetEntity' => 'EdgeWeb\\Project\\PaycomBundle\\Entity\\Payroll', 'mappedBy' => 'users', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'payrolls'), 'position' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'position', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'inversedBy' => 'users', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'position_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('position_id' => 'id'), 'joinColumnFieldNames' => array('position_id' => 'position_id'), 'targetToSourceKeyColumns' => array('id' => 'position_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'position')), 'form_options' => array(), 'actions' => array('delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'btn btn-default action-delete', 'icon' => 'trash-o'), 'list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'list' => array('fields' => array('username' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'username', 'columnName' => 'username', 'length' => 255, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'username'), 'usernameCanonical' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'usernameCanonical', 'columnName' => 'username_canonical', 'length' => 255, 'unique' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'usernameCanonical'), 'email' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'email', 'columnName' => 'email', 'length' => 255, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'email'), 'emailCanonical' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'emailCanonical', 'columnName' => 'email_canonical', 'length' => 255, 'unique' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'emailCanonical'), 'enabled' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_toggle.html.twig', 'type_options' => array(), 'fieldName' => 'enabled', 'columnName' => 'enabled', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'enabled'), 'lastLogin' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'lastLogin', 'columnName' => 'last_login', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'lastLogin'), 'locked' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_toggle.html.twig', 'type_options' => array(), 'fieldName' => 'locked', 'columnName' => 'locked', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'locked')), 'actions' => array('edit' => array('name' => 'edit', 'type' => 'method', 'label' => 'action.edit', 'css_class' => 'text-primary action-edit', 'icon' => NULL), 'delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'text-danger action-delete', 'icon' => NULL), 'new' => array('name' => 'new', 'type' => 'method', 'label' => 'action.new', 'css_class' => 'btn btn-primary action-new', 'icon' => NULL), 'search' => array('name' => 'search', 'type' => 'method', 'label' => 'action.search', 'css_class' => ' action-search', 'icon' => NULL))), 'new' => array('fields' => array('username' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'username', 'columnName' => 'username', 'length' => 255, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'username'), 'usernameCanonical' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'usernameCanonical', 'columnName' => 'username_canonical', 'length' => 255, 'unique' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'usernameCanonical'), 'email' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'email', 'columnName' => 'email', 'length' => 255, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'email'), 'emailCanonical' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'emailCanonical', 'columnName' => 'email_canonical', 'length' => 255, 'unique' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'emailCanonical'), 'enabled' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'enabled', 'columnName' => 'enabled', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'enabled'), 'salt' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'salt', 'columnName' => 'salt', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'salt'), 'password' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'password', 'columnName' => 'password', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'password'), 'lastLogin' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'lastLogin', 'columnName' => 'last_login', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'lastLogin'), 'locked' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'locked', 'columnName' => 'locked', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'locked'), 'expired' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'expired', 'columnName' => 'expired', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'expired'), 'expiresAt' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'expiresAt', 'columnName' => 'expires_at', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'expiresAt'), 'confirmationToken' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'confirmationToken', 'columnName' => 'confirmation_token', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'confirmationToken'), 'passwordRequestedAt' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'passwordRequestedAt', 'columnName' => 'password_requested_at', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'passwordRequestedAt'), 'roles' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'array', 'fieldType' => 'collection', 'dataType' => 'array', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'roles', 'columnName' => 'roles', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'roles'), 'credentialsExpired' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'credentialsExpired', 'columnName' => 'credentials_expired', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'credentialsExpired'), 'credentialsExpireAt' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'credentialsExpireAt', 'columnName' => 'credentials_expire_at', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'credentialsExpireAt'), 'timerecords' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'timerecords', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Timerecord', 'mappedBy' => 'users', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'timerecords'), 'payrolls' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'payrolls', 'targetEntity' => 'EdgeWeb\\Project\\PaycomBundle\\Entity\\Payroll', 'mappedBy' => 'users', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'payrolls'), 'position' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'position', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'inversedBy' => 'users', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'position_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('position_id' => 'id'), 'joinColumnFieldNames' => array('position_id' => 'position_id'), 'targetToSourceKeyColumns' => array('id' => 'position_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'position')), 'form_options' => array(), 'actions' => array('list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'search' => array('fields' => array('username' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'username', 'columnName' => 'username', 'length' => 255, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'username'), 'usernameCanonical' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'usernameCanonical', 'columnName' => 'username_canonical', 'length' => 255, 'unique' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'usernameCanonical'), 'email' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'email', 'columnName' => 'email', 'length' => 255, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'email'), 'emailCanonical' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'emailCanonical', 'columnName' => 'email_canonical', 'length' => 255, 'unique' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'emailCanonical'), 'confirmationToken' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'confirmationToken', 'columnName' => 'confirmation_token', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'confirmationToken'), 'roles' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'array', 'fieldType' => 'collection', 'dataType' => 'array', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'roles', 'columnName' => 'roles', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'roles'), 'id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => 'ID', 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'))), 'show' => array('fields' => array('username' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'username', 'columnName' => 'username', 'length' => 255, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'username'), 'usernameCanonical' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'usernameCanonical', 'columnName' => 'username_canonical', 'length' => 255, 'unique' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'usernameCanonical'), 'email' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'email', 'columnName' => 'email', 'length' => 255, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'email'), 'emailCanonical' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'emailCanonical', 'columnName' => 'email_canonical', 'length' => 255, 'unique' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'emailCanonical'), 'enabled' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_toggle.html.twig', 'type_options' => array(), 'fieldName' => 'enabled', 'columnName' => 'enabled', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'enabled'), 'salt' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'salt', 'columnName' => 'salt', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'salt'), 'password' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'password', 'columnName' => 'password', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'password'), 'lastLogin' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'lastLogin', 'columnName' => 'last_login', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'lastLogin'), 'locked' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_toggle.html.twig', 'type_options' => array(), 'fieldName' => 'locked', 'columnName' => 'locked', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'locked'), 'expired' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_toggle.html.twig', 'type_options' => array(), 'fieldName' => 'expired', 'columnName' => 'expired', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'expired'), 'expiresAt' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'expiresAt', 'columnName' => 'expires_at', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'expiresAt'), 'confirmationToken' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'confirmationToken', 'columnName' => 'confirmation_token', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'confirmationToken'), 'passwordRequestedAt' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'passwordRequestedAt', 'columnName' => 'password_requested_at', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'passwordRequestedAt'), 'roles' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'array', 'fieldType' => 'collection', 'dataType' => 'array', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_array.html.twig', 'type_options' => array(), 'fieldName' => 'roles', 'columnName' => 'roles', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'roles'), 'credentialsExpired' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_toggle.html.twig', 'type_options' => array(), 'fieldName' => 'credentialsExpired', 'columnName' => 'credentials_expired', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'credentialsExpired'), 'credentialsExpireAt' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'credentialsExpireAt', 'columnName' => 'credentials_expire_at', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'credentialsExpireAt'), 'id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => 'ID', 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_id.html.twig', 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'timerecords' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => '@EasyAdmin/default/field_association.html.twig', 'type_options' => array(), 'fieldName' => 'timerecords', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Timerecord', 'mappedBy' => 'users', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'timerecords'), 'payrolls' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => '@EasyAdmin/default/field_association.html.twig', 'type_options' => array(), 'fieldName' => 'payrolls', 'targetEntity' => 'EdgeWeb\\Project\\PaycomBundle\\Entity\\Payroll', 'mappedBy' => 'users', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'payrolls'), 'position' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_association.html.twig', 'type_options' => array(), 'fieldName' => 'position', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'inversedBy' => 'users', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'position_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('position_id' => 'id'), 'joinColumnFieldNames' => array('position_id' => 'position_id'), 'targetToSourceKeyColumns' => array('id' => 'position_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'position')), 'actions' => array('edit' => array('name' => 'edit', 'type' => 'method', 'label' => 'action.edit', 'css_class' => 'btn btn-primary action-edit', 'icon' => 'edit'), 'delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'btn btn-default action-delete', 'icon' => 'trash-o'), 'list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'disabled_actions' => array(), 'primary_key_field_name' => 'id', 'properties' => array('username' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'username', 'columnName' => 'username', 'length' => 255, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'username'), 'usernameCanonical' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'usernameCanonical', 'columnName' => 'username_canonical', 'length' => 255, 'unique' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'usernameCanonical'), 'email' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'email', 'columnName' => 'email', 'length' => 255, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'email'), 'emailCanonical' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'emailCanonical', 'columnName' => 'email_canonical', 'length' => 255, 'unique' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'emailCanonical'), 'enabled' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'enabled', 'columnName' => 'enabled', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'enabled'), 'salt' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'salt', 'columnName' => 'salt', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'salt'), 'password' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'password', 'columnName' => 'password', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'password'), 'lastLogin' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'lastLogin', 'columnName' => 'last_login', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'lastLogin'), 'locked' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'locked', 'columnName' => 'locked', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'locked'), 'expired' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'expired', 'columnName' => 'expired', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'expired'), 'expiresAt' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'expiresAt', 'columnName' => 'expires_at', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'expiresAt'), 'confirmationToken' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'confirmationToken', 'columnName' => 'confirmation_token', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'confirmationToken'), 'passwordRequestedAt' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'passwordRequestedAt', 'columnName' => 'password_requested_at', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'passwordRequestedAt'), 'roles' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'array', 'fieldType' => 'collection', 'dataType' => 'array', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'roles', 'columnName' => 'roles', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'roles'), 'credentialsExpired' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'boolean', 'fieldType' => 'checkbox', 'dataType' => 'toggle', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'credentialsExpired', 'columnName' => 'credentials_expired', 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'credentialsExpired'), 'credentialsExpireAt' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'credentialsExpireAt', 'columnName' => 'credentials_expire_at', 'nullable' => true, 'declared' => 'FOS\\UserBundle\\Model\\User', 'property' => 'credentialsExpireAt'), 'id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'timerecords' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'timerecords', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Timerecord', 'mappedBy' => 'users', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'timerecords'), 'payrolls' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'payrolls', 'targetEntity' => 'EdgeWeb\\Project\\PaycomBundle\\Entity\\Payroll', 'mappedBy' => 'users', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'payrolls'), 'position' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'position', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'inversedBy' => 'users', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'position_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('position_id' => 'id'), 'joinColumnFieldNames' => array('position_id' => 'position_id'), 'targetToSourceKeyColumns' => array('id' => 'position_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'position')), 'templates' => array('layout' => '@EasyAdmin/default/layout.html.twig', 'menu' => '@EasyAdmin/default/menu.html.twig', 'edit' => '@EasyAdmin/default/edit.html.twig', 'list' => '@EasyAdmin/default/list.html.twig', 'new' => '@EasyAdmin/default/new.html.twig', 'show' => '@EasyAdmin/default/show.html.twig', 'exception' => '@EasyAdmin/default/exception.html.twig', 'flash_messages' => '@EasyAdmin/default/flash_messages.html.twig', 'paginator' => '@EasyAdmin/default/paginator.html.twig', 'field_array' => '@EasyAdmin/default/field_array.html.twig', 'field_association' => '@EasyAdmin/default/field_association.html.twig', 'field_bigint' => '@EasyAdmin/default/field_bigint.html.twig', 'field_boolean' => '@EasyAdmin/default/field_boolean.html.twig', 'field_date' => '@EasyAdmin/default/field_date.html.twig', 'field_datetime' => '@EasyAdmin/default/field_datetime.html.twig', 'field_datetimetz' => '@EasyAdmin/default/field_datetimetz.html.twig', 'field_decimal' => '@EasyAdmin/default/field_decimal.html.twig', 'field_float' => '@EasyAdmin/default/field_float.html.twig', 'field_guid' => '@EasyAdmin/default/field_guid.html.twig', 'field_id' => '@EasyAdmin/default/field_id.html.twig', 'field_image' => '@EasyAdmin/default/field_image.html.twig', 'field_json_array' => '@EasyAdmin/default/field_json_array.html.twig', 'field_integer' => '@EasyAdmin/default/field_integer.html.twig', 'field_object' => '@EasyAdmin/default/field_object.html.twig', 'field_raw' => '@EasyAdmin/default/field_raw.html.twig', 'field_simple_array' => '@EasyAdmin/default/field_simple_array.html.twig', 'field_smallint' => '@EasyAdmin/default/field_smallint.html.twig', 'field_string' => '@EasyAdmin/default/field_string.html.twig', 'field_text' => '@EasyAdmin/default/field_text.html.twig', 'field_time' => '@EasyAdmin/default/field_time.html.twig', 'field_toggle' => '@EasyAdmin/default/field_toggle.html.twig', 'label_empty' => '@EasyAdmin/default/label_empty.html.twig', 'label_inaccessible' => '@EasyAdmin/default/label_inaccessible.html.twig', 'label_null' => '@EasyAdmin/default/label_null.html.twig', 'label_undefined' => '@EasyAdmin/default/label_undefined.html.twig')), 'Department' => array('class' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department', 'name' => 'Department', 'label' => 'Department', 'edit' => array('fields' => array('department' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'department', 'length' => 255, 'columnName' => 'department', 'property' => 'department'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'datecreated', 'columnName' => 'datecreated', 'property' => 'datecreated'), 'positions' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'positions', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'mappedBy' => 'department', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'positions')), 'form_options' => array(), 'actions' => array('delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'btn btn-default action-delete', 'icon' => 'trash-o'), 'list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'list' => array('fields' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => 'ID', 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_id.html.twig', 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'department' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'department', 'length' => 255, 'columnName' => 'department', 'property' => 'department'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'datecreated', 'columnName' => 'datecreated', 'property' => 'datecreated')), 'actions' => array('edit' => array('name' => 'edit', 'type' => 'method', 'label' => 'action.edit', 'css_class' => 'text-primary action-edit', 'icon' => NULL), 'delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'text-danger action-delete', 'icon' => NULL), 'new' => array('name' => 'new', 'type' => 'method', 'label' => 'action.new', 'css_class' => 'btn btn-primary action-new', 'icon' => NULL), 'search' => array('name' => 'search', 'type' => 'method', 'label' => 'action.search', 'css_class' => ' action-search', 'icon' => NULL))), 'new' => array('fields' => array('department' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'department', 'length' => 255, 'columnName' => 'department', 'property' => 'department'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'datecreated', 'columnName' => 'datecreated', 'property' => 'datecreated'), 'positions' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'positions', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'mappedBy' => 'department', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'positions')), 'form_options' => array(), 'actions' => array('list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'search' => array('fields' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => 'ID', 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'department' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'department', 'length' => 255, 'columnName' => 'department', 'property' => 'department'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'))), 'show' => array('fields' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => 'ID', 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_id.html.twig', 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'department' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'department', 'length' => 255, 'columnName' => 'department', 'property' => 'department'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'datecreated', 'columnName' => 'datecreated', 'property' => 'datecreated'), 'positions' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => '@EasyAdmin/default/field_association.html.twig', 'type_options' => array(), 'fieldName' => 'positions', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'mappedBy' => 'department', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'positions')), 'actions' => array('edit' => array('name' => 'edit', 'type' => 'method', 'label' => 'action.edit', 'css_class' => 'btn btn-primary action-edit', 'icon' => 'edit'), 'delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'btn btn-default action-delete', 'icon' => 'trash-o'), 'list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'disabled_actions' => array(), 'primary_key_field_name' => 'id', 'properties' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'department' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'department', 'length' => 255, 'columnName' => 'department', 'property' => 'department'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'datecreated', 'columnName' => 'datecreated', 'property' => 'datecreated'), 'positions' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'positions', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'mappedBy' => 'department', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'positions')), 'templates' => array('layout' => '@EasyAdmin/default/layout.html.twig', 'menu' => '@EasyAdmin/default/menu.html.twig', 'edit' => '@EasyAdmin/default/edit.html.twig', 'list' => '@EasyAdmin/default/list.html.twig', 'new' => '@EasyAdmin/default/new.html.twig', 'show' => '@EasyAdmin/default/show.html.twig', 'exception' => '@EasyAdmin/default/exception.html.twig', 'flash_messages' => '@EasyAdmin/default/flash_messages.html.twig', 'paginator' => '@EasyAdmin/default/paginator.html.twig', 'field_array' => '@EasyAdmin/default/field_array.html.twig', 'field_association' => '@EasyAdmin/default/field_association.html.twig', 'field_bigint' => '@EasyAdmin/default/field_bigint.html.twig', 'field_boolean' => '@EasyAdmin/default/field_boolean.html.twig', 'field_date' => '@EasyAdmin/default/field_date.html.twig', 'field_datetime' => '@EasyAdmin/default/field_datetime.html.twig', 'field_datetimetz' => '@EasyAdmin/default/field_datetimetz.html.twig', 'field_decimal' => '@EasyAdmin/default/field_decimal.html.twig', 'field_float' => '@EasyAdmin/default/field_float.html.twig', 'field_guid' => '@EasyAdmin/default/field_guid.html.twig', 'field_id' => '@EasyAdmin/default/field_id.html.twig', 'field_image' => '@EasyAdmin/default/field_image.html.twig', 'field_json_array' => '@EasyAdmin/default/field_json_array.html.twig', 'field_integer' => '@EasyAdmin/default/field_integer.html.twig', 'field_object' => '@EasyAdmin/default/field_object.html.twig', 'field_raw' => '@EasyAdmin/default/field_raw.html.twig', 'field_simple_array' => '@EasyAdmin/default/field_simple_array.html.twig', 'field_smallint' => '@EasyAdmin/default/field_smallint.html.twig', 'field_string' => '@EasyAdmin/default/field_string.html.twig', 'field_text' => '@EasyAdmin/default/field_text.html.twig', 'field_time' => '@EasyAdmin/default/field_time.html.twig', 'field_toggle' => '@EasyAdmin/default/field_toggle.html.twig', 'label_empty' => '@EasyAdmin/default/label_empty.html.twig', 'label_inaccessible' => '@EasyAdmin/default/label_inaccessible.html.twig', 'label_null' => '@EasyAdmin/default/label_null.html.twig', 'label_undefined' => '@EasyAdmin/default/label_undefined.html.twig')), 'Position' => array('class' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'name' => 'Position', 'label' => 'Position', 'edit' => array('fields' => array('name' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'name', 'length' => 255, 'columnName' => 'name', 'property' => 'name'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'datecreated', 'nullable' => true, 'columnName' => 'datecreated', 'property' => 'datecreated'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'users' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'users', 'targetEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'mappedBy' => 'position', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'users'), 'department' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'department', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department', 'inversedBy' => 'positions', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'department_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('department_id' => 'id'), 'joinColumnFieldNames' => array('department_id' => 'department_id'), 'targetToSourceKeyColumns' => array('id' => 'department_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'department')), 'form_options' => array(), 'actions' => array('delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'btn btn-default action-delete', 'icon' => 'trash-o'), 'list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'list' => array('fields' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => 'ID', 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_id.html.twig', 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'name' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'name', 'length' => 255, 'columnName' => 'name', 'property' => 'name'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'datecreated', 'nullable' => true, 'columnName' => 'datecreated', 'property' => 'datecreated'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated')), 'actions' => array('edit' => array('name' => 'edit', 'type' => 'method', 'label' => 'action.edit', 'css_class' => 'text-primary action-edit', 'icon' => NULL), 'delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'text-danger action-delete', 'icon' => NULL), 'new' => array('name' => 'new', 'type' => 'method', 'label' => 'action.new', 'css_class' => 'btn btn-primary action-new', 'icon' => NULL), 'search' => array('name' => 'search', 'type' => 'method', 'label' => 'action.search', 'css_class' => ' action-search', 'icon' => NULL))), 'new' => array('fields' => array('name' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'name', 'length' => 255, 'columnName' => 'name', 'property' => 'name'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'datecreated', 'nullable' => true, 'columnName' => 'datecreated', 'property' => 'datecreated'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'users' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'users', 'targetEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'mappedBy' => 'position', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'users'), 'department' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'department', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department', 'inversedBy' => 'positions', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'department_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('department_id' => 'id'), 'joinColumnFieldNames' => array('department_id' => 'department_id'), 'targetToSourceKeyColumns' => array('id' => 'department_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'department')), 'form_options' => array(), 'actions' => array('list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'search' => array('fields' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => 'ID', 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'name' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'name', 'length' => 255, 'columnName' => 'name', 'property' => 'name'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'))), 'show' => array('fields' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => 'ID', 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_id.html.twig', 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'name' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'name', 'length' => 255, 'columnName' => 'name', 'property' => 'name'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'datecreated', 'nullable' => true, 'columnName' => 'datecreated', 'property' => 'datecreated'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'users' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => '@EasyAdmin/default/field_association.html.twig', 'type_options' => array(), 'fieldName' => 'users', 'targetEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'mappedBy' => 'position', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'users'), 'department' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_association.html.twig', 'type_options' => array(), 'fieldName' => 'department', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department', 'inversedBy' => 'positions', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'department_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('department_id' => 'id'), 'joinColumnFieldNames' => array('department_id' => 'department_id'), 'targetToSourceKeyColumns' => array('id' => 'department_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'department')), 'actions' => array('edit' => array('name' => 'edit', 'type' => 'method', 'label' => 'action.edit', 'css_class' => 'btn btn-primary action-edit', 'icon' => 'edit'), 'delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'btn btn-default action-delete', 'icon' => 'trash-o'), 'list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'disabled_actions' => array(), 'primary_key_field_name' => 'id', 'properties' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'name' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'name', 'length' => 255, 'columnName' => 'name', 'property' => 'name'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'datecreated', 'nullable' => true, 'columnName' => 'datecreated', 'property' => 'datecreated'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'users' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'users', 'targetEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User', 'mappedBy' => 'position', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'users'), 'department' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'department', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department', 'inversedBy' => 'positions', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'department_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('department_id' => 'id'), 'joinColumnFieldNames' => array('department_id' => 'department_id'), 'targetToSourceKeyColumns' => array('id' => 'department_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'department')), 'templates' => array('layout' => '@EasyAdmin/default/layout.html.twig', 'menu' => '@EasyAdmin/default/menu.html.twig', 'edit' => '@EasyAdmin/default/edit.html.twig', 'list' => '@EasyAdmin/default/list.html.twig', 'new' => '@EasyAdmin/default/new.html.twig', 'show' => '@EasyAdmin/default/show.html.twig', 'exception' => '@EasyAdmin/default/exception.html.twig', 'flash_messages' => '@EasyAdmin/default/flash_messages.html.twig', 'paginator' => '@EasyAdmin/default/paginator.html.twig', 'field_array' => '@EasyAdmin/default/field_array.html.twig', 'field_association' => '@EasyAdmin/default/field_association.html.twig', 'field_bigint' => '@EasyAdmin/default/field_bigint.html.twig', 'field_boolean' => '@EasyAdmin/default/field_boolean.html.twig', 'field_date' => '@EasyAdmin/default/field_date.html.twig', 'field_datetime' => '@EasyAdmin/default/field_datetime.html.twig', 'field_datetimetz' => '@EasyAdmin/default/field_datetimetz.html.twig', 'field_decimal' => '@EasyAdmin/default/field_decimal.html.twig', 'field_float' => '@EasyAdmin/default/field_float.html.twig', 'field_guid' => '@EasyAdmin/default/field_guid.html.twig', 'field_id' => '@EasyAdmin/default/field_id.html.twig', 'field_image' => '@EasyAdmin/default/field_image.html.twig', 'field_json_array' => '@EasyAdmin/default/field_json_array.html.twig', 'field_integer' => '@EasyAdmin/default/field_integer.html.twig', 'field_object' => '@EasyAdmin/default/field_object.html.twig', 'field_raw' => '@EasyAdmin/default/field_raw.html.twig', 'field_simple_array' => '@EasyAdmin/default/field_simple_array.html.twig', 'field_smallint' => '@EasyAdmin/default/field_smallint.html.twig', 'field_string' => '@EasyAdmin/default/field_string.html.twig', 'field_text' => '@EasyAdmin/default/field_text.html.twig', 'field_time' => '@EasyAdmin/default/field_time.html.twig', 'field_toggle' => '@EasyAdmin/default/field_toggle.html.twig', 'label_empty' => '@EasyAdmin/default/label_empty.html.twig', 'label_inaccessible' => '@EasyAdmin/default/label_inaccessible.html.twig', 'label_null' => '@EasyAdmin/default/label_null.html.twig', 'label_undefined' => '@EasyAdmin/default/label_undefined.html.twig')), 'Comment' => array('class' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment', 'name' => 'Comment', 'label' => 'Comment', 'edit' => array('fields' => array('comment' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'comment', 'length' => 255, 'columnName' => 'comment', 'property' => 'comment'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'datecreated', 'nullable' => true, 'columnName' => 'datecreated', 'property' => 'datecreated'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'task' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'task', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task', 'inversedBy' => 'comments', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'task_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('task_id' => 'id'), 'joinColumnFieldNames' => array('task_id' => 'task_id'), 'targetToSourceKeyColumns' => array('id' => 'task_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'task')), 'form_options' => array(), 'actions' => array('delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'btn btn-default action-delete', 'icon' => 'trash-o'), 'list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'list' => array('fields' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => 'ID', 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_id.html.twig', 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'comment' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'comment', 'length' => 255, 'columnName' => 'comment', 'property' => 'comment'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'datecreated', 'nullable' => true, 'columnName' => 'datecreated', 'property' => 'datecreated'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'task' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_association.html.twig', 'type_options' => array(), 'fieldName' => 'task', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task', 'inversedBy' => 'comments', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'task_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('task_id' => 'id'), 'joinColumnFieldNames' => array('task_id' => 'task_id'), 'targetToSourceKeyColumns' => array('id' => 'task_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'task')), 'actions' => array('edit' => array('name' => 'edit', 'type' => 'method', 'label' => 'action.edit', 'css_class' => 'text-primary action-edit', 'icon' => NULL), 'delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'text-danger action-delete', 'icon' => NULL), 'new' => array('name' => 'new', 'type' => 'method', 'label' => 'action.new', 'css_class' => 'btn btn-primary action-new', 'icon' => NULL), 'search' => array('name' => 'search', 'type' => 'method', 'label' => 'action.search', 'css_class' => ' action-search', 'icon' => NULL))), 'new' => array('fields' => array('comment' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'comment', 'length' => 255, 'columnName' => 'comment', 'property' => 'comment'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'datecreated', 'nullable' => true, 'columnName' => 'datecreated', 'property' => 'datecreated'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'task' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'task', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task', 'inversedBy' => 'comments', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'task_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('task_id' => 'id'), 'joinColumnFieldNames' => array('task_id' => 'task_id'), 'targetToSourceKeyColumns' => array('id' => 'task_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'task')), 'form_options' => array(), 'actions' => array('list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'search' => array('fields' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => 'ID', 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'comment' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'comment', 'length' => 255, 'columnName' => 'comment', 'property' => 'comment'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'))), 'show' => array('fields' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => 'ID', 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_id.html.twig', 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'comment' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'comment', 'length' => 255, 'columnName' => 'comment', 'property' => 'comment'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'datecreated', 'nullable' => true, 'columnName' => 'datecreated', 'property' => 'datecreated'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'task' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_association.html.twig', 'type_options' => array(), 'fieldName' => 'task', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task', 'inversedBy' => 'comments', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'task_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('task_id' => 'id'), 'joinColumnFieldNames' => array('task_id' => 'task_id'), 'targetToSourceKeyColumns' => array('id' => 'task_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'task')), 'actions' => array('edit' => array('name' => 'edit', 'type' => 'method', 'label' => 'action.edit', 'css_class' => 'btn btn-primary action-edit', 'icon' => 'edit'), 'delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'btn btn-default action-delete', 'icon' => 'trash-o'), 'list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'disabled_actions' => array(), 'primary_key_field_name' => 'id', 'properties' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'comment' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'comment', 'length' => 255, 'columnName' => 'comment', 'property' => 'comment'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'datecreated', 'nullable' => true, 'columnName' => 'datecreated', 'property' => 'datecreated'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'task' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'task', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task', 'inversedBy' => 'comments', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'task_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('task_id' => 'id'), 'joinColumnFieldNames' => array('task_id' => 'task_id'), 'targetToSourceKeyColumns' => array('id' => 'task_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'task')), 'templates' => array('layout' => '@EasyAdmin/default/layout.html.twig', 'menu' => '@EasyAdmin/default/menu.html.twig', 'edit' => '@EasyAdmin/default/edit.html.twig', 'list' => '@EasyAdmin/default/list.html.twig', 'new' => '@EasyAdmin/default/new.html.twig', 'show' => '@EasyAdmin/default/show.html.twig', 'exception' => '@EasyAdmin/default/exception.html.twig', 'flash_messages' => '@EasyAdmin/default/flash_messages.html.twig', 'paginator' => '@EasyAdmin/default/paginator.html.twig', 'field_array' => '@EasyAdmin/default/field_array.html.twig', 'field_association' => '@EasyAdmin/default/field_association.html.twig', 'field_bigint' => '@EasyAdmin/default/field_bigint.html.twig', 'field_boolean' => '@EasyAdmin/default/field_boolean.html.twig', 'field_date' => '@EasyAdmin/default/field_date.html.twig', 'field_datetime' => '@EasyAdmin/default/field_datetime.html.twig', 'field_datetimetz' => '@EasyAdmin/default/field_datetimetz.html.twig', 'field_decimal' => '@EasyAdmin/default/field_decimal.html.twig', 'field_float' => '@EasyAdmin/default/field_float.html.twig', 'field_guid' => '@EasyAdmin/default/field_guid.html.twig', 'field_id' => '@EasyAdmin/default/field_id.html.twig', 'field_image' => '@EasyAdmin/default/field_image.html.twig', 'field_json_array' => '@EasyAdmin/default/field_json_array.html.twig', 'field_integer' => '@EasyAdmin/default/field_integer.html.twig', 'field_object' => '@EasyAdmin/default/field_object.html.twig', 'field_raw' => '@EasyAdmin/default/field_raw.html.twig', 'field_simple_array' => '@EasyAdmin/default/field_simple_array.html.twig', 'field_smallint' => '@EasyAdmin/default/field_smallint.html.twig', 'field_string' => '@EasyAdmin/default/field_string.html.twig', 'field_text' => '@EasyAdmin/default/field_text.html.twig', 'field_time' => '@EasyAdmin/default/field_time.html.twig', 'field_toggle' => '@EasyAdmin/default/field_toggle.html.twig', 'label_empty' => '@EasyAdmin/default/label_empty.html.twig', 'label_inaccessible' => '@EasyAdmin/default/label_inaccessible.html.twig', 'label_null' => '@EasyAdmin/default/label_null.html.twig', 'label_undefined' => '@EasyAdmin/default/label_undefined.html.twig')), 'Task' => array('class' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task', 'name' => 'Task', 'label' => 'Task', 'edit' => array('fields' => array('name' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'name', 'length' => 255, 'columnName' => 'name', 'property' => 'name'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'start' => array('css_class' => '', 'format' => 'H:i:s', 'help' => NULL, 'label' => NULL, 'type' => 'time', 'fieldType' => 'time', 'dataType' => 'time', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'start', 'columnName' => 'start', 'property' => 'start'), 'end' => array('css_class' => '', 'format' => 'H:i:s', 'help' => NULL, 'label' => NULL, 'type' => 'time', 'fieldType' => 'time', 'dataType' => 'time', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'end', 'columnName' => 'end', 'property' => 'end'), 'path' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'path', 'nullable' => true, 'columnName' => 'path', 'property' => 'path'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'datecreated', 'nullable' => true, 'columnName' => 'datecreated', 'property' => 'datecreated'), 'comments' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'comments', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment', 'mappedBy' => 'task', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'comments'), 'project' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'project', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Project', 'inversedBy' => 'tasks', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'project_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('project_id' => 'id'), 'joinColumnFieldNames' => array('project_id' => 'project_id'), 'targetToSourceKeyColumns' => array('id' => 'project_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'project')), 'form_options' => array(), 'actions' => array('delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'btn btn-default action-delete', 'icon' => 'trash-o'), 'list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'list' => array('fields' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => 'ID', 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_id.html.twig', 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'name' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'name', 'length' => 255, 'columnName' => 'name', 'property' => 'name'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'start' => array('css_class' => '', 'format' => 'H:i:s', 'help' => NULL, 'label' => NULL, 'type' => 'time', 'fieldType' => 'time', 'dataType' => 'time', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_time.html.twig', 'type_options' => array(), 'fieldName' => 'start', 'columnName' => 'start', 'property' => 'start'), 'end' => array('css_class' => '', 'format' => 'H:i:s', 'help' => NULL, 'label' => NULL, 'type' => 'time', 'fieldType' => 'time', 'dataType' => 'time', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_time.html.twig', 'type_options' => array(), 'fieldName' => 'end', 'columnName' => 'end', 'property' => 'end'), 'path' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'path', 'nullable' => true, 'columnName' => 'path', 'property' => 'path'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby')), 'actions' => array('edit' => array('name' => 'edit', 'type' => 'method', 'label' => 'action.edit', 'css_class' => 'text-primary action-edit', 'icon' => NULL), 'delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'text-danger action-delete', 'icon' => NULL), 'new' => array('name' => 'new', 'type' => 'method', 'label' => 'action.new', 'css_class' => 'btn btn-primary action-new', 'icon' => NULL), 'search' => array('name' => 'search', 'type' => 'method', 'label' => 'action.search', 'css_class' => ' action-search', 'icon' => NULL))), 'new' => array('fields' => array('name' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'name', 'length' => 255, 'columnName' => 'name', 'property' => 'name'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'start' => array('css_class' => '', 'format' => 'H:i:s', 'help' => NULL, 'label' => NULL, 'type' => 'time', 'fieldType' => 'time', 'dataType' => 'time', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'start', 'columnName' => 'start', 'property' => 'start'), 'end' => array('css_class' => '', 'format' => 'H:i:s', 'help' => NULL, 'label' => NULL, 'type' => 'time', 'fieldType' => 'time', 'dataType' => 'time', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'end', 'columnName' => 'end', 'property' => 'end'), 'path' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'path', 'nullable' => true, 'columnName' => 'path', 'property' => 'path'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'datecreated', 'nullable' => true, 'columnName' => 'datecreated', 'property' => 'datecreated'), 'comments' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'comments', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment', 'mappedBy' => 'task', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'comments'), 'project' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'project', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Project', 'inversedBy' => 'tasks', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'project_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('project_id' => 'id'), 'joinColumnFieldNames' => array('project_id' => 'project_id'), 'targetToSourceKeyColumns' => array('id' => 'project_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'project')), 'form_options' => array(), 'actions' => array('list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'search' => array('fields' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => 'ID', 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'name' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'name', 'length' => 255, 'columnName' => 'name', 'property' => 'name'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'path' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'path', 'nullable' => true, 'columnName' => 'path', 'property' => 'path'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'))), 'show' => array('fields' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => 'ID', 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_id.html.twig', 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'name' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'name', 'length' => 255, 'columnName' => 'name', 'property' => 'name'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'start' => array('css_class' => '', 'format' => 'H:i:s', 'help' => NULL, 'label' => NULL, 'type' => 'time', 'fieldType' => 'time', 'dataType' => 'time', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_time.html.twig', 'type_options' => array(), 'fieldName' => 'start', 'columnName' => 'start', 'property' => 'start'), 'end' => array('css_class' => '', 'format' => 'H:i:s', 'help' => NULL, 'label' => NULL, 'type' => 'time', 'fieldType' => 'time', 'dataType' => 'time', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_time.html.twig', 'type_options' => array(), 'fieldName' => 'end', 'columnName' => 'end', 'property' => 'end'), 'path' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'path', 'nullable' => true, 'columnName' => 'path', 'property' => 'path'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_string.html.twig', 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_datetime.html.twig', 'type_options' => array(), 'fieldName' => 'datecreated', 'nullable' => true, 'columnName' => 'datecreated', 'property' => 'datecreated'), 'comments' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => '@EasyAdmin/default/field_association.html.twig', 'type_options' => array(), 'fieldName' => 'comments', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment', 'mappedBy' => 'task', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'comments'), 'project' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => '@EasyAdmin/default/field_association.html.twig', 'type_options' => array(), 'fieldName' => 'project', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Project', 'inversedBy' => 'tasks', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'project_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('project_id' => 'id'), 'joinColumnFieldNames' => array('project_id' => 'project_id'), 'targetToSourceKeyColumns' => array('id' => 'project_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'project')), 'actions' => array('edit' => array('name' => 'edit', 'type' => 'method', 'label' => 'action.edit', 'css_class' => 'btn btn-primary action-edit', 'icon' => 'edit'), 'delete' => array('name' => 'delete', 'type' => 'method', 'label' => 'action.delete', 'css_class' => 'btn btn-default action-delete', 'icon' => 'trash-o'), 'list' => array('name' => 'list', 'type' => 'method', 'label' => 'action.list', 'css_class' => 'btn btn-secondary action-list', 'icon' => NULL))), 'disabled_actions' => array(), 'primary_key_field_name' => 'id', 'properties' => array('id' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'integer', 'fieldType' => 'integer', 'dataType' => 'integer', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'id' => true, 'fieldName' => 'id', 'columnName' => 'id', 'property' => 'id'), 'name' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'name', 'length' => 255, 'columnName' => 'name', 'property' => 'name'), 'description' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'description', 'length' => 255, 'columnName' => 'description', 'property' => 'description'), 'start' => array('css_class' => '', 'format' => 'H:i:s', 'help' => NULL, 'label' => NULL, 'type' => 'time', 'fieldType' => 'time', 'dataType' => 'time', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'start', 'columnName' => 'start', 'property' => 'start'), 'end' => array('css_class' => '', 'format' => 'H:i:s', 'help' => NULL, 'label' => NULL, 'type' => 'time', 'fieldType' => 'time', 'dataType' => 'time', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'end', 'columnName' => 'end', 'property' => 'end'), 'path' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'path', 'nullable' => true, 'columnName' => 'path', 'property' => 'path'), 'createdby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'createdby', 'length' => 255, 'nullable' => true, 'columnName' => 'createdby', 'property' => 'createdby'), 'updatedby' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'string', 'fieldType' => 'text', 'dataType' => 'string', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'updatedby', 'length' => 255, 'nullable' => true, 'columnName' => 'updatedby', 'property' => 'updatedby'), 'dateupdated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'dateupdated', 'nullable' => true, 'columnName' => 'dateupdated', 'property' => 'dateupdated'), 'datecreated' => array('css_class' => '', 'format' => 'F j, Y H:i', 'help' => NULL, 'label' => NULL, 'type' => 'datetime', 'fieldType' => 'datetime', 'dataType' => 'datetime', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'datecreated', 'nullable' => true, 'columnName' => 'datecreated', 'property' => 'datecreated'), 'comments' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => false, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'comments', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment', 'mappedBy' => 'task', 'inversedBy' => NULL, 'isOwningSide' => false, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task', 'fetch' => 2, 'cascade' => array(), 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'orphanRemoval' => false, 'associationType' => 4, 'property' => 'comments'), 'project' => array('css_class' => '', 'format' => NULL, 'help' => NULL, 'label' => NULL, 'type' => 'association', 'fieldType' => 'entity', 'dataType' => 'association', 'virtual' => false, 'sortable' => true, 'template' => NULL, 'type_options' => array(), 'fieldName' => 'project', 'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Project', 'inversedBy' => 'tasks', 'joinColumns' => array(0 => array('referencedColumnName' => 'id', 'name' => 'project_id')), 'cascade' => array(), 'mappedBy' => NULL, 'isOwningSide' => true, 'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task', 'fetch' => 2, 'isCascadeRemove' => false, 'isCascadePersist' => false, 'isCascadeRefresh' => false, 'isCascadeMerge' => false, 'isCascadeDetach' => false, 'sourceToTargetKeyColumns' => array('project_id' => 'id'), 'joinColumnFieldNames' => array('project_id' => 'project_id'), 'targetToSourceKeyColumns' => array('id' => 'project_id'), 'orphanRemoval' => false, 'associationType' => 2, 'property' => 'project')), 'templates' => array('layout' => '@EasyAdmin/default/layout.html.twig', 'menu' => '@EasyAdmin/default/menu.html.twig', 'edit' => '@EasyAdmin/default/edit.html.twig', 'list' => '@EasyAdmin/default/list.html.twig', 'new' => '@EasyAdmin/default/new.html.twig', 'show' => '@EasyAdmin/default/show.html.twig', 'exception' => '@EasyAdmin/default/exception.html.twig', 'flash_messages' => '@EasyAdmin/default/flash_messages.html.twig', 'paginator' => '@EasyAdmin/default/paginator.html.twig', 'field_array' => '@EasyAdmin/default/field_array.html.twig', 'field_association' => '@EasyAdmin/default/field_association.html.twig', 'field_bigint' => '@EasyAdmin/default/field_bigint.html.twig', 'field_boolean' => '@EasyAdmin/default/field_boolean.html.twig', 'field_date' => '@EasyAdmin/default/field_date.html.twig', 'field_datetime' => '@EasyAdmin/default/field_datetime.html.twig', 'field_datetimetz' => '@EasyAdmin/default/field_datetimetz.html.twig', 'field_decimal' => '@EasyAdmin/default/field_decimal.html.twig', 'field_float' => '@EasyAdmin/default/field_float.html.twig', 'field_guid' => '@EasyAdmin/default/field_guid.html.twig', 'field_id' => '@EasyAdmin/default/field_id.html.twig', 'field_image' => '@EasyAdmin/default/field_image.html.twig', 'field_json_array' => '@EasyAdmin/default/field_json_array.html.twig', 'field_integer' => '@EasyAdmin/default/field_integer.html.twig', 'field_object' => '@EasyAdmin/default/field_object.html.twig', 'field_raw' => '@EasyAdmin/default/field_raw.html.twig', 'field_simple_array' => '@EasyAdmin/default/field_simple_array.html.twig', 'field_smallint' => '@EasyAdmin/default/field_smallint.html.twig', 'field_string' => '@EasyAdmin/default/field_string.html.twig', 'field_text' => '@EasyAdmin/default/field_text.html.twig', 'field_time' => '@EasyAdmin/default/field_time.html.twig', 'field_toggle' => '@EasyAdmin/default/field_toggle.html.twig', 'label_empty' => '@EasyAdmin/default/label_empty.html.twig', 'label_inaccessible' => '@EasyAdmin/default/label_inaccessible.html.twig', 'label_null' => '@EasyAdmin/default/label_null.html.twig', 'label_undefined' => '@EasyAdmin/default/label_undefined.html.twig'))), 'site_name' => 'EdgeWebMedia', 'design' => array('assets' => array('css' => array(), 'js' => array(), 'favicon' => array('path' => 'favicon.ico', 'mime_type' => 'image/x-icon')), 'theme' => 'default', 'color_scheme' => 'dark', 'brand_color' => '#205081', 'form_theme' => array(0 => '@EasyAdmin/form/bootstrap_3_horizontal_layout.html.twig'), 'menu' => array(0 => array('entity' => 'User', 'label' => 'User', 'icon' => 'fa-chevron-circle-right', 'children' => array(), 'default' => false, 'target' => false, 'menu_index' => 0, 'submenu_index' => -1, 'type' => 'entity', 'params' => array()), 1 => array('entity' => 'Department', 'label' => 'Department', 'icon' => 'fa-chevron-circle-right', 'children' => array(), 'default' => false, 'target' => false, 'menu_index' => 1, 'submenu_index' => -1, 'type' => 'entity', 'params' => array()), 2 => array('entity' => 'Position', 'label' => 'Position', 'icon' => 'fa-chevron-circle-right', 'children' => array(), 'default' => false, 'target' => false, 'menu_index' => 2, 'submenu_index' => -1, 'type' => 'entity', 'params' => array()), 3 => array('entity' => 'Comment', 'label' => 'Comment', 'icon' => 'fa-chevron-circle-right', 'children' => array(), 'default' => false, 'target' => false, 'menu_index' => 3, 'submenu_index' => -1, 'type' => 'entity', 'params' => array()), 4 => array('entity' => 'Task', 'label' => 'Task', 'icon' => 'fa-chevron-circle-right', 'children' => array(), 'default' => false, 'target' => false, 'menu_index' => 4, 'submenu_index' => -1, 'type' => 'entity', 'params' => array())), 'templates' => array('layout' => '@EasyAdmin/default/layout.html.twig', 'menu' => '@EasyAdmin/default/menu.html.twig', 'edit' => '@EasyAdmin/default/edit.html.twig', 'list' => '@EasyAdmin/default/list.html.twig', 'new' => '@EasyAdmin/default/new.html.twig', 'show' => '@EasyAdmin/default/show.html.twig', 'exception' => '@EasyAdmin/default/exception.html.twig', 'flash_messages' => '@EasyAdmin/default/flash_messages.html.twig', 'paginator' => '@EasyAdmin/default/paginator.html.twig', 'field_array' => '@EasyAdmin/default/field_array.html.twig', 'field_association' => '@EasyAdmin/default/field_association.html.twig', 'field_bigint' => '@EasyAdmin/default/field_bigint.html.twig', 'field_boolean' => '@EasyAdmin/default/field_boolean.html.twig', 'field_date' => '@EasyAdmin/default/field_date.html.twig', 'field_datetime' => '@EasyAdmin/default/field_datetime.html.twig', 'field_datetimetz' => '@EasyAdmin/default/field_datetimetz.html.twig', 'field_decimal' => '@EasyAdmin/default/field_decimal.html.twig', 'field_float' => '@EasyAdmin/default/field_float.html.twig', 'field_guid' => '@EasyAdmin/default/field_guid.html.twig', 'field_id' => '@EasyAdmin/default/field_id.html.twig', 'field_image' => '@EasyAdmin/default/field_image.html.twig', 'field_json_array' => '@EasyAdmin/default/field_json_array.html.twig', 'field_integer' => '@EasyAdmin/default/field_integer.html.twig', 'field_object' => '@EasyAdmin/default/field_object.html.twig', 'field_raw' => '@EasyAdmin/default/field_raw.html.twig', 'field_simple_array' => '@EasyAdmin/default/field_simple_array.html.twig', 'field_smallint' => '@EasyAdmin/default/field_smallint.html.twig', 'field_string' => '@EasyAdmin/default/field_string.html.twig', 'field_text' => '@EasyAdmin/default/field_text.html.twig', 'field_time' => '@EasyAdmin/default/field_time.html.twig', 'field_toggle' => '@EasyAdmin/default/field_toggle.html.twig', 'label_empty' => '@EasyAdmin/default/label_empty.html.twig', 'label_inaccessible' => '@EasyAdmin/default/label_inaccessible.html.twig', 'label_null' => '@EasyAdmin/default/label_null.html.twig', 'label_undefined' => '@EasyAdmin/default/label_undefined.html.twig')), 'formats' => array('date' => 'Y-m-d', 'time' => 'H:i:s', 'datetime' => 'F j, Y H:i'), 'disabled_actions' => array(), 'list' => array('actions' => array(), 'max_results' => 15), 'edit' => array('actions' => array()), 'new' => array('actions' => array()), 'show' => array('actions' => array()), 'default_entity_name' => 'User', 'default_menu_item' => NULL, 'homepage' => array('route' => 'easyadmin', 'params' => array('action' => 'list', 'entity' => 'User'))), $this->get('property_accessor'));
    }

    /**
     * Gets the 'easyadmin.form.type' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JavierEguiluz\Bundle\EasyAdminBundle\Form\Type\EasyAdminFormType A JavierEguiluz\Bundle\EasyAdminBundle\Form\Type\EasyAdminFormType instance.
     */
    protected function getEasyadmin_Form_TypeService()
    {
        $a = $this->get('form.type_guesser.validator');
        $b = $this->get('form.type_guesser.doctrine');

        $c = new \Symfony\Component\Form\FormTypeGuesserChain(array(0 => $a, 1 => $b));

        return $this->services['easyadmin.form.type'] = new \JavierEguiluz\Bundle\EasyAdminBundle\Form\Type\EasyAdminFormType($this->get('easyadmin.configurator'), array(3 => new \JavierEguiluz\Bundle\EasyAdminBundle\Form\Type\Configurator\CollectionTypeConfigurator(), 2 => new \JavierEguiluz\Bundle\EasyAdminBundle\Form\Type\Configurator\CheckboxTypeConfigurator(), 1 => new \JavierEguiluz\Bundle\EasyAdminBundle\Form\Type\Configurator\RequiredOptionConfigurator($c), 0 => new \JavierEguiluz\Bundle\EasyAdminBundle\Form\Type\Configurator\EntityTypeConfigurator($c)));
    }

    /**
     * Gets the 'easyadmin.form.type.extension' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JavierEguiluz\Bundle\EasyAdminBundle\Form\Extension\EasyAdminExtension A JavierEguiluz\Bundle\EasyAdminBundle\Form\Extension\EasyAdminExtension instance.
     */
    protected function getEasyadmin_Form_Type_ExtensionService()
    {
        return $this->services['easyadmin.form.type.extension'] = new \JavierEguiluz\Bundle\EasyAdminBundle\Form\Extension\EasyAdminExtension($this->get('request_stack', ContainerInterface::NULL_ON_INVALID_REFERENCE));
    }

    /**
     * Gets the 'easyadmin.listener.request_post_initialize' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JavierEguiluz\Bundle\EasyAdminBundle\EventListener\RequestPostInitializeListener A JavierEguiluz\Bundle\EasyAdminBundle\EventListener\RequestPostInitializeListener instance.
     */
    protected function getEasyadmin_Listener_RequestPostInitializeService()
    {
        return $this->services['easyadmin.listener.request_post_initialize'] = new \JavierEguiluz\Bundle\EasyAdminBundle\EventListener\RequestPostInitializeListener($this->get('doctrine'), $this->get('request_stack', ContainerInterface::NULL_ON_INVALID_REFERENCE));
    }

    /**
     * Gets the 'easyadmin.paginator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JavierEguiluz\Bundle\EasyAdminBundle\Search\Paginator A JavierEguiluz\Bundle\EasyAdminBundle\Search\Paginator instance.
     */
    protected function getEasyadmin_PaginatorService()
    {
        return $this->services['easyadmin.paginator'] = new \JavierEguiluz\Bundle\EasyAdminBundle\Search\Paginator();
    }

    /**
     * Gets the 'easyadmin.query_builder' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JavierEguiluz\Bundle\EasyAdminBundle\Search\QueryBuilder A JavierEguiluz\Bundle\EasyAdminBundle\Search\QueryBuilder instance.
     */
    protected function getEasyadmin_QueryBuilderService()
    {
        return $this->services['easyadmin.query_builder'] = new \JavierEguiluz\Bundle\EasyAdminBundle\Search\QueryBuilder($this->get('doctrine'));
    }

    /**
     * Gets the 'employee.alreadytimedin_extension' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \EdgeWeb\Project\EmployeeBundle\Twig\AlreadyTimedInExtension A EdgeWeb\Project\EmployeeBundle\Twig\AlreadyTimedInExtension instance.
     */
    protected function getEmployee_AlreadytimedinExtensionService()
    {
        return $this->services['employee.alreadytimedin_extension'] = new \EdgeWeb\Project\EmployeeBundle\Twig\AlreadyTimedInExtension($this->get('doctrine.orm.default_entity_manager'));
    }

    /**
     * Gets the 'employee.currentidproject_extension' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \EdgeWeb\Project\EmployeeBundle\Twig\CurrentIdProjectExtension A EdgeWeb\Project\EmployeeBundle\Twig\CurrentIdProjectExtension instance.
     */
    protected function getEmployee_CurrentidprojectExtensionService()
    {
        return $this->services['employee.currentidproject_extension'] = new \EdgeWeb\Project\EmployeeBundle\Twig\CurrentIdProjectExtension($this->get('doctrine.orm.default_entity_manager'));
    }

    /**
     * Gets the 'employee.projectname_extension' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \EdgeWeb\Project\EmployeeBundle\Twig\ProjectNameExtension A EdgeWeb\Project\EmployeeBundle\Twig\ProjectNameExtension instance.
     */
    protected function getEmployee_ProjectnameExtensionService()
    {
        return $this->services['employee.projectname_extension'] = new \EdgeWeb\Project\EmployeeBundle\Twig\ProjectNameExtension($this->get('doctrine.orm.default_entity_manager'));
    }

    /**
     * Gets the 'employee.projecttask_extension' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \EdgeWeb\Project\EmployeeBundle\Twig\ProjectRelatedTaskExtension A EdgeWeb\Project\EmployeeBundle\Twig\ProjectRelatedTaskExtension instance.
     */
    protected function getEmployee_ProjecttaskExtensionService()
    {
        return $this->services['employee.projecttask_extension'] = new \EdgeWeb\Project\EmployeeBundle\Twig\ProjectRelatedTaskExtension($this->get('doctrine.orm.default_entity_manager'));
    }

    /**
     * Gets the 'employee.twig.number_work_extension' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \EdgeWeb\Project\EmployeeBundle\Twig\WorkHourExtension A EdgeWeb\Project\EmployeeBundle\Twig\WorkHourExtension instance.
     */
    protected function getEmployee_Twig_NumberWorkExtensionService()
    {
        return $this->services['employee.twig.number_work_extension'] = new \EdgeWeb\Project\EmployeeBundle\Twig\WorkHourExtension();
    }

    /**
     * Gets the 'file_locator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\Config\FileLocator A Symfony\Component\HttpKernel\Config\FileLocator instance.
     */
    protected function getFileLocatorService()
    {
        return $this->services['file_locator'] = new \Symfony\Component\HttpKernel\Config\FileLocator($this->get('kernel'), ($this->targetDirs[2].'/Resources'));
    }

    /**
     * Gets the 'filesystem' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Filesystem\Filesystem A Symfony\Component\Filesystem\Filesystem instance.
     */
    protected function getFilesystemService()
    {
        return $this->services['filesystem'] = new \Symfony\Component\Filesystem\Filesystem();
    }

    /**
     * Gets the 'form.csrf_provider' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Csrf\CsrfProvider\CsrfTokenManagerAdapter A Symfony\Component\Form\Extension\Csrf\CsrfProvider\CsrfTokenManagerAdapter instance.
     */
    protected function getForm_CsrfProviderService()
    {
        return $this->services['form.csrf_provider'] = new \Symfony\Component\Form\Extension\Csrf\CsrfProvider\CsrfTokenManagerAdapter($this->get('security.csrf.token_manager'));
    }

    /**
     * Gets the 'form.factory' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\FormFactory A Symfony\Component\Form\FormFactory instance.
     */
    protected function getForm_FactoryService()
    {
        return $this->services['form.factory'] = new \Symfony\Component\Form\FormFactory($this->get('form.registry'), $this->get('form.resolved_type_factory'));
    }

    /**
     * Gets the 'form.registry' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\FormRegistry A Symfony\Component\Form\FormRegistry instance.
     */
    protected function getForm_RegistryService()
    {
        return $this->services['form.registry'] = new \Symfony\Component\Form\FormRegistry(array(0 => new \Symfony\Component\Form\Extension\DependencyInjection\DependencyInjectionExtension($this, array('app_user_registration' => 'app.form.registration', 'app_user_profile' => 'app.form.profile', 'form' => 'form.type.form', 'birthday' => 'form.type.birthday', 'checkbox' => 'form.type.checkbox', 'choice' => 'form.type.choice', 'collection' => 'form.type.collection', 'country' => 'form.type.country', 'date' => 'form.type.date', 'datetime' => 'form.type.datetime', 'email' => 'form.type.email', 'file' => 'form.type.file', 'hidden' => 'form.type.hidden', 'integer' => 'form.type.integer', 'language' => 'form.type.language', 'locale' => 'form.type.locale', 'money' => 'form.type.money', 'number' => 'form.type.number', 'password' => 'form.type.password', 'percent' => 'form.type.percent', 'radio' => 'form.type.radio', 'repeated' => 'form.type.repeated', 'search' => 'form.type.search', 'textarea' => 'form.type.textarea', 'text' => 'form.type.text', 'time' => 'form.type.time', 'timezone' => 'form.type.timezone', 'url' => 'form.type.url', 'button' => 'form.type.button', 'submit' => 'form.type.submit', 'reset' => 'form.type.reset', 'currency' => 'form.type.currency', 'entity' => 'form.type.entity', 'fos_user_username' => 'fos_user.username_form_type', 'fos_user_profile' => 'fos_user.profile.form.type', 'fos_user_registration' => 'fos_user.registration.form.type', 'fos_user_change_password' => 'fos_user.change_password.form.type', 'fos_user_resetting' => 'fos_user.resetting.form.type', 'easyadmin' => 'easyadmin.form.type', 'sonata_type_immutable_array' => 'sonata.core.form.type.array', 'sonata_type_boolean' => 'sonata.core.form.type.boolean', 'sonata_type_collection' => 'sonata.core.form.type.collection', 'sonata_type_translatable_choice' => 'sonata.core.form.type.translatable_choice', 'sonata_type_date_range' => 'sonata.core.form.type.date_range', 'sonata_type_datetime_range' => 'sonata.core.form.type.datetime_range', 'sonata_type_date_picker' => 'sonata.core.form.type.date_picker', 'sonata_type_datetime_picker' => 'sonata.core.form.type.datetime_picker', 'sonata_type_date_range_picker' => 'sonata.core.form.type.date_range_picker', 'sonata_type_datetime_range_picker' => 'sonata.core.form.type.datetime_range_picker', 'sonata_type_equal' => 'sonata.core.form.type.equal', 'sonata_type_color_selector' => 'sonata.core.form.type.color_selector', 'sonata_block_service_choice' => 'sonata.block.form.type.block', 'sonata_type_container_template_choice' => 'sonata.block.form.type.container_template', 'sonata_type_admin' => 'sonata.admin.form.type.admin', 'sonata_type_model' => 'sonata.admin.form.type.model_choice', 'sonata_type_model_list' => 'sonata.admin.form.type.model_list', 'sonata_type_model_reference' => 'sonata.admin.form.type.model_reference', 'sonata_type_model_hidden' => 'sonata.admin.form.type.model_hidden', 'sonata_type_model_autocomplete' => 'sonata.admin.form.type.model_autocomplete', 'sonata_type_native_collection' => 'sonata.admin.form.type.collection', 'sonata_type_filter_number' => 'sonata.admin.form.filter.type.number', 'sonata_type_filter_choice' => 'sonata.admin.form.filter.type.choice', 'sonata_type_filter_default' => 'sonata.admin.form.filter.type.default', 'sonata_type_filter_date' => 'sonata.admin.form.filter.type.date', 'sonata_type_filter_date_range' => 'sonata.admin.form.filter.type.daterange', 'sonata_type_filter_datetime' => 'sonata.admin.form.filter.type.datetime', 'sonata_type_filter_datetime_range' => 'sonata.admin.form.filter.type.datetime_range'), array('form' => array(0 => 'form.type_extension.form.http_foundation', 1 => 'form.type_extension.form.validator', 2 => 'form.type_extension.csrf', 3 => 'form.type_extension.form.data_collector', 4 => 'easyadmin.form.type.extension', 5 => 'sonata.admin.form.extension.field', 6 => 'sonata.admin.form.extension.field.mopa'), 'repeated' => array(0 => 'form.type_extension.repeated.validator'), 'submit' => array(0 => 'form.type_extension.submit.validator')), array(0 => 'form.type_guesser.validator', 1 => 'form.type_guesser.doctrine'))), $this->get('form.resolved_type_factory'));
    }

    /**
     * Gets the 'form.resolved_type_factory' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\DataCollector\Proxy\ResolvedTypeFactoryDataCollectorProxy A Symfony\Component\Form\Extension\DataCollector\Proxy\ResolvedTypeFactoryDataCollectorProxy instance.
     */
    protected function getForm_ResolvedTypeFactoryService()
    {
        return $this->services['form.resolved_type_factory'] = new \Symfony\Component\Form\Extension\DataCollector\Proxy\ResolvedTypeFactoryDataCollectorProxy(new \Symfony\Component\Form\ResolvedFormTypeFactory(), $this->get('data_collector.form'));
    }

    /**
     * Gets the 'form.type.birthday' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\BirthdayType A Symfony\Component\Form\Extension\Core\Type\BirthdayType instance.
     */
    protected function getForm_Type_BirthdayService()
    {
        return $this->services['form.type.birthday'] = new \Symfony\Component\Form\Extension\Core\Type\BirthdayType();
    }

    /**
     * Gets the 'form.type.button' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\ButtonType A Symfony\Component\Form\Extension\Core\Type\ButtonType instance.
     */
    protected function getForm_Type_ButtonService()
    {
        return $this->services['form.type.button'] = new \Symfony\Component\Form\Extension\Core\Type\ButtonType();
    }

    /**
     * Gets the 'form.type.checkbox' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\CheckboxType A Symfony\Component\Form\Extension\Core\Type\CheckboxType instance.
     */
    protected function getForm_Type_CheckboxService()
    {
        return $this->services['form.type.checkbox'] = new \Symfony\Component\Form\Extension\Core\Type\CheckboxType();
    }

    /**
     * Gets the 'form.type.choice' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\ChoiceType A Symfony\Component\Form\Extension\Core\Type\ChoiceType instance.
     */
    protected function getForm_Type_ChoiceService()
    {
        return $this->services['form.type.choice'] = new \Symfony\Component\Form\Extension\Core\Type\ChoiceType(new \Symfony\Component\Form\ChoiceList\Factory\CachingFactoryDecorator(new \Symfony\Component\Form\ChoiceList\Factory\PropertyAccessDecorator(new \Symfony\Component\Form\ChoiceList\Factory\DefaultChoiceListFactory(), $this->get('property_accessor'))));
    }

    /**
     * Gets the 'form.type.collection' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\CollectionType A Symfony\Component\Form\Extension\Core\Type\CollectionType instance.
     */
    protected function getForm_Type_CollectionService()
    {
        return $this->services['form.type.collection'] = new \Symfony\Component\Form\Extension\Core\Type\CollectionType();
    }

    /**
     * Gets the 'form.type.country' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\CountryType A Symfony\Component\Form\Extension\Core\Type\CountryType instance.
     */
    protected function getForm_Type_CountryService()
    {
        return $this->services['form.type.country'] = new \Symfony\Component\Form\Extension\Core\Type\CountryType();
    }

    /**
     * Gets the 'form.type.currency' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\CurrencyType A Symfony\Component\Form\Extension\Core\Type\CurrencyType instance.
     */
    protected function getForm_Type_CurrencyService()
    {
        return $this->services['form.type.currency'] = new \Symfony\Component\Form\Extension\Core\Type\CurrencyType();
    }

    /**
     * Gets the 'form.type.date' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\DateType A Symfony\Component\Form\Extension\Core\Type\DateType instance.
     */
    protected function getForm_Type_DateService()
    {
        return $this->services['form.type.date'] = new \Symfony\Component\Form\Extension\Core\Type\DateType();
    }

    /**
     * Gets the 'form.type.datetime' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\DateTimeType A Symfony\Component\Form\Extension\Core\Type\DateTimeType instance.
     */
    protected function getForm_Type_DatetimeService()
    {
        return $this->services['form.type.datetime'] = new \Symfony\Component\Form\Extension\Core\Type\DateTimeType();
    }

    /**
     * Gets the 'form.type.email' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\EmailType A Symfony\Component\Form\Extension\Core\Type\EmailType instance.
     */
    protected function getForm_Type_EmailService()
    {
        return $this->services['form.type.email'] = new \Symfony\Component\Form\Extension\Core\Type\EmailType();
    }

    /**
     * Gets the 'form.type.entity' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Doctrine\Form\Type\EntityType A Symfony\Bridge\Doctrine\Form\Type\EntityType instance.
     */
    protected function getForm_Type_EntityService()
    {
        return $this->services['form.type.entity'] = new \Symfony\Bridge\Doctrine\Form\Type\EntityType($this->get('doctrine'));
    }

    /**
     * Gets the 'form.type.file' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\FileType A Symfony\Component\Form\Extension\Core\Type\FileType instance.
     */
    protected function getForm_Type_FileService()
    {
        return $this->services['form.type.file'] = new \Symfony\Component\Form\Extension\Core\Type\FileType();
    }

    /**
     * Gets the 'form.type.form' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\FormType A Symfony\Component\Form\Extension\Core\Type\FormType instance.
     */
    protected function getForm_Type_FormService()
    {
        return $this->services['form.type.form'] = new \Symfony\Component\Form\Extension\Core\Type\FormType($this->get('property_accessor'));
    }

    /**
     * Gets the 'form.type.hidden' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\HiddenType A Symfony\Component\Form\Extension\Core\Type\HiddenType instance.
     */
    protected function getForm_Type_HiddenService()
    {
        return $this->services['form.type.hidden'] = new \Symfony\Component\Form\Extension\Core\Type\HiddenType();
    }

    /**
     * Gets the 'form.type.integer' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\IntegerType A Symfony\Component\Form\Extension\Core\Type\IntegerType instance.
     */
    protected function getForm_Type_IntegerService()
    {
        return $this->services['form.type.integer'] = new \Symfony\Component\Form\Extension\Core\Type\IntegerType();
    }

    /**
     * Gets the 'form.type.language' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\LanguageType A Symfony\Component\Form\Extension\Core\Type\LanguageType instance.
     */
    protected function getForm_Type_LanguageService()
    {
        return $this->services['form.type.language'] = new \Symfony\Component\Form\Extension\Core\Type\LanguageType();
    }

    /**
     * Gets the 'form.type.locale' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\LocaleType A Symfony\Component\Form\Extension\Core\Type\LocaleType instance.
     */
    protected function getForm_Type_LocaleService()
    {
        return $this->services['form.type.locale'] = new \Symfony\Component\Form\Extension\Core\Type\LocaleType();
    }

    /**
     * Gets the 'form.type.money' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\MoneyType A Symfony\Component\Form\Extension\Core\Type\MoneyType instance.
     */
    protected function getForm_Type_MoneyService()
    {
        return $this->services['form.type.money'] = new \Symfony\Component\Form\Extension\Core\Type\MoneyType();
    }

    /**
     * Gets the 'form.type.number' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\NumberType A Symfony\Component\Form\Extension\Core\Type\NumberType instance.
     */
    protected function getForm_Type_NumberService()
    {
        return $this->services['form.type.number'] = new \Symfony\Component\Form\Extension\Core\Type\NumberType();
    }

    /**
     * Gets the 'form.type.password' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\PasswordType A Symfony\Component\Form\Extension\Core\Type\PasswordType instance.
     */
    protected function getForm_Type_PasswordService()
    {
        return $this->services['form.type.password'] = new \Symfony\Component\Form\Extension\Core\Type\PasswordType();
    }

    /**
     * Gets the 'form.type.percent' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\PercentType A Symfony\Component\Form\Extension\Core\Type\PercentType instance.
     */
    protected function getForm_Type_PercentService()
    {
        return $this->services['form.type.percent'] = new \Symfony\Component\Form\Extension\Core\Type\PercentType();
    }

    /**
     * Gets the 'form.type.radio' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\RadioType A Symfony\Component\Form\Extension\Core\Type\RadioType instance.
     */
    protected function getForm_Type_RadioService()
    {
        return $this->services['form.type.radio'] = new \Symfony\Component\Form\Extension\Core\Type\RadioType();
    }

    /**
     * Gets the 'form.type.repeated' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\RepeatedType A Symfony\Component\Form\Extension\Core\Type\RepeatedType instance.
     */
    protected function getForm_Type_RepeatedService()
    {
        return $this->services['form.type.repeated'] = new \Symfony\Component\Form\Extension\Core\Type\RepeatedType();
    }

    /**
     * Gets the 'form.type.reset' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\ResetType A Symfony\Component\Form\Extension\Core\Type\ResetType instance.
     */
    protected function getForm_Type_ResetService()
    {
        return $this->services['form.type.reset'] = new \Symfony\Component\Form\Extension\Core\Type\ResetType();
    }

    /**
     * Gets the 'form.type.search' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\SearchType A Symfony\Component\Form\Extension\Core\Type\SearchType instance.
     */
    protected function getForm_Type_SearchService()
    {
        return $this->services['form.type.search'] = new \Symfony\Component\Form\Extension\Core\Type\SearchType();
    }

    /**
     * Gets the 'form.type.submit' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\SubmitType A Symfony\Component\Form\Extension\Core\Type\SubmitType instance.
     */
    protected function getForm_Type_SubmitService()
    {
        return $this->services['form.type.submit'] = new \Symfony\Component\Form\Extension\Core\Type\SubmitType();
    }

    /**
     * Gets the 'form.type.text' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\TextType A Symfony\Component\Form\Extension\Core\Type\TextType instance.
     */
    protected function getForm_Type_TextService()
    {
        return $this->services['form.type.text'] = new \Symfony\Component\Form\Extension\Core\Type\TextType();
    }

    /**
     * Gets the 'form.type.textarea' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\TextareaType A Symfony\Component\Form\Extension\Core\Type\TextareaType instance.
     */
    protected function getForm_Type_TextareaService()
    {
        return $this->services['form.type.textarea'] = new \Symfony\Component\Form\Extension\Core\Type\TextareaType();
    }

    /**
     * Gets the 'form.type.time' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\TimeType A Symfony\Component\Form\Extension\Core\Type\TimeType instance.
     */
    protected function getForm_Type_TimeService()
    {
        return $this->services['form.type.time'] = new \Symfony\Component\Form\Extension\Core\Type\TimeType();
    }

    /**
     * Gets the 'form.type.timezone' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\TimezoneType A Symfony\Component\Form\Extension\Core\Type\TimezoneType instance.
     */
    protected function getForm_Type_TimezoneService()
    {
        return $this->services['form.type.timezone'] = new \Symfony\Component\Form\Extension\Core\Type\TimezoneType();
    }

    /**
     * Gets the 'form.type.url' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\UrlType A Symfony\Component\Form\Extension\Core\Type\UrlType instance.
     */
    protected function getForm_Type_UrlService()
    {
        return $this->services['form.type.url'] = new \Symfony\Component\Form\Extension\Core\Type\UrlType();
    }

    /**
     * Gets the 'form.type_extension.csrf' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Csrf\Type\FormTypeCsrfExtension A Symfony\Component\Form\Extension\Csrf\Type\FormTypeCsrfExtension instance.
     */
    protected function getForm_TypeExtension_CsrfService()
    {
        return $this->services['form.type_extension.csrf'] = new \Symfony\Component\Form\Extension\Csrf\Type\FormTypeCsrfExtension($this->get('security.csrf.token_manager'), true, '_token', $this->get('translator.default'), 'validators');
    }

    /**
     * Gets the 'form.type_extension.form.data_collector' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\DataCollector\Type\DataCollectorTypeExtension A Symfony\Component\Form\Extension\DataCollector\Type\DataCollectorTypeExtension instance.
     */
    protected function getForm_TypeExtension_Form_DataCollectorService()
    {
        return $this->services['form.type_extension.form.data_collector'] = new \Symfony\Component\Form\Extension\DataCollector\Type\DataCollectorTypeExtension($this->get('data_collector.form'));
    }

    /**
     * Gets the 'form.type_extension.form.http_foundation' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\HttpFoundation\Type\FormTypeHttpFoundationExtension A Symfony\Component\Form\Extension\HttpFoundation\Type\FormTypeHttpFoundationExtension instance.
     */
    protected function getForm_TypeExtension_Form_HttpFoundationService()
    {
        return $this->services['form.type_extension.form.http_foundation'] = new \Symfony\Component\Form\Extension\HttpFoundation\Type\FormTypeHttpFoundationExtension(new \Symfony\Component\Form\Extension\HttpFoundation\HttpFoundationRequestHandler(new \Symfony\Component\Form\Util\ServerParams($this->get('request_stack'))));
    }

    /**
     * Gets the 'form.type_extension.form.validator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Validator\Type\FormTypeValidatorExtension A Symfony\Component\Form\Extension\Validator\Type\FormTypeValidatorExtension instance.
     */
    protected function getForm_TypeExtension_Form_ValidatorService()
    {
        return $this->services['form.type_extension.form.validator'] = new \Symfony\Component\Form\Extension\Validator\Type\FormTypeValidatorExtension($this->get('validator'));
    }

    /**
     * Gets the 'form.type_extension.repeated.validator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Validator\Type\RepeatedTypeValidatorExtension A Symfony\Component\Form\Extension\Validator\Type\RepeatedTypeValidatorExtension instance.
     */
    protected function getForm_TypeExtension_Repeated_ValidatorService()
    {
        return $this->services['form.type_extension.repeated.validator'] = new \Symfony\Component\Form\Extension\Validator\Type\RepeatedTypeValidatorExtension();
    }

    /**
     * Gets the 'form.type_extension.submit.validator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Validator\Type\SubmitTypeValidatorExtension A Symfony\Component\Form\Extension\Validator\Type\SubmitTypeValidatorExtension instance.
     */
    protected function getForm_TypeExtension_Submit_ValidatorService()
    {
        return $this->services['form.type_extension.submit.validator'] = new \Symfony\Component\Form\Extension\Validator\Type\SubmitTypeValidatorExtension();
    }

    /**
     * Gets the 'form.type_guesser.doctrine' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Doctrine\Form\DoctrineOrmTypeGuesser A Symfony\Bridge\Doctrine\Form\DoctrineOrmTypeGuesser instance.
     */
    protected function getForm_TypeGuesser_DoctrineService()
    {
        return $this->services['form.type_guesser.doctrine'] = new \Symfony\Bridge\Doctrine\Form\DoctrineOrmTypeGuesser($this->get('doctrine'));
    }

    /**
     * Gets the 'form.type_guesser.validator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Form\Extension\Validator\ValidatorTypeGuesser A Symfony\Component\Form\Extension\Validator\ValidatorTypeGuesser instance.
     */
    protected function getForm_TypeGuesser_ValidatorService()
    {
        return $this->services['form.type_guesser.validator'] = new \Symfony\Component\Form\Extension\Validator\ValidatorTypeGuesser($this->get('validator'));
    }

    /**
     * Gets the 'fos_user.change_password.form.factory' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Form\Factory\FormFactory A FOS\UserBundle\Form\Factory\FormFactory instance.
     */
    protected function getFosUser_ChangePassword_Form_FactoryService()
    {
        return $this->services['fos_user.change_password.form.factory'] = new \FOS\UserBundle\Form\Factory\FormFactory($this->get('form.factory'), 'fos_user_change_password_form', 'fos_user_change_password', array(0 => 'ChangePassword', 1 => 'Default'));
    }

    /**
     * Gets the 'fos_user.change_password.form.type' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Form\Type\ChangePasswordFormType A FOS\UserBundle\Form\Type\ChangePasswordFormType instance.
     */
    protected function getFosUser_ChangePassword_Form_TypeService()
    {
        return $this->services['fos_user.change_password.form.type'] = new \FOS\UserBundle\Form\Type\ChangePasswordFormType('EdgeWeb\\Project\\UserBundle\\Entity\\User');
    }

    /**
     * Gets the 'fos_user.listener.authentication' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\EventListener\AuthenticationListener A FOS\UserBundle\EventListener\AuthenticationListener instance.
     */
    protected function getFosUser_Listener_AuthenticationService()
    {
        return $this->services['fos_user.listener.authentication'] = new \FOS\UserBundle\EventListener\AuthenticationListener($this->get('fos_user.security.login_manager'), 'main');
    }

    /**
     * Gets the 'fos_user.listener.flash' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\EventListener\FlashListener A FOS\UserBundle\EventListener\FlashListener instance.
     */
    protected function getFosUser_Listener_FlashService()
    {
        return $this->services['fos_user.listener.flash'] = new \FOS\UserBundle\EventListener\FlashListener($this->get('session'), $this->get('translator'));
    }

    /**
     * Gets the 'fos_user.listener.resetting' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\EventListener\ResettingListener A FOS\UserBundle\EventListener\ResettingListener instance.
     */
    protected function getFosUser_Listener_ResettingService()
    {
        return $this->services['fos_user.listener.resetting'] = new \FOS\UserBundle\EventListener\ResettingListener($this->get('router'), 86400);
    }

    /**
     * Gets the 'fos_user.mailer' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Mailer\Mailer A FOS\UserBundle\Mailer\Mailer instance.
     */
    protected function getFosUser_MailerService()
    {
        return $this->services['fos_user.mailer'] = new \FOS\UserBundle\Mailer\Mailer($this->get('swiftmailer.mailer.default'), $this->get('router'), $this->get('templating'), array('confirmation.template' => 'FOSUserBundle:Registration:email.txt.twig', 'resetting.template' => 'FOSUserBundle:Resetting:email.txt.twig', 'from_email' => array('confirmation' => array('webmaster@example.com' => 'webmaster'), 'resetting' => array('webmaster@example.com' => 'webmaster'))));
    }

    /**
     * Gets the 'fos_user.profile.form.factory' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Form\Factory\FormFactory A FOS\UserBundle\Form\Factory\FormFactory instance.
     */
    protected function getFosUser_Profile_Form_FactoryService()
    {
        return $this->services['fos_user.profile.form.factory'] = new \FOS\UserBundle\Form\Factory\FormFactory($this->get('form.factory'), 'fos_user_profile_form', 'app_user_profile', array(0 => 'Profile', 1 => 'Default'));
    }

    /**
     * Gets the 'fos_user.profile.form.type' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Form\Type\ProfileFormType A FOS\UserBundle\Form\Type\ProfileFormType instance.
     */
    protected function getFosUser_Profile_Form_TypeService()
    {
        return $this->services['fos_user.profile.form.type'] = new \FOS\UserBundle\Form\Type\ProfileFormType('EdgeWeb\\Project\\UserBundle\\Entity\\User');
    }

    /**
     * Gets the 'fos_user.registration.form.factory' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Form\Factory\FormFactory A FOS\UserBundle\Form\Factory\FormFactory instance.
     */
    protected function getFosUser_Registration_Form_FactoryService()
    {
        return $this->services['fos_user.registration.form.factory'] = new \FOS\UserBundle\Form\Factory\FormFactory($this->get('form.factory'), 'fos_user_registration_form', 'app_user_registration', array(0 => 'Registration', 1 => 'Default'));
    }

    /**
     * Gets the 'fos_user.registration.form.type' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Form\Type\RegistrationFormType A FOS\UserBundle\Form\Type\RegistrationFormType instance.
     */
    protected function getFosUser_Registration_Form_TypeService()
    {
        return $this->services['fos_user.registration.form.type'] = new \FOS\UserBundle\Form\Type\RegistrationFormType('EdgeWeb\\Project\\UserBundle\\Entity\\User');
    }

    /**
     * Gets the 'fos_user.resetting.form.factory' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Form\Factory\FormFactory A FOS\UserBundle\Form\Factory\FormFactory instance.
     */
    protected function getFosUser_Resetting_Form_FactoryService()
    {
        return $this->services['fos_user.resetting.form.factory'] = new \FOS\UserBundle\Form\Factory\FormFactory($this->get('form.factory'), 'fos_user_resetting_form', 'fos_user_resetting', array(0 => 'ResetPassword', 1 => 'Default'));
    }

    /**
     * Gets the 'fos_user.resetting.form.type' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Form\Type\ResettingFormType A FOS\UserBundle\Form\Type\ResettingFormType instance.
     */
    protected function getFosUser_Resetting_Form_TypeService()
    {
        return $this->services['fos_user.resetting.form.type'] = new \FOS\UserBundle\Form\Type\ResettingFormType('EdgeWeb\\Project\\UserBundle\\Entity\\User');
    }

    /**
     * Gets the 'fos_user.security.interactive_login_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\EventListener\LastLoginListener A FOS\UserBundle\EventListener\LastLoginListener instance.
     */
    protected function getFosUser_Security_InteractiveLoginListenerService()
    {
        return $this->services['fos_user.security.interactive_login_listener'] = new \FOS\UserBundle\EventListener\LastLoginListener($this->get('fos_user.user_manager'));
    }

    /**
     * Gets the 'fos_user.security.login_manager' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Security\LoginManager A FOS\UserBundle\Security\LoginManager instance.
     */
    protected function getFosUser_Security_LoginManagerService()
    {
        return $this->services['fos_user.security.login_manager'] = new \FOS\UserBundle\Security\LoginManager($this->get('security.token_storage'), $this->get('security.user_checker'), $this->get('security.authentication.session_strategy'), $this);
    }

    /**
     * Gets the 'fos_user.user_manager' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Doctrine\UserManager A FOS\UserBundle\Doctrine\UserManager instance.
     */
    protected function getFosUser_UserManagerService()
    {
        $a = $this->get('fos_user.util.email_canonicalizer');

        return $this->services['fos_user.user_manager'] = new \FOS\UserBundle\Doctrine\UserManager($this->get('security.encoder_factory'), $a, $a, $this->get('doctrine')->getManager(NULL), 'EdgeWeb\\Project\\UserBundle\\Entity\\User');
    }

    /**
     * Gets the 'fos_user.username_form_type' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Form\Type\UsernameFormType A FOS\UserBundle\Form\Type\UsernameFormType instance.
     */
    protected function getFosUser_UsernameFormTypeService()
    {
        return $this->services['fos_user.username_form_type'] = new \FOS\UserBundle\Form\Type\UsernameFormType(new \FOS\UserBundle\Form\DataTransformer\UserToUsernameTransformer($this->get('fos_user.user_manager')));
    }

    /**
     * Gets the 'fos_user.util.email_canonicalizer' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Util\Canonicalizer A FOS\UserBundle\Util\Canonicalizer instance.
     */
    protected function getFosUser_Util_EmailCanonicalizerService()
    {
        return $this->services['fos_user.util.email_canonicalizer'] = new \FOS\UserBundle\Util\Canonicalizer();
    }

    /**
     * Gets the 'fos_user.util.token_generator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Util\TokenGenerator A FOS\UserBundle\Util\TokenGenerator instance.
     */
    protected function getFosUser_Util_TokenGeneratorService()
    {
        return $this->services['fos_user.util.token_generator'] = new \FOS\UserBundle\Util\TokenGenerator($this->get('logger', ContainerInterface::NULL_ON_INVALID_REFERENCE));
    }

    /**
     * Gets the 'fos_user.util.user_manipulator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \FOS\UserBundle\Util\UserManipulator A FOS\UserBundle\Util\UserManipulator instance.
     */
    protected function getFosUser_Util_UserManipulatorService()
    {
        return $this->services['fos_user.util.user_manipulator'] = new \FOS\UserBundle\Util\UserManipulator($this->get('fos_user.user_manager'));
    }

    /**
     * Gets the 'fragment.handler' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\DependencyInjection\LazyLoadingFragmentHandler A Symfony\Component\HttpKernel\DependencyInjection\LazyLoadingFragmentHandler instance.
     */
    protected function getFragment_HandlerService()
    {
        $this->services['fragment.handler'] = $instance = new \Symfony\Component\HttpKernel\DependencyInjection\LazyLoadingFragmentHandler($this, true, $this->get('request_stack'));

        $instance->addRendererService('inline', 'fragment.renderer.inline');
        $instance->addRendererService('hinclude', 'fragment.renderer.hinclude');
        $instance->addRendererService('hinclude', 'fragment.renderer.hinclude');
        $instance->addRendererService('esi', 'fragment.renderer.esi');
        $instance->addRendererService('ssi', 'fragment.renderer.ssi');

        return $instance;
    }

    /**
     * Gets the 'fragment.listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\FragmentListener A Symfony\Component\HttpKernel\EventListener\FragmentListener instance.
     */
    protected function getFragment_ListenerService()
    {
        return $this->services['fragment.listener'] = new \Symfony\Component\HttpKernel\EventListener\FragmentListener($this->get('uri_signer'), '/_fragment');
    }

    /**
     * Gets the 'fragment.renderer.esi' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\Fragment\EsiFragmentRenderer A Symfony\Component\HttpKernel\Fragment\EsiFragmentRenderer instance.
     */
    protected function getFragment_Renderer_EsiService()
    {
        $this->services['fragment.renderer.esi'] = $instance = new \Symfony\Component\HttpKernel\Fragment\EsiFragmentRenderer(NULL, $this->get('fragment.renderer.inline'), $this->get('uri_signer'));

        $instance->setFragmentPath('/_fragment');

        return $instance;
    }

    /**
     * Gets the 'fragment.renderer.hinclude' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\Fragment\HIncludeFragmentRenderer A Symfony\Component\HttpKernel\Fragment\HIncludeFragmentRenderer instance.
     */
    protected function getFragment_Renderer_HincludeService()
    {
        $this->services['fragment.renderer.hinclude'] = $instance = new \Symfony\Component\HttpKernel\Fragment\HIncludeFragmentRenderer($this->get('twig'), $this->get('uri_signer'), NULL);

        $instance->setFragmentPath('/_fragment');

        return $instance;
    }

    /**
     * Gets the 'fragment.renderer.inline' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\Fragment\InlineFragmentRenderer A Symfony\Component\HttpKernel\Fragment\InlineFragmentRenderer instance.
     */
    protected function getFragment_Renderer_InlineService()
    {
        $this->services['fragment.renderer.inline'] = $instance = new \Symfony\Component\HttpKernel\Fragment\InlineFragmentRenderer($this->get('http_kernel'), $this->get('debug.event_dispatcher'));

        $instance->setFragmentPath('/_fragment');

        return $instance;
    }

    /**
     * Gets the 'fragment.renderer.ssi' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\Fragment\SsiFragmentRenderer A Symfony\Component\HttpKernel\Fragment\SsiFragmentRenderer instance.
     */
    protected function getFragment_Renderer_SsiService()
    {
        $this->services['fragment.renderer.ssi'] = $instance = new \Symfony\Component\HttpKernel\Fragment\SsiFragmentRenderer(NULL, $this->get('fragment.renderer.inline'), $this->get('uri_signer'));

        $instance->setFragmentPath('/_fragment');

        return $instance;
    }

    /**
     * Gets the 'http_kernel' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\DependencyInjection\ContainerAwareHttpKernel A Symfony\Component\HttpKernel\DependencyInjection\ContainerAwareHttpKernel instance.
     */
    protected function getHttpKernelService()
    {
        return $this->services['http_kernel'] = new \Symfony\Component\HttpKernel\DependencyInjection\ContainerAwareHttpKernel($this->get('debug.event_dispatcher'), $this, $this->get('debug.controller_resolver'), $this->get('request_stack'), false);
    }

    /**
     * Gets the 'jms_serializer' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\Serializer A JMS\Serializer\Serializer instance.
     */
    protected function getJmsSerializerService()
    {
        $a = new \Metadata\MetadataFactory(new \Metadata\Driver\LazyLoadingDriver($this, 'jms_serializer.metadata_driver'), 'Metadata\\ClassHierarchyMetadata', true);
        $a->setCache(new \Metadata\Cache\FileCache((__DIR__.'/jms_serializer')));

        $b = new \JMS\Serializer\EventDispatcher\LazyEventDispatcher($this);
        $b->setListeners(array('serializer.pre_serialize' => array(0 => array(0 => array(0 => 'jms_serializer.stopwatch_subscriber', 1 => 'onPreSerialize'), 1 => NULL, 2 => NULL), 1 => array(0 => array(0 => 'jms_serializer.doctrine_proxy_subscriber', 1 => 'onPreSerialize'), 1 => NULL, 2 => NULL)), 'serializer.post_serialize' => array(0 => array(0 => array(0 => 'jms_serializer.stopwatch_subscriber', 1 => 'onPostSerialize'), 1 => NULL, 2 => NULL))));

        return $this->services['jms_serializer'] = new \JMS\Serializer\Serializer($a, $this->get('jms_serializer.handler_registry'), $this->get('jms_serializer.unserialize_object_constructor'), new \PhpCollection\Map(array('json' => $this->get('jms_serializer.json_serialization_visitor'), 'xml' => $this->get('jms_serializer.xml_serialization_visitor'), 'yml' => $this->get('jms_serializer.yaml_serialization_visitor'))), new \PhpCollection\Map(array('json' => $this->get('jms_serializer.json_deserialization_visitor'), 'xml' => $this->get('jms_serializer.xml_deserialization_visitor'))), $b);
    }

    /**
     * Gets the 'jms_serializer.array_collection_handler' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\Handler\ArrayCollectionHandler A JMS\Serializer\Handler\ArrayCollectionHandler instance.
     */
    protected function getJmsSerializer_ArrayCollectionHandlerService()
    {
        return $this->services['jms_serializer.array_collection_handler'] = new \JMS\Serializer\Handler\ArrayCollectionHandler();
    }

    /**
     * Gets the 'jms_serializer.constraint_violation_handler' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\Handler\ConstraintViolationHandler A JMS\Serializer\Handler\ConstraintViolationHandler instance.
     */
    protected function getJmsSerializer_ConstraintViolationHandlerService()
    {
        return $this->services['jms_serializer.constraint_violation_handler'] = new \JMS\Serializer\Handler\ConstraintViolationHandler();
    }

    /**
     * Gets the 'jms_serializer.datetime_handler' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\Handler\DateHandler A JMS\Serializer\Handler\DateHandler instance.
     */
    protected function getJmsSerializer_DatetimeHandlerService()
    {
        return $this->services['jms_serializer.datetime_handler'] = new \JMS\Serializer\Handler\DateHandler('Y-m-d\\TH:i:sO', 'Asia/Manila', true);
    }

    /**
     * Gets the 'jms_serializer.doctrine_proxy_subscriber' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\EventDispatcher\Subscriber\DoctrineProxySubscriber A JMS\Serializer\EventDispatcher\Subscriber\DoctrineProxySubscriber instance.
     */
    protected function getJmsSerializer_DoctrineProxySubscriberService()
    {
        return $this->services['jms_serializer.doctrine_proxy_subscriber'] = new \JMS\Serializer\EventDispatcher\Subscriber\DoctrineProxySubscriber();
    }

    /**
     * Gets the 'jms_serializer.form_error_handler' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\Handler\FormErrorHandler A JMS\Serializer\Handler\FormErrorHandler instance.
     */
    protected function getJmsSerializer_FormErrorHandlerService()
    {
        return $this->services['jms_serializer.form_error_handler'] = new \JMS\Serializer\Handler\FormErrorHandler($this->get('translator'));
    }

    /**
     * Gets the 'jms_serializer.handler_registry' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\Handler\LazyHandlerRegistry A JMS\Serializer\Handler\LazyHandlerRegistry instance.
     */
    protected function getJmsSerializer_HandlerRegistryService()
    {
        return $this->services['jms_serializer.handler_registry'] = new \JMS\Serializer\Handler\LazyHandlerRegistry($this, array(2 => array('DateTime' => array('json' => array(0 => 'jms_serializer.datetime_handler', 1 => 'deserializeDateTimeFromjson'), 'xml' => array(0 => 'jms_serializer.datetime_handler', 1 => 'deserializeDateTimeFromxml'), 'yml' => array(0 => 'jms_serializer.datetime_handler', 1 => 'deserializeDateTimeFromyml')), 'ArrayCollection' => array('json' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection'), 'xml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection'), 'yml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection')), 'Doctrine\\Common\\Collections\\ArrayCollection' => array('json' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection'), 'xml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection'), 'yml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection')), 'Doctrine\\ORM\\PersistentCollection' => array('json' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection'), 'xml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection'), 'yml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection')), 'Doctrine\\ODM\\MongoDB\\PersistentCollection' => array('json' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection'), 'xml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection'), 'yml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection')), 'Doctrine\\ODM\\PHPCR\\PersistentCollection' => array('json' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection'), 'xml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection'), 'yml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'deserializeCollection')), 'PhpCollection\\Sequence' => array('json' => array(0 => 'jms_serializer.php_collection_handler', 1 => 'deserializeSequence'), 'xml' => array(0 => 'jms_serializer.php_collection_handler', 1 => 'deserializeSequence'), 'yml' => array(0 => 'jms_serializer.php_collection_handler', 1 => 'deserializeSequence')), 'PhpCollection\\Map' => array('json' => array(0 => 'jms_serializer.php_collection_handler', 1 => 'deserializeMap'), 'xml' => array(0 => 'jms_serializer.php_collection_handler', 1 => 'deserializeMap'), 'yml' => array(0 => 'jms_serializer.php_collection_handler', 1 => 'deserializeMap'))), 1 => array('DateTime' => array('json' => array(0 => 'jms_serializer.datetime_handler', 1 => 'serializeDateTime'), 'xml' => array(0 => 'jms_serializer.datetime_handler', 1 => 'serializeDateTime'), 'yml' => array(0 => 'jms_serializer.datetime_handler', 1 => 'serializeDateTime')), 'DateInterval' => array('json' => array(0 => 'jms_serializer.datetime_handler', 1 => 'serializeDateInterval'), 'xml' => array(0 => 'jms_serializer.datetime_handler', 1 => 'serializeDateInterval'), 'yml' => array(0 => 'jms_serializer.datetime_handler', 1 => 'serializeDateInterval')), 'ArrayCollection' => array('json' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection'), 'xml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection'), 'yml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection')), 'Doctrine\\Common\\Collections\\ArrayCollection' => array('json' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection'), 'xml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection'), 'yml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection')), 'Doctrine\\ORM\\PersistentCollection' => array('json' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection'), 'xml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection'), 'yml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection')), 'Doctrine\\ODM\\MongoDB\\PersistentCollection' => array('json' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection'), 'xml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection'), 'yml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection')), 'Doctrine\\ODM\\PHPCR\\PersistentCollection' => array('json' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection'), 'xml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection'), 'yml' => array(0 => 'jms_serializer.array_collection_handler', 1 => 'serializeCollection')), 'PhpCollection\\Sequence' => array('json' => array(0 => 'jms_serializer.php_collection_handler', 1 => 'serializeSequence'), 'xml' => array(0 => 'jms_serializer.php_collection_handler', 1 => 'serializeSequence'), 'yml' => array(0 => 'jms_serializer.php_collection_handler', 1 => 'serializeSequence')), 'PhpCollection\\Map' => array('json' => array(0 => 'jms_serializer.php_collection_handler', 1 => 'serializeMap'), 'xml' => array(0 => 'jms_serializer.php_collection_handler', 1 => 'serializeMap'), 'yml' => array(0 => 'jms_serializer.php_collection_handler', 1 => 'serializeMap')), 'Symfony\\Component\\Form\\Form' => array('xml' => array(0 => 'jms_serializer.form_error_handler', 1 => 'serializeFormToxml'), 'json' => array(0 => 'jms_serializer.form_error_handler', 1 => 'serializeFormTojson'), 'yml' => array(0 => 'jms_serializer.form_error_handler', 1 => 'serializeFormToyml')), 'Symfony\\Component\\Form\\FormError' => array('xml' => array(0 => 'jms_serializer.form_error_handler', 1 => 'serializeFormErrorToxml'), 'json' => array(0 => 'jms_serializer.form_error_handler', 1 => 'serializeFormErrorTojson'), 'yml' => array(0 => 'jms_serializer.form_error_handler', 1 => 'serializeFormErrorToyml')), 'Symfony\\Component\\Validator\\ConstraintViolationList' => array('xml' => array(0 => 'jms_serializer.constraint_violation_handler', 1 => 'serializeListToxml'), 'json' => array(0 => 'jms_serializer.constraint_violation_handler', 1 => 'serializeListTojson'), 'yml' => array(0 => 'jms_serializer.constraint_violation_handler', 1 => 'serializeListToyml')), 'Symfony\\Component\\Validator\\ConstraintViolation' => array('xml' => array(0 => 'jms_serializer.constraint_violation_handler', 1 => 'serializeViolationToxml'), 'json' => array(0 => 'jms_serializer.constraint_violation_handler', 1 => 'serializeViolationTojson'), 'yml' => array(0 => 'jms_serializer.constraint_violation_handler', 1 => 'serializeViolationToyml')))));
    }

    /**
     * Gets the 'jms_serializer.json_deserialization_visitor' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\JsonDeserializationVisitor A JMS\Serializer\JsonDeserializationVisitor instance.
     */
    protected function getJmsSerializer_JsonDeserializationVisitorService()
    {
        return $this->services['jms_serializer.json_deserialization_visitor'] = new \JMS\Serializer\JsonDeserializationVisitor($this->get('jms_serializer.naming_strategy'), $this->get('jms_serializer.unserialize_object_constructor'));
    }

    /**
     * Gets the 'jms_serializer.json_serialization_visitor' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\JsonSerializationVisitor A JMS\Serializer\JsonSerializationVisitor instance.
     */
    protected function getJmsSerializer_JsonSerializationVisitorService()
    {
        $this->services['jms_serializer.json_serialization_visitor'] = $instance = new \JMS\Serializer\JsonSerializationVisitor($this->get('jms_serializer.naming_strategy'));

        $instance->setOptions(0);

        return $instance;
    }

    /**
     * Gets the 'jms_serializer.metadata_driver' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\Metadata\Driver\DoctrineTypeDriver A JMS\Serializer\Metadata\Driver\DoctrineTypeDriver instance.
     */
    protected function getJmsSerializer_MetadataDriverService()
    {
        $a = new \Metadata\Driver\FileLocator(array('Symfony\\Bundle\\FrameworkBundle' => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle/Resources/config/serializer'), 'Symfony\\Bundle\\SecurityBundle' => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\SecurityBundle/Resources/config/serializer'), 'Symfony\\Bundle\\TwigBundle' => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/config/serializer'), 'Symfony\\Bundle\\MonologBundle' => ($this->targetDirs[3].'\\vendor\\symfony\\monolog-bundle/Resources/config/serializer'), 'Symfony\\Bundle\\SwiftmailerBundle' => ($this->targetDirs[3].'\\vendor\\symfony\\swiftmailer-bundle/Resources/config/serializer'), 'Symfony\\Bundle\\AsseticBundle' => ($this->targetDirs[3].'\\vendor\\symfony\\assetic-bundle/Resources/config/serializer'), 'Doctrine\\Bundle\\DoctrineBundle' => ($this->targetDirs[3].'\\vendor\\doctrine\\doctrine-bundle/Resources/config/serializer'), 'Sensio\\Bundle\\FrameworkExtraBundle' => ($this->targetDirs[3].'\\vendor\\sensio\\framework-extra-bundle/Resources/config/serializer'), 'AppBundle' => ($this->targetDirs[3].'\\src\\AppBundle/Resources/config/serializer'), 'JMS\\SerializerBundle' => ($this->targetDirs[3].'\\vendor\\jms\\serializer-bundle\\JMS\\SerializerBundle/Resources/config/serializer'), 'EdgeWeb\\Project\\EmployeeBundle' => ($this->targetDirs[3].'\\src\\EdgeWeb\\Project\\EmployeeBundle/Resources/config/serializer'), 'Stof\\DoctrineExtensionsBundle' => ($this->targetDirs[3].'\\vendor\\stof\\doctrine-extensions-bundle/Resources/config/serializer'), 'FOS\\UserBundle' => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/config/serializer'), 'EdgeWeb\\Project\\UserBundle' => ($this->targetDirs[3].'\\src\\EdgeWeb\\Project\\UserBundle/Resources/config/serializer'), 'JavierEguiluz\\Bundle\\EasyAdminBundle' => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/config/serializer'), 'Knp\\DoctrineBehaviors\\Bundle' => ($this->targetDirs[3].'\\vendor\\knplabs\\doctrine-behaviors\\src\\Bundle/Resources/config/serializer'), 'Sonata\\CoreBundle' => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/config/serializer'), 'Sonata\\BlockBundle' => ($this->targetDirs[3].'\\vendor\\sonata-project\\block-bundle/Resources/config/serializer'), 'Knp\\Bundle\\MenuBundle' => ($this->targetDirs[3].'\\vendor\\knplabs\\knp-menu-bundle/Resources/config/serializer'), 'Sonata\\DoctrineORMAdminBundle' => ($this->targetDirs[3].'\\vendor\\sonata-project\\doctrine-orm-admin-bundle/Resources/config/serializer'), 'Sonata\\AdminBundle' => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/config/serializer'), 'Knp\\Bundle\\PaginatorBundle' => ($this->targetDirs[3].'\\vendor\\knplabs\\knp-paginator-bundle/Resources/config/serializer'), 'EdgeWeb\\Project\\PaycomBundle' => ($this->targetDirs[3].'\\src\\EdgeWeb\\Project\\PaycomBundle/Resources/config/serializer'), 'Symfony\\Bundle\\DebugBundle' => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\DebugBundle/Resources/config/serializer'), 'Symfony\\Bundle\\WebProfilerBundle' => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/config/serializer'), 'Sensio\\Bundle\\DistributionBundle' => ($this->targetDirs[3].'\\vendor\\sensio\\distribution-bundle\\Sensio\\Bundle\\DistributionBundle/Resources/config/serializer'), 'Sensio\\Bundle\\GeneratorBundle' => ($this->targetDirs[3].'\\vendor\\sensio\\generator-bundle\\Sensio\\Bundle\\GeneratorBundle/Resources/config/serializer')));

        return $this->services['jms_serializer.metadata_driver'] = new \JMS\Serializer\Metadata\Driver\DoctrineTypeDriver(new \Metadata\Driver\DriverChain(array(0 => new \JMS\Serializer\Metadata\Driver\YamlDriver($a), 1 => new \JMS\Serializer\Metadata\Driver\XmlDriver($a), 2 => new \JMS\Serializer\Metadata\Driver\PhpDriver($a), 3 => new \JMS\Serializer\Metadata\Driver\AnnotationDriver($this->get('annotation_reader')))), $this->get('doctrine'));
    }

    /**
     * Gets the 'jms_serializer.naming_strategy' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\Naming\CacheNamingStrategy A JMS\Serializer\Naming\CacheNamingStrategy instance.
     */
    protected function getJmsSerializer_NamingStrategyService()
    {
        return $this->services['jms_serializer.naming_strategy'] = new \JMS\Serializer\Naming\CacheNamingStrategy(new \JMS\Serializer\Naming\SerializedNameAnnotationStrategy(new \JMS\Serializer\Naming\CamelCaseNamingStrategy('_', true)));
    }

    /**
     * Gets the 'jms_serializer.object_constructor' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\Construction\DoctrineObjectConstructor A JMS\Serializer\Construction\DoctrineObjectConstructor instance.
     */
    protected function getJmsSerializer_ObjectConstructorService()
    {
        return $this->services['jms_serializer.object_constructor'] = new \JMS\Serializer\Construction\DoctrineObjectConstructor($this->get('doctrine'), $this->get('jms_serializer.unserialize_object_constructor'));
    }

    /**
     * Gets the 'jms_serializer.php_collection_handler' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\Handler\PhpCollectionHandler A JMS\Serializer\Handler\PhpCollectionHandler instance.
     */
    protected function getJmsSerializer_PhpCollectionHandlerService()
    {
        return $this->services['jms_serializer.php_collection_handler'] = new \JMS\Serializer\Handler\PhpCollectionHandler();
    }

    /**
     * Gets the 'jms_serializer.stopwatch_subscriber' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\SerializerBundle\Serializer\StopwatchEventSubscriber A JMS\SerializerBundle\Serializer\StopwatchEventSubscriber instance.
     */
    protected function getJmsSerializer_StopwatchSubscriberService()
    {
        return $this->services['jms_serializer.stopwatch_subscriber'] = new \JMS\SerializerBundle\Serializer\StopwatchEventSubscriber($this->get('debug.stopwatch'));
    }

    /**
     * Gets the 'jms_serializer.templating.helper.serializer' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\SerializerBundle\Templating\SerializerHelper A JMS\SerializerBundle\Templating\SerializerHelper instance.
     */
    protected function getJmsSerializer_Templating_Helper_SerializerService()
    {
        return $this->services['jms_serializer.templating.helper.serializer'] = new \JMS\SerializerBundle\Templating\SerializerHelper($this->get('jms_serializer'));
    }

    /**
     * Gets the 'jms_serializer.xml_deserialization_visitor' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\XmlDeserializationVisitor A JMS\Serializer\XmlDeserializationVisitor instance.
     */
    protected function getJmsSerializer_XmlDeserializationVisitorService()
    {
        $this->services['jms_serializer.xml_deserialization_visitor'] = $instance = new \JMS\Serializer\XmlDeserializationVisitor($this->get('jms_serializer.naming_strategy'), $this->get('jms_serializer.unserialize_object_constructor'));

        $instance->setDoctypeWhitelist(array());

        return $instance;
    }

    /**
     * Gets the 'jms_serializer.xml_serialization_visitor' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\XmlSerializationVisitor A JMS\Serializer\XmlSerializationVisitor instance.
     */
    protected function getJmsSerializer_XmlSerializationVisitorService()
    {
        return $this->services['jms_serializer.xml_serialization_visitor'] = new \JMS\Serializer\XmlSerializationVisitor($this->get('jms_serializer.naming_strategy'));
    }

    /**
     * Gets the 'jms_serializer.yaml_serialization_visitor' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \JMS\Serializer\YamlSerializationVisitor A JMS\Serializer\YamlSerializationVisitor instance.
     */
    protected function getJmsSerializer_YamlSerializationVisitorService()
    {
        return $this->services['jms_serializer.yaml_serialization_visitor'] = new \JMS\Serializer\YamlSerializationVisitor($this->get('jms_serializer.naming_strategy'));
    }

    /**
     * Gets the 'kernel' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @throws RuntimeException always since this service is expected to be injected dynamically
     */
    protected function getKernelService()
    {
        throw new RuntimeException('You have requested a synthetic service ("kernel"). The DIC does not know how to construct this service.');
    }

    /**
     * Gets the 'knp_menu.factory' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Menu\MenuFactory A Knp\Menu\MenuFactory instance.
     */
    protected function getKnpMenu_FactoryService()
    {
        $this->services['knp_menu.factory'] = $instance = new \Knp\Menu\MenuFactory();

        $instance->addExtension(new \Knp\Menu\Integration\Symfony\RoutingExtension($this->get('router')), 0);

        return $instance;
    }

    /**
     * Gets the 'knp_menu.listener.voters' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Bundle\MenuBundle\EventListener\VoterInitializerListener A Knp\Bundle\MenuBundle\EventListener\VoterInitializerListener instance.
     */
    protected function getKnpMenu_Listener_VotersService()
    {
        $this->services['knp_menu.listener.voters'] = $instance = new \Knp\Bundle\MenuBundle\EventListener\VoterInitializerListener();

        $instance->addVoter($this->get('knp_menu.voter.router'));

        return $instance;
    }

    /**
     * Gets the 'knp_menu.matcher' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Menu\Matcher\Matcher A Knp\Menu\Matcher\Matcher instance.
     */
    protected function getKnpMenu_MatcherService()
    {
        $this->services['knp_menu.matcher'] = $instance = new \Knp\Menu\Matcher\Matcher();

        $instance->addVoter($this->get('knp_menu.voter.router'));

        return $instance;
    }

    /**
     * Gets the 'knp_menu.menu_provider' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Menu\Provider\ChainProvider A Knp\Menu\Provider\ChainProvider instance.
     */
    protected function getKnpMenu_MenuProviderService()
    {
        return $this->services['knp_menu.menu_provider'] = new \Knp\Menu\Provider\ChainProvider(array(0 => new \Knp\Bundle\MenuBundle\Provider\ContainerAwareProvider($this, array()), 1 => new \Knp\Bundle\MenuBundle\Provider\BuilderServiceProvider($this, array()), 2 => new \Knp\Bundle\MenuBundle\Provider\BuilderAliasProvider($this->get('kernel'), $this, $this->get('knp_menu.factory'))));
    }

    /**
     * Gets the 'knp_menu.renderer.list' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Menu\Renderer\ListRenderer A Knp\Menu\Renderer\ListRenderer instance.
     */
    protected function getKnpMenu_Renderer_ListService()
    {
        return $this->services['knp_menu.renderer.list'] = new \Knp\Menu\Renderer\ListRenderer($this->get('knp_menu.matcher'), array(), 'UTF-8');
    }

    /**
     * Gets the 'knp_menu.renderer.twig' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Menu\Renderer\TwigRenderer A Knp\Menu\Renderer\TwigRenderer instance.
     */
    protected function getKnpMenu_Renderer_TwigService()
    {
        return $this->services['knp_menu.renderer.twig'] = new \Knp\Menu\Renderer\TwigRenderer($this->get('twig'), 'knp_menu.html.twig', $this->get('knp_menu.matcher'), array());
    }

    /**
     * Gets the 'knp_menu.renderer_provider' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Bundle\MenuBundle\Renderer\ContainerAwareProvider A Knp\Bundle\MenuBundle\Renderer\ContainerAwareProvider instance.
     */
    protected function getKnpMenu_RendererProviderService()
    {
        return $this->services['knp_menu.renderer_provider'] = new \Knp\Bundle\MenuBundle\Renderer\ContainerAwareProvider($this, 'twig', array('list' => 'knp_menu.renderer.list', 'twig' => 'knp_menu.renderer.twig'));
    }

    /**
     * Gets the 'knp_menu.voter.router' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Menu\Matcher\Voter\RouteVoter A Knp\Menu\Matcher\Voter\RouteVoter instance.
     */
    protected function getKnpMenu_Voter_RouterService()
    {
        return $this->services['knp_menu.voter.router'] = new \Knp\Menu\Matcher\Voter\RouteVoter();
    }

    /**
     * Gets the 'knp_paginator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Component\Pager\Paginator A Knp\Component\Pager\Paginator instance.
     */
    protected function getKnpPaginatorService()
    {
        $this->services['knp_paginator'] = $instance = new \Knp\Component\Pager\Paginator($this->get('debug.event_dispatcher'));

        $instance->setDefaultPaginatorOptions(array('pageParameterName' => 'page', 'sortFieldParameterName' => 'sort', 'sortDirectionParameterName' => 'direction', 'filterFieldParameterName' => 'filterField', 'filterValueParameterName' => 'filterValue', 'distinct' => true));

        return $instance;
    }

    /**
     * Gets the 'knp_paginator.helper.processor' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Bundle\PaginatorBundle\Helper\Processor A Knp\Bundle\PaginatorBundle\Helper\Processor instance.
     */
    protected function getKnpPaginator_Helper_ProcessorService()
    {
        return $this->services['knp_paginator.helper.processor'] = new \Knp\Bundle\PaginatorBundle\Helper\Processor($this->get('router'), $this->get('translator'));
    }

    /**
     * Gets the 'knp_paginator.subscriber.filtration' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Component\Pager\Event\Subscriber\Filtration\FiltrationSubscriber A Knp\Component\Pager\Event\Subscriber\Filtration\FiltrationSubscriber instance.
     */
    protected function getKnpPaginator_Subscriber_FiltrationService()
    {
        return $this->services['knp_paginator.subscriber.filtration'] = new \Knp\Component\Pager\Event\Subscriber\Filtration\FiltrationSubscriber();
    }

    /**
     * Gets the 'knp_paginator.subscriber.paginate' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Component\Pager\Event\Subscriber\Paginate\PaginationSubscriber A Knp\Component\Pager\Event\Subscriber\Paginate\PaginationSubscriber instance.
     */
    protected function getKnpPaginator_Subscriber_PaginateService()
    {
        return $this->services['knp_paginator.subscriber.paginate'] = new \Knp\Component\Pager\Event\Subscriber\Paginate\PaginationSubscriber();
    }

    /**
     * Gets the 'knp_paginator.subscriber.sliding_pagination' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Bundle\PaginatorBundle\Subscriber\SlidingPaginationSubscriber A Knp\Bundle\PaginatorBundle\Subscriber\SlidingPaginationSubscriber instance.
     */
    protected function getKnpPaginator_Subscriber_SlidingPaginationService()
    {
        return $this->services['knp_paginator.subscriber.sliding_pagination'] = new \Knp\Bundle\PaginatorBundle\Subscriber\SlidingPaginationSubscriber(array('defaultPaginationTemplate' => 'KnpPaginatorBundle:Pagination:twitter_bootstrap_v3_pagination.html.twig', 'defaultSortableTemplate' => 'KnpPaginatorBundle:Pagination:sortable_link.html.twig', 'defaultFiltrationTemplate' => 'KnpPaginatorBundle:Pagination:filtration.html.twig', 'defaultPageRange' => 5));
    }

    /**
     * Gets the 'knp_paginator.subscriber.sortable' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Component\Pager\Event\Subscriber\Sortable\SortableSubscriber A Knp\Component\Pager\Event\Subscriber\Sortable\SortableSubscriber instance.
     */
    protected function getKnpPaginator_Subscriber_SortableService()
    {
        return $this->services['knp_paginator.subscriber.sortable'] = new \Knp\Component\Pager\Event\Subscriber\Sortable\SortableSubscriber();
    }

    /**
     * Gets the 'knp_paginator.twig.extension.pagination' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension A Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension instance.
     */
    protected function getKnpPaginator_Twig_Extension_PaginationService()
    {
        return $this->services['knp_paginator.twig.extension.pagination'] = new \Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension($this->get('knp_paginator.helper.processor'));
    }

    /**
     * Gets the 'locale_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\LocaleListener A Symfony\Component\HttpKernel\EventListener\LocaleListener instance.
     */
    protected function getLocaleListenerService()
    {
        return $this->services['locale_listener'] = new \Symfony\Component\HttpKernel\EventListener\LocaleListener('en', $this->get('router', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('request_stack'));
    }

    /**
     * Gets the 'logger' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Monolog\Logger A Symfony\Bridge\Monolog\Logger instance.
     */
    protected function getLoggerService()
    {
        $this->services['logger'] = $instance = new \Symfony\Bridge\Monolog\Logger('app');

        $instance->pushHandler($this->get('monolog.handler.console'));
        $instance->pushHandler($this->get('monolog.handler.main'));
        $instance->pushHandler($this->get('monolog.handler.debug'));

        return $instance;
    }

    /**
     * Gets the 'monolog.handler.console' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Monolog\Handler\ConsoleHandler A Symfony\Bridge\Monolog\Handler\ConsoleHandler instance.
     */
    protected function getMonolog_Handler_ConsoleService()
    {
        return $this->services['monolog.handler.console'] = new \Symfony\Bridge\Monolog\Handler\ConsoleHandler(NULL, false, array(2 => 200, 3 => 100, 1 => 300, 4 => 100));
    }

    /**
     * Gets the 'monolog.handler.console_very_verbose' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Monolog\Handler\ConsoleHandler A Symfony\Bridge\Monolog\Handler\ConsoleHandler instance.
     */
    protected function getMonolog_Handler_ConsoleVeryVerboseService()
    {
        return $this->services['monolog.handler.console_very_verbose'] = new \Symfony\Bridge\Monolog\Handler\ConsoleHandler(NULL, false, array(2 => 250, 3 => 250, 4 => 100, 1 => 300));
    }

    /**
     * Gets the 'monolog.handler.debug' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Monolog\Handler\DebugHandler A Symfony\Bridge\Monolog\Handler\DebugHandler instance.
     */
    protected function getMonolog_Handler_DebugService()
    {
        return $this->services['monolog.handler.debug'] = new \Symfony\Bridge\Monolog\Handler\DebugHandler(100, true);
    }

    /**
     * Gets the 'monolog.handler.main' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Monolog\Handler\StreamHandler A Monolog\Handler\StreamHandler instance.
     */
    protected function getMonolog_Handler_MainService()
    {
        return $this->services['monolog.handler.main'] = new \Monolog\Handler\StreamHandler(($this->targetDirs[2].'\\logs/dev.log'), 100, true, NULL);
    }

    /**
     * Gets the 'monolog.logger.assetic' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Monolog\Logger A Symfony\Bridge\Monolog\Logger instance.
     */
    protected function getMonolog_Logger_AsseticService()
    {
        $this->services['monolog.logger.assetic'] = $instance = new \Symfony\Bridge\Monolog\Logger('assetic');

        $instance->pushHandler($this->get('monolog.handler.console'));
        $instance->pushHandler($this->get('monolog.handler.main'));
        $instance->pushHandler($this->get('monolog.handler.debug'));

        return $instance;
    }

    /**
     * Gets the 'monolog.logger.doctrine' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Monolog\Logger A Symfony\Bridge\Monolog\Logger instance.
     */
    protected function getMonolog_Logger_DoctrineService()
    {
        $this->services['monolog.logger.doctrine'] = $instance = new \Symfony\Bridge\Monolog\Logger('doctrine');

        $instance->pushHandler($this->get('monolog.handler.console_very_verbose'));
        $instance->pushHandler($this->get('monolog.handler.main'));
        $instance->pushHandler($this->get('monolog.handler.debug'));

        return $instance;
    }

    /**
     * Gets the 'monolog.logger.event' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Monolog\Logger A Symfony\Bridge\Monolog\Logger instance.
     */
    protected function getMonolog_Logger_EventService()
    {
        $this->services['monolog.logger.event'] = $instance = new \Symfony\Bridge\Monolog\Logger('event');

        $instance->pushHandler($this->get('monolog.handler.console'));
        $instance->pushHandler($this->get('monolog.handler.main'));
        $instance->pushHandler($this->get('monolog.handler.debug'));

        return $instance;
    }

    /**
     * Gets the 'monolog.logger.php' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Monolog\Logger A Symfony\Bridge\Monolog\Logger instance.
     */
    protected function getMonolog_Logger_PhpService()
    {
        $this->services['monolog.logger.php'] = $instance = new \Symfony\Bridge\Monolog\Logger('php');

        $instance->pushHandler($this->get('monolog.handler.console'));
        $instance->pushHandler($this->get('monolog.handler.main'));
        $instance->pushHandler($this->get('monolog.handler.debug'));

        return $instance;
    }

    /**
     * Gets the 'monolog.logger.profiler' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Monolog\Logger A Symfony\Bridge\Monolog\Logger instance.
     */
    protected function getMonolog_Logger_ProfilerService()
    {
        $this->services['monolog.logger.profiler'] = $instance = new \Symfony\Bridge\Monolog\Logger('profiler');

        $instance->pushHandler($this->get('monolog.handler.console'));
        $instance->pushHandler($this->get('monolog.handler.main'));
        $instance->pushHandler($this->get('monolog.handler.debug'));

        return $instance;
    }

    /**
     * Gets the 'monolog.logger.request' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Monolog\Logger A Symfony\Bridge\Monolog\Logger instance.
     */
    protected function getMonolog_Logger_RequestService()
    {
        $this->services['monolog.logger.request'] = $instance = new \Symfony\Bridge\Monolog\Logger('request');

        $instance->pushHandler($this->get('monolog.handler.console'));
        $instance->pushHandler($this->get('monolog.handler.main'));
        $instance->pushHandler($this->get('monolog.handler.debug'));

        return $instance;
    }

    /**
     * Gets the 'monolog.logger.router' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Monolog\Logger A Symfony\Bridge\Monolog\Logger instance.
     */
    protected function getMonolog_Logger_RouterService()
    {
        $this->services['monolog.logger.router'] = $instance = new \Symfony\Bridge\Monolog\Logger('router');

        $instance->pushHandler($this->get('monolog.handler.console'));
        $instance->pushHandler($this->get('monolog.handler.main'));
        $instance->pushHandler($this->get('monolog.handler.debug'));

        return $instance;
    }

    /**
     * Gets the 'monolog.logger.security' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Monolog\Logger A Symfony\Bridge\Monolog\Logger instance.
     */
    protected function getMonolog_Logger_SecurityService()
    {
        $this->services['monolog.logger.security'] = $instance = new \Symfony\Bridge\Monolog\Logger('security');

        $instance->pushHandler($this->get('monolog.handler.console'));
        $instance->pushHandler($this->get('monolog.handler.main'));
        $instance->pushHandler($this->get('monolog.handler.debug'));

        return $instance;
    }

    /**
     * Gets the 'monolog.logger.templating' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Monolog\Logger A Symfony\Bridge\Monolog\Logger instance.
     */
    protected function getMonolog_Logger_TemplatingService()
    {
        $this->services['monolog.logger.templating'] = $instance = new \Symfony\Bridge\Monolog\Logger('templating');

        $instance->pushHandler($this->get('monolog.handler.console'));
        $instance->pushHandler($this->get('monolog.handler.main'));
        $instance->pushHandler($this->get('monolog.handler.debug'));

        return $instance;
    }

    /**
     * Gets the 'monolog.logger.translation' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Monolog\Logger A Symfony\Bridge\Monolog\Logger instance.
     */
    protected function getMonolog_Logger_TranslationService()
    {
        $this->services['monolog.logger.translation'] = $instance = new \Symfony\Bridge\Monolog\Logger('translation');

        $instance->pushHandler($this->get('monolog.handler.console'));
        $instance->pushHandler($this->get('monolog.handler.main'));
        $instance->pushHandler($this->get('monolog.handler.debug'));

        return $instance;
    }

    /**
     * Gets the 'profiler' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\Profiler\Profiler A Symfony\Component\HttpKernel\Profiler\Profiler instance.
     */
    protected function getProfilerService()
    {
        $a = $this->get('monolog.logger.profiler', ContainerInterface::NULL_ON_INVALID_REFERENCE);
        $b = $this->get('kernel', ContainerInterface::NULL_ON_INVALID_REFERENCE);

        $c = new \Symfony\Component\HttpKernel\DataCollector\ConfigDataCollector();
        if ($this->has('kernel')) {
            $c->setKernel($b);
        }

        $d = new \Doctrine\Bundle\DoctrineBundle\DataCollector\DoctrineDataCollector($this->get('doctrine'));
        $d->addLogger('default', $this->get('doctrine.dbal.logger.profiling.default'));

        $this->services['profiler'] = $instance = new \Symfony\Component\HttpKernel\Profiler\Profiler(new \Symfony\Component\HttpKernel\Profiler\FileProfilerStorage(('file:'.__DIR__.'/profiler'), '', '', 86400), $a);

        $instance->add($c);
        $instance->add($this->get('data_collector.request'));
        $instance->add(new \Symfony\Bundle\FrameworkBundle\DataCollector\AjaxDataCollector());
        $instance->add(new \Symfony\Component\HttpKernel\DataCollector\ExceptionDataCollector());
        $instance->add(new \Symfony\Component\HttpKernel\DataCollector\EventDataCollector($this->get('debug.event_dispatcher', ContainerInterface::NULL_ON_INVALID_REFERENCE)));
        $instance->add(new \Symfony\Component\HttpKernel\DataCollector\LoggerDataCollector($a));
        $instance->add(new \Symfony\Component\HttpKernel\DataCollector\TimeDataCollector($b, $this->get('debug.stopwatch', ContainerInterface::NULL_ON_INVALID_REFERENCE)));
        $instance->add(new \Symfony\Component\HttpKernel\DataCollector\MemoryDataCollector());
        $instance->add($this->get('data_collector.router'));
        $instance->add($this->get('data_collector.form'));
        $instance->add($this->get('data_collector.translation'));
        $instance->add(new \Symfony\Bridge\Twig\DataCollector\TwigDataCollector($this->get('twig.profile')));
        $instance->add($d);
        $instance->add(new \Symfony\Bundle\SwiftmailerBundle\DataCollector\MessageDataCollector($this));
        $instance->add(new \Symfony\Bundle\SecurityBundle\DataCollector\SecurityDataCollector($this->get('security.token_storage', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('security.role_hierarchy')));
        $instance->add(new \JavierEguiluz\Bundle\EasyAdminBundle\DataCollector\EasyAdminDataCollector($this->get('easyadmin.configurator')));
        $instance->add(new \Sonata\BlockBundle\Profiler\DataCollector\BlockDataCollector($this->get('sonata.block.templating.helper'), array(0 => 'sonata.block.service.container', 1 => 'sonata.page.block.container', 2 => 'cmf.block.container', 3 => 'cmf.block.slideshow')));
        $instance->add($this->get('data_collector.dump'));

        return $instance;
    }

    /**
     * Gets the 'profiler_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\ProfilerListener A Symfony\Component\HttpKernel\EventListener\ProfilerListener instance.
     */
    protected function getProfilerListenerService()
    {
        return $this->services['profiler_listener'] = new \Symfony\Component\HttpKernel\EventListener\ProfilerListener($this->get('profiler'), NULL, false, false, $this->get('request_stack'));
    }

    /**
     * Gets the 'property_accessor' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\PropertyAccess\PropertyAccessor A Symfony\Component\PropertyAccess\PropertyAccessor instance.
     */
    protected function getPropertyAccessorService()
    {
        return $this->services['property_accessor'] = new \Symfony\Component\PropertyAccess\PropertyAccessor(false, false);
    }

    /**
     * Gets the 'request' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @throws RuntimeException always since this service is expected to be injected dynamically
     * @throws InactiveScopeException when the 'request' service is requested while the 'request' scope is not active
     */
    protected function getRequestService()
    {
        if (!isset($this->scopedServices['request'])) {
            throw new InactiveScopeException('request', 'request');
        }

        throw new RuntimeException('You have requested a synthetic service ("request"). The DIC does not know how to construct this service.');
    }

    /**
     * Gets the 'request_stack' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpFoundation\RequestStack A Symfony\Component\HttpFoundation\RequestStack instance.
     */
    protected function getRequestStackService()
    {
        return $this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack();
    }

    /**
     * Gets the 'response_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\ResponseListener A Symfony\Component\HttpKernel\EventListener\ResponseListener instance.
     */
    protected function getResponseListenerService()
    {
        return $this->services['response_listener'] = new \Symfony\Component\HttpKernel\EventListener\ResponseListener('UTF-8');
    }

    /**
     * Gets the 'router' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Routing\Router A Symfony\Bundle\FrameworkBundle\Routing\Router instance.
     */
    protected function getRouterService()
    {
        return $this->services['router'] = new \Symfony\Bundle\FrameworkBundle\Routing\Router($this, (__DIR__.'/assetic/routing.yml'), array('cache_dir' => __DIR__, 'debug' => true, 'generator_class' => 'Symfony\\Component\\Routing\\Generator\\UrlGenerator', 'generator_base_class' => 'Symfony\\Component\\Routing\\Generator\\UrlGenerator', 'generator_dumper_class' => 'Symfony\\Component\\Routing\\Generator\\Dumper\\PhpGeneratorDumper', 'generator_cache_class' => 'appDevUrlGenerator', 'matcher_class' => 'Symfony\\Bundle\\FrameworkBundle\\Routing\\RedirectableUrlMatcher', 'matcher_base_class' => 'Symfony\\Bundle\\FrameworkBundle\\Routing\\RedirectableUrlMatcher', 'matcher_dumper_class' => 'Symfony\\Component\\Routing\\Matcher\\Dumper\\PhpMatcherDumper', 'matcher_cache_class' => 'appDevUrlMatcher', 'strict_requirements' => true, 'resource_type' => 'yaml'), $this->get('router.request_context', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('monolog.logger.router', ContainerInterface::NULL_ON_INVALID_REFERENCE));
    }

    /**
     * Gets the 'router_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\RouterListener A Symfony\Component\HttpKernel\EventListener\RouterListener instance.
     */
    protected function getRouterListenerService()
    {
        return $this->services['router_listener'] = new \Symfony\Component\HttpKernel\EventListener\RouterListener($this->get('router'), $this->get('router.request_context', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('monolog.logger.request', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('request_stack'));
    }

    /**
     * Gets the 'routing.loader' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Routing\DelegatingLoader A Symfony\Bundle\FrameworkBundle\Routing\DelegatingLoader instance.
     */
    protected function getRouting_LoaderService()
    {
        $a = $this->get('file_locator');
        $b = $this->get('annotation_reader');

        $c = new \Sensio\Bundle\FrameworkExtraBundle\Routing\AnnotatedRouteControllerLoader($b);

        $d = new \Symfony\Component\Config\Loader\LoaderResolver();
        $d->addLoader(new \Symfony\Component\Routing\Loader\XmlFileLoader($a));
        $d->addLoader(new \Symfony\Component\Routing\Loader\YamlFileLoader($a));
        $d->addLoader(new \Symfony\Component\Routing\Loader\PhpFileLoader($a));
        $d->addLoader(new \Symfony\Bundle\AsseticBundle\Routing\AsseticLoader($this->get('assetic.asset_manager'), array()));
        $d->addLoader(new \Symfony\Component\Routing\Loader\AnnotationDirectoryLoader($a, $c));
        $d->addLoader(new \Symfony\Component\Routing\Loader\AnnotationFileLoader($a, $c));
        $d->addLoader($c);
        $d->addLoader($this->get('sonata.admin.route_loader'));

        return $this->services['routing.loader'] = new \Symfony\Bundle\FrameworkBundle\Routing\DelegatingLoader($this->get('controller_name_converter'), $this->get('monolog.logger.router', ContainerInterface::NULL_ON_INVALID_REFERENCE), $d);
    }

    /**
     * Gets the 'security.acl.dbal.schema' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Security\Acl\Dbal\Schema A Symfony\Component\Security\Acl\Dbal\Schema instance.
     */
    protected function getSecurity_Acl_Dbal_SchemaService()
    {
        return $this->services['security.acl.dbal.schema'] = new \Symfony\Component\Security\Acl\Dbal\Schema(array('class_table_name' => 'acl_classes', 'entry_table_name' => 'acl_entries', 'oid_table_name' => 'acl_object_identities', 'oid_ancestors_table_name' => 'acl_object_identity_ancestors', 'sid_table_name' => 'acl_security_identities'), $this->get('doctrine.dbal.default_connection'));
    }

    /**
     * Gets the 'security.acl.dbal.schema_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\SecurityBundle\EventListener\AclSchemaListener A Symfony\Bundle\SecurityBundle\EventListener\AclSchemaListener instance.
     */
    protected function getSecurity_Acl_Dbal_SchemaListenerService()
    {
        return $this->services['security.acl.dbal.schema_listener'] = new \Symfony\Bundle\SecurityBundle\EventListener\AclSchemaListener($this->get('security.acl.dbal.schema'));
    }

    /**
     * Gets the 'security.acl.provider' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Security\Acl\Dbal\MutableAclProvider A Symfony\Component\Security\Acl\Dbal\MutableAclProvider instance.
     */
    protected function getSecurity_Acl_ProviderService()
    {
        return $this->services['security.acl.provider'] = new \Symfony\Component\Security\Acl\Dbal\MutableAclProvider($this->get('doctrine.dbal.default_connection'), new \Symfony\Component\Security\Acl\Domain\PermissionGrantingStrategy(), array('class_table_name' => 'acl_classes', 'entry_table_name' => 'acl_entries', 'oid_table_name' => 'acl_object_identities', 'oid_ancestors_table_name' => 'acl_object_identity_ancestors', 'sid_table_name' => 'acl_security_identities'), NULL);
    }

    /**
     * Gets the 'security.authentication_utils' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Security\Http\Authentication\AuthenticationUtils A Symfony\Component\Security\Http\Authentication\AuthenticationUtils instance.
     */
    protected function getSecurity_AuthenticationUtilsService()
    {
        return $this->services['security.authentication_utils'] = new \Symfony\Component\Security\Http\Authentication\AuthenticationUtils($this->get('request_stack'));
    }

    /**
     * Gets the 'security.authorization_checker' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Security\Core\Authorization\AuthorizationChecker A Symfony\Component\Security\Core\Authorization\AuthorizationChecker instance.
     */
    protected function getSecurity_AuthorizationCheckerService()
    {
        return $this->services['security.authorization_checker'] = new \Symfony\Component\Security\Core\Authorization\AuthorizationChecker($this->get('security.token_storage'), $this->get('security.authentication.manager'), $this->get('security.access.decision_manager'), false);
    }

    /**
     * Gets the 'security.context' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Security\Core\SecurityContext A Symfony\Component\Security\Core\SecurityContext instance.
     */
    protected function getSecurity_ContextService()
    {
        return $this->services['security.context'] = new \Symfony\Component\Security\Core\SecurityContext($this->get('security.token_storage'), $this->get('security.authorization_checker'));
    }

    /**
     * Gets the 'security.csrf.token_manager' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Security\Csrf\CsrfTokenManager A Symfony\Component\Security\Csrf\CsrfTokenManager instance.
     */
    protected function getSecurity_Csrf_TokenManagerService()
    {
        return $this->services['security.csrf.token_manager'] = new \Symfony\Component\Security\Csrf\CsrfTokenManager(new \Symfony\Component\Security\Csrf\TokenGenerator\UriSafeTokenGenerator($this->get('security.secure_random')), new \Symfony\Component\Security\Csrf\TokenStorage\SessionTokenStorage($this->get('session')));
    }

    /**
     * Gets the 'security.encoder_factory' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Security\Core\Encoder\EncoderFactory A Symfony\Component\Security\Core\Encoder\EncoderFactory instance.
     */
    protected function getSecurity_EncoderFactoryService()
    {
        return $this->services['security.encoder_factory'] = new \Symfony\Component\Security\Core\Encoder\EncoderFactory(array('FOS\\UserBundle\\Model\\UserInterface' => array('class' => 'Symfony\\Component\\Security\\Core\\Encoder\\BCryptPasswordEncoder', 'arguments' => array(0 => 13))));
    }

    /**
     * Gets the 'security.firewall' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Security\Http\Firewall A Symfony\Component\Security\Http\Firewall instance.
     */
    protected function getSecurity_FirewallService()
    {
        return $this->services['security.firewall'] = new \Symfony\Component\Security\Http\Firewall(new \Symfony\Bundle\SecurityBundle\Security\FirewallMap($this, array('security.firewall.map.context.main' => new \Symfony\Component\HttpFoundation\RequestMatcher('^/'))), $this->get('debug.event_dispatcher'));
    }

    /**
     * Gets the 'security.firewall.map.context.main' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\SecurityBundle\Security\FirewallContext A Symfony\Bundle\SecurityBundle\Security\FirewallContext instance.
     */
    protected function getSecurity_Firewall_Map_Context_MainService()
    {
        $a = $this->get('monolog.logger.security', ContainerInterface::NULL_ON_INVALID_REFERENCE);
        $b = $this->get('security.token_storage');
        $c = $this->get('debug.event_dispatcher', ContainerInterface::NULL_ON_INVALID_REFERENCE);
        $d = $this->get('router', ContainerInterface::NULL_ON_INVALID_REFERENCE);
        $e = $this->get('http_kernel');
        $f = $this->get('security.authentication.manager');

        $g = new \Symfony\Component\HttpFoundation\RequestMatcher('^/login$');

        $h = new \Symfony\Component\HttpFoundation\RequestMatcher('^/register');

        $i = new \Symfony\Component\HttpFoundation\RequestMatcher('^/resetting');

        $j = new \Symfony\Component\HttpFoundation\RequestMatcher('^/admin/');

        $k = new \Symfony\Component\HttpFoundation\RequestMatcher('^/');

        $l = new \Symfony\Component\Security\Http\AccessMap();
        $l->add($g, array(0 => 'IS_AUTHENTICATED_ANONYMOUSLY'), NULL);
        $l->add($h, array(0 => 'IS_AUTHENTICATED_ANONYMOUSLY'), NULL);
        $l->add($i, array(0 => 'IS_AUTHENTICATED_ANONYMOUSLY'), NULL);
        $l->add($j, array(0 => 'ROLE_SUPER_ADMIN'), NULL);
        $l->add($k, array(0 => 'ROLE_USER'), NULL);

        $m = new \Symfony\Component\Security\Http\HttpUtils($d, $d);

        $n = new \Symfony\Component\Security\Http\Firewall\LogoutListener($b, $m, new \Symfony\Component\Security\Http\Logout\DefaultLogoutSuccessHandler($m, '/'), array('csrf_parameter' => '_csrf_token', 'intention' => 'logout', 'logout_path' => '/logout'));
        $n->addHandler(new \Symfony\Component\Security\Http\Logout\SessionLogoutHandler());

        $o = new \Symfony\Component\Security\Http\Authentication\DefaultAuthenticationSuccessHandler($m, array());
        $o->setOptions(array('always_use_default_target_path' => false, 'default_target_path' => '/', 'login_path' => '/login', 'target_path_parameter' => '_target_path', 'use_referer' => false));
        $o->setProviderKey('main');

        $p = new \Symfony\Component\Security\Http\Authentication\DefaultAuthenticationFailureHandler($e, $m, array(), $a);
        $p->setOptions(array('login_path' => '/login', 'failure_path' => NULL, 'failure_forward' => false, 'failure_path_parameter' => '_failure_path'));

        return $this->services['security.firewall.map.context.main'] = new \Symfony\Bundle\SecurityBundle\Security\FirewallContext(array(0 => new \Symfony\Component\Security\Http\Firewall\ChannelListener($l, new \Symfony\Component\Security\Http\EntryPoint\RetryAuthenticationEntryPoint(80, 443), $a), 1 => new \Symfony\Component\Security\Http\Firewall\ContextListener($b, array(0 => $this->get('fos_user.user_provider.username')), 'main', $a, $c), 2 => $n, 3 => new \Symfony\Component\Security\Http\Firewall\UsernamePasswordFormAuthenticationListener($b, $f, $this->get('security.authentication.session_strategy'), $m, 'main', $o, $p, array('check_path' => '/login_check', 'use_forward' => false, 'require_previous_session' => true, 'username_parameter' => '_username', 'password_parameter' => '_password', 'csrf_parameter' => '_csrf_token', 'intention' => 'authenticate', 'post_only' => true), $a, $c, $this->get('form.csrf_provider')), 4 => new \Symfony\Component\Security\Http\Firewall\AnonymousAuthenticationListener($b, '56fb31d31482b7.98455892', $a, $f), 5 => new \Symfony\Component\Security\Http\Firewall\AccessListener($b, $this->get('security.access.decision_manager'), $l, $f)), new \Symfony\Component\Security\Http\Firewall\ExceptionListener($b, $this->get('security.authentication.trust_resolver'), $m, 'main', new \Symfony\Component\Security\Http\EntryPoint\FormAuthenticationEntryPoint($e, $m, '/login', false), NULL, NULL, $a, false));
    }

    /**
     * Gets the 'security.password_encoder' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Security\Core\Encoder\UserPasswordEncoder A Symfony\Component\Security\Core\Encoder\UserPasswordEncoder instance.
     */
    protected function getSecurity_PasswordEncoderService()
    {
        return $this->services['security.password_encoder'] = new \Symfony\Component\Security\Core\Encoder\UserPasswordEncoder($this->get('security.encoder_factory'));
    }

    /**
     * Gets the 'security.rememberme.response_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Security\Http\RememberMe\ResponseListener A Symfony\Component\Security\Http\RememberMe\ResponseListener instance.
     */
    protected function getSecurity_Rememberme_ResponseListenerService()
    {
        return $this->services['security.rememberme.response_listener'] = new \Symfony\Component\Security\Http\RememberMe\ResponseListener();
    }

    /**
     * Gets the 'security.secure_random' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Security\Core\Util\SecureRandom A Symfony\Component\Security\Core\Util\SecureRandom instance.
     */
    protected function getSecurity_SecureRandomService()
    {
        return $this->services['security.secure_random'] = new \Symfony\Component\Security\Core\Util\SecureRandom();
    }

    /**
     * Gets the 'security.token_storage' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage A Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage instance.
     */
    protected function getSecurity_TokenStorageService()
    {
        return $this->services['security.token_storage'] = new \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage();
    }

    /**
     * Gets the 'security.validator.user_password' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Security\Core\Validator\Constraints\UserPasswordValidator A Symfony\Component\Security\Core\Validator\Constraints\UserPasswordValidator instance.
     */
    protected function getSecurity_Validator_UserPasswordService()
    {
        return $this->services['security.validator.user_password'] = new \Symfony\Component\Security\Core\Validator\Constraints\UserPasswordValidator($this->get('security.token_storage'), $this->get('security.encoder_factory'));
    }

    /**
     * Gets the 'sensio_distribution.security_checker' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \SensioLabs\Security\SecurityChecker A SensioLabs\Security\SecurityChecker instance.
     */
    protected function getSensioDistribution_SecurityCheckerService()
    {
        return $this->services['sensio_distribution.security_checker'] = new \SensioLabs\Security\SecurityChecker();
    }

    /**
     * Gets the 'sensio_distribution.security_checker.command' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \SensioLabs\Security\Command\SecurityCheckerCommand A SensioLabs\Security\Command\SecurityCheckerCommand instance.
     */
    protected function getSensioDistribution_SecurityChecker_CommandService()
    {
        return $this->services['sensio_distribution.security_checker.command'] = new \SensioLabs\Security\Command\SecurityCheckerCommand($this->get('sensio_distribution.security_checker'));
    }

    /**
     * Gets the 'sensio_distribution.webconfigurator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sensio\Bundle\DistributionBundle\Configurator\Configurator A Sensio\Bundle\DistributionBundle\Configurator\Configurator instance.
     */
    protected function getSensioDistribution_WebconfiguratorService()
    {
        $this->services['sensio_distribution.webconfigurator'] = $instance = new \Sensio\Bundle\DistributionBundle\Configurator\Configurator($this->targetDirs[2]);

        $instance->addStep(new \Sensio\Bundle\DistributionBundle\Configurator\Step\DoctrineStep(), 10);
        $instance->addStep(new \Sensio\Bundle\DistributionBundle\Configurator\Step\SecretStep(), 0);

        return $instance;
    }

    /**
     * Gets the 'sensio_framework_extra.cache.listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\EventListener\HttpCacheListener A Sensio\Bundle\FrameworkExtraBundle\EventListener\HttpCacheListener instance.
     */
    protected function getSensioFrameworkExtra_Cache_ListenerService()
    {
        return $this->services['sensio_framework_extra.cache.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\HttpCacheListener();
    }

    /**
     * Gets the 'sensio_framework_extra.controller.listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\EventListener\ControllerListener A Sensio\Bundle\FrameworkExtraBundle\EventListener\ControllerListener instance.
     */
    protected function getSensioFrameworkExtra_Controller_ListenerService()
    {
        return $this->services['sensio_framework_extra.controller.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\ControllerListener($this->get('annotation_reader'));
    }

    /**
     * Gets the 'sensio_framework_extra.converter.datetime' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\DateTimeParamConverter A Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\DateTimeParamConverter instance.
     */
    protected function getSensioFrameworkExtra_Converter_DatetimeService()
    {
        return $this->services['sensio_framework_extra.converter.datetime'] = new \Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\DateTimeParamConverter();
    }

    /**
     * Gets the 'sensio_framework_extra.converter.doctrine.orm' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\DoctrineParamConverter A Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\DoctrineParamConverter instance.
     */
    protected function getSensioFrameworkExtra_Converter_Doctrine_OrmService()
    {
        return $this->services['sensio_framework_extra.converter.doctrine.orm'] = new \Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\DoctrineParamConverter($this->get('doctrine', ContainerInterface::NULL_ON_INVALID_REFERENCE));
    }

    /**
     * Gets the 'sensio_framework_extra.converter.listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\EventListener\ParamConverterListener A Sensio\Bundle\FrameworkExtraBundle\EventListener\ParamConverterListener instance.
     */
    protected function getSensioFrameworkExtra_Converter_ListenerService()
    {
        return $this->services['sensio_framework_extra.converter.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\ParamConverterListener($this->get('sensio_framework_extra.converter.manager'), true);
    }

    /**
     * Gets the 'sensio_framework_extra.converter.manager' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\ParamConverterManager A Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\ParamConverterManager instance.
     */
    protected function getSensioFrameworkExtra_Converter_ManagerService()
    {
        $this->services['sensio_framework_extra.converter.manager'] = $instance = new \Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\ParamConverterManager();

        $instance->add($this->get('sensio_framework_extra.converter.doctrine.orm'), 0, 'doctrine.orm');
        $instance->add($this->get('sensio_framework_extra.converter.datetime'), 0, 'datetime');

        return $instance;
    }

    /**
     * Gets the 'sensio_framework_extra.security.listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\EventListener\SecurityListener A Sensio\Bundle\FrameworkExtraBundle\EventListener\SecurityListener instance.
     */
    protected function getSensioFrameworkExtra_Security_ListenerService()
    {
        return $this->services['sensio_framework_extra.security.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\SecurityListener(NULL, new \Sensio\Bundle\FrameworkExtraBundle\Security\ExpressionLanguage(), $this->get('security.authentication.trust_resolver', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('security.role_hierarchy', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('security.token_storage', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('security.authorization_checker', ContainerInterface::NULL_ON_INVALID_REFERENCE));
    }

    /**
     * Gets the 'sensio_framework_extra.view.guesser' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\Templating\TemplateGuesser A Sensio\Bundle\FrameworkExtraBundle\Templating\TemplateGuesser instance.
     */
    protected function getSensioFrameworkExtra_View_GuesserService()
    {
        return $this->services['sensio_framework_extra.view.guesser'] = new \Sensio\Bundle\FrameworkExtraBundle\Templating\TemplateGuesser($this->get('kernel'));
    }

    /**
     * Gets the 'sensio_framework_extra.view.listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\EventListener\TemplateListener A Sensio\Bundle\FrameworkExtraBundle\EventListener\TemplateListener instance.
     */
    protected function getSensioFrameworkExtra_View_ListenerService()
    {
        return $this->services['sensio_framework_extra.view.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\TemplateListener($this);
    }

    /**
     * Gets the 'service_container' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @throws RuntimeException always since this service is expected to be injected dynamically
     */
    protected function getServiceContainerService()
    {
        throw new RuntimeException('You have requested a synthetic service ("service_container"). The DIC does not know how to construct this service.');
    }

    /**
     * Gets the 'session' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpFoundation\Session\Session A Symfony\Component\HttpFoundation\Session\Session instance.
     */
    protected function getSessionService()
    {
        return $this->services['session'] = new \Symfony\Component\HttpFoundation\Session\Session($this->get('session.storage.native'), new \Symfony\Component\HttpFoundation\Session\Attribute\AttributeBag(), new \Symfony\Component\HttpFoundation\Session\Flash\FlashBag());
    }

    /**
     * Gets the 'session.save_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\SaveSessionListener A Symfony\Component\HttpKernel\EventListener\SaveSessionListener instance.
     */
    protected function getSession_SaveListenerService()
    {
        return $this->services['session.save_listener'] = new \Symfony\Component\HttpKernel\EventListener\SaveSessionListener();
    }

    /**
     * Gets the 'session.storage.filesystem' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpFoundation\Session\Storage\MockFileSessionStorage A Symfony\Component\HttpFoundation\Session\Storage\MockFileSessionStorage instance.
     */
    protected function getSession_Storage_FilesystemService()
    {
        return $this->services['session.storage.filesystem'] = new \Symfony\Component\HttpFoundation\Session\Storage\MockFileSessionStorage((__DIR__.'/sessions'), 'MOCKSESSID', $this->get('session.storage.metadata_bag'));
    }

    /**
     * Gets the 'session.storage.native' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpFoundation\Session\Storage\NativeSessionStorage A Symfony\Component\HttpFoundation\Session\Storage\NativeSessionStorage instance.
     */
    protected function getSession_Storage_NativeService()
    {
        return $this->services['session.storage.native'] = new \Symfony\Component\HttpFoundation\Session\Storage\NativeSessionStorage(array('gc_probability' => 0), NULL, $this->get('session.storage.metadata_bag'));
    }

    /**
     * Gets the 'session.storage.php_bridge' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpFoundation\Session\Storage\PhpBridgeSessionStorage A Symfony\Component\HttpFoundation\Session\Storage\PhpBridgeSessionStorage instance.
     */
    protected function getSession_Storage_PhpBridgeService()
    {
        return $this->services['session.storage.php_bridge'] = new \Symfony\Component\HttpFoundation\Session\Storage\PhpBridgeSessionStorage(NULL, $this->get('session.storage.metadata_bag'));
    }

    /**
     * Gets the 'session_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\EventListener\SessionListener A Symfony\Bundle\FrameworkBundle\EventListener\SessionListener instance.
     */
    protected function getSessionListenerService()
    {
        return $this->services['session_listener'] = new \Symfony\Bundle\FrameworkBundle\EventListener\SessionListener($this);
    }

    /**
     * Gets the 'sonata.admin.audit.manager' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Model\AuditManager A Sonata\AdminBundle\Model\AuditManager instance.
     */
    protected function getSonata_Admin_Audit_ManagerService()
    {
        return $this->services['sonata.admin.audit.manager'] = new \Sonata\AdminBundle\Model\AuditManager($this);
    }

    /**
     * Gets the 'sonata.admin.block.admin_list' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Block\AdminListBlockService A Sonata\AdminBundle\Block\AdminListBlockService instance.
     */
    protected function getSonata_Admin_Block_AdminListService()
    {
        return $this->services['sonata.admin.block.admin_list'] = new \Sonata\AdminBundle\Block\AdminListBlockService('sonata.admin.block.admin_list', $this->get('templating'), $this->get('sonata.admin.pool'));
    }

    /**
     * Gets the 'sonata.admin.block.search_result' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Block\AdminSearchBlockService A Sonata\AdminBundle\Block\AdminSearchBlockService instance.
     */
    protected function getSonata_Admin_Block_SearchResultService()
    {
        return $this->services['sonata.admin.block.search_result'] = new \Sonata\AdminBundle\Block\AdminSearchBlockService('sonata.admin.block.search_result', $this->get('templating'), $this->get('sonata.admin.pool'), $this->get('sonata.admin.search.handler'));
    }

    /**
     * Gets the 'sonata.admin.builder.filter.factory' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Filter\FilterFactory A Sonata\AdminBundle\Filter\FilterFactory instance.
     */
    protected function getSonata_Admin_Builder_Filter_FactoryService()
    {
        return $this->services['sonata.admin.builder.filter.factory'] = new \Sonata\AdminBundle\Filter\FilterFactory($this, array('doctrine_orm_boolean' => 'sonata.admin.orm.filter.type.boolean', 'doctrine_orm_callback' => 'sonata.admin.orm.filter.type.callback', 'doctrine_orm_choice' => 'sonata.admin.orm.filter.type.choice', 'doctrine_orm_model' => 'sonata.admin.orm.filter.type.model', 'doctrine_orm_string' => 'sonata.admin.orm.filter.type.string', 'doctrine_orm_number' => 'sonata.admin.orm.filter.type.number', 'doctrine_orm_date' => 'sonata.admin.orm.filter.type.date', 'doctrine_orm_date_range' => 'sonata.admin.orm.filter.type.date_range', 'doctrine_orm_datetime' => 'sonata.admin.orm.filter.type.datetime', 'doctrine_orm_time' => 'sonata.admin.orm.filter.type.time', 'doctrine_orm_datetime_range' => 'sonata.admin.orm.filter.type.datetime_range', 'doctrine_orm_class' => 'sonata.admin.orm.filter.type.class'));
    }

    /**
     * Gets the 'sonata.admin.builder.orm_datagrid' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Builder\DatagridBuilder A Sonata\DoctrineORMAdminBundle\Builder\DatagridBuilder instance.
     */
    protected function getSonata_Admin_Builder_OrmDatagridService()
    {
        return $this->services['sonata.admin.builder.orm_datagrid'] = new \Sonata\DoctrineORMAdminBundle\Builder\DatagridBuilder($this->get('form.factory'), $this->get('sonata.admin.builder.filter.factory'), $this->get('sonata.admin.guesser.orm_datagrid_chain'), true);
    }

    /**
     * Gets the 'sonata.admin.builder.orm_form' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Builder\FormContractor A Sonata\DoctrineORMAdminBundle\Builder\FormContractor instance.
     */
    protected function getSonata_Admin_Builder_OrmFormService()
    {
        return $this->services['sonata.admin.builder.orm_form'] = new \Sonata\DoctrineORMAdminBundle\Builder\FormContractor($this->get('form.factory'));
    }

    /**
     * Gets the 'sonata.admin.builder.orm_list' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Builder\ListBuilder A Sonata\DoctrineORMAdminBundle\Builder\ListBuilder instance.
     */
    protected function getSonata_Admin_Builder_OrmListService()
    {
        return $this->services['sonata.admin.builder.orm_list'] = new \Sonata\DoctrineORMAdminBundle\Builder\ListBuilder($this->get('sonata.admin.guesser.orm_list_chain'), array('array' => 'SonataAdminBundle:CRUD:list_array.html.twig', 'boolean' => 'SonataAdminBundle:CRUD:list_boolean.html.twig', 'date' => 'SonataAdminBundle:CRUD:list_date.html.twig', 'time' => 'SonataAdminBundle:CRUD:list_time.html.twig', 'datetime' => 'SonataAdminBundle:CRUD:list_datetime.html.twig', 'text' => 'SonataAdminBundle:CRUD:list_string.html.twig', 'textarea' => 'SonataAdminBundle:CRUD:list_string.html.twig', 'email' => 'SonataAdminBundle:CRUD:list_string.html.twig', 'trans' => 'SonataAdminBundle:CRUD:list_trans.html.twig', 'string' => 'SonataAdminBundle:CRUD:list_string.html.twig', 'smallint' => 'SonataAdminBundle:CRUD:list_string.html.twig', 'bigint' => 'SonataAdminBundle:CRUD:list_string.html.twig', 'integer' => 'SonataAdminBundle:CRUD:list_string.html.twig', 'decimal' => 'SonataAdminBundle:CRUD:list_string.html.twig', 'identifier' => 'SonataAdminBundle:CRUD:list_string.html.twig', 'currency' => 'SonataAdminBundle:CRUD:list_currency.html.twig', 'percent' => 'SonataAdminBundle:CRUD:list_percent.html.twig', 'choice' => 'SonataAdminBundle:CRUD:list_choice.html.twig', 'url' => 'SonataAdminBundle:CRUD:list_url.html.twig', 'html' => 'SonataAdminBundle:CRUD:list_html.html.twig'));
    }

    /**
     * Gets the 'sonata.admin.builder.orm_show' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Builder\ShowBuilder A Sonata\DoctrineORMAdminBundle\Builder\ShowBuilder instance.
     */
    protected function getSonata_Admin_Builder_OrmShowService()
    {
        return $this->services['sonata.admin.builder.orm_show'] = new \Sonata\DoctrineORMAdminBundle\Builder\ShowBuilder($this->get('sonata.admin.guesser.orm_show_chain'), array('array' => 'SonataAdminBundle:CRUD:show_array.html.twig', 'boolean' => 'SonataAdminBundle:CRUD:show_boolean.html.twig', 'date' => 'SonataAdminBundle:CRUD:show_date.html.twig', 'time' => 'SonataAdminBundle:CRUD:show_time.html.twig', 'datetime' => 'SonataAdminBundle:CRUD:show_datetime.html.twig', 'text' => 'SonataAdminBundle:CRUD:base_show_field.html.twig', 'trans' => 'SonataAdminBundle:CRUD:show_trans.html.twig', 'string' => 'SonataAdminBundle:CRUD:base_show_field.html.twig', 'smallint' => 'SonataAdminBundle:CRUD:base_show_field.html.twig', 'bigint' => 'SonataAdminBundle:CRUD:base_show_field.html.twig', 'integer' => 'SonataAdminBundle:CRUD:base_show_field.html.twig', 'decimal' => 'SonataAdminBundle:CRUD:base_show_field.html.twig', 'currency' => 'SonataAdminBundle:CRUD:show_currency.html.twig', 'percent' => 'SonataAdminBundle:CRUD:show_percent.html.twig', 'choice' => 'SonataAdminBundle:CRUD:show_choice.html.twig', 'url' => 'SonataAdminBundle:CRUD:show_url.html.twig', 'html' => 'SonataAdminBundle:CRUD:show_html.html.twig'));
    }

    /**
     * Gets the 'sonata.admin.controller.admin' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Controller\HelperController A Sonata\AdminBundle\Controller\HelperController instance.
     */
    protected function getSonata_Admin_Controller_AdminService()
    {
        return $this->services['sonata.admin.controller.admin'] = new \Sonata\AdminBundle\Controller\HelperController($this->get('twig'), $this->get('sonata.admin.pool'), $this->get('sonata.admin.helper'), $this->get('validator'));
    }

    /**
     * Gets the 'sonata.admin.event.extension' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Event\AdminEventExtension A Sonata\AdminBundle\Event\AdminEventExtension instance.
     */
    protected function getSonata_Admin_Event_ExtensionService()
    {
        return $this->services['sonata.admin.event.extension'] = new \Sonata\AdminBundle\Event\AdminEventExtension($this->get('debug.event_dispatcher'));
    }

    /**
     * Gets the 'sonata.admin.exporter' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Export\Exporter A Sonata\AdminBundle\Export\Exporter instance.
     */
    protected function getSonata_Admin_ExporterService()
    {
        return $this->services['sonata.admin.exporter'] = new \Sonata\AdminBundle\Export\Exporter();
    }

    /**
     * Gets the 'sonata.admin.form.extension.field' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Extension\Field\Type\FormTypeFieldExtension A Sonata\AdminBundle\Form\Extension\Field\Type\FormTypeFieldExtension instance.
     */
    protected function getSonata_Admin_Form_Extension_FieldService()
    {
        return $this->services['sonata.admin.form.extension.field'] = new \Sonata\AdminBundle\Form\Extension\Field\Type\FormTypeFieldExtension(array('email' => '', 'textarea' => '', 'text' => '', 'choice' => '', 'integer' => '', 'datetime' => 'sonata-medium-date', 'date' => 'sonata-medium-date'));
    }

    /**
     * Gets the 'sonata.admin.form.extension.field.mopa' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Extension\Field\Type\MopaCompatibilityTypeFieldExtension A Sonata\AdminBundle\Form\Extension\Field\Type\MopaCompatibilityTypeFieldExtension instance.
     */
    protected function getSonata_Admin_Form_Extension_Field_MopaService()
    {
        return $this->services['sonata.admin.form.extension.field.mopa'] = new \Sonata\AdminBundle\Form\Extension\Field\Type\MopaCompatibilityTypeFieldExtension();
    }

    /**
     * Gets the 'sonata.admin.form.filter.type.choice' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Type\Filter\ChoiceType A Sonata\AdminBundle\Form\Type\Filter\ChoiceType instance.
     */
    protected function getSonata_Admin_Form_Filter_Type_ChoiceService()
    {
        return $this->services['sonata.admin.form.filter.type.choice'] = new \Sonata\AdminBundle\Form\Type\Filter\ChoiceType($this->get('translator'));
    }

    /**
     * Gets the 'sonata.admin.form.filter.type.date' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Type\Filter\DateType A Sonata\AdminBundle\Form\Type\Filter\DateType instance.
     */
    protected function getSonata_Admin_Form_Filter_Type_DateService()
    {
        return $this->services['sonata.admin.form.filter.type.date'] = new \Sonata\AdminBundle\Form\Type\Filter\DateType($this->get('translator'));
    }

    /**
     * Gets the 'sonata.admin.form.filter.type.daterange' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Type\Filter\DateRangeType A Sonata\AdminBundle\Form\Type\Filter\DateRangeType instance.
     */
    protected function getSonata_Admin_Form_Filter_Type_DaterangeService()
    {
        return $this->services['sonata.admin.form.filter.type.daterange'] = new \Sonata\AdminBundle\Form\Type\Filter\DateRangeType($this->get('translator'));
    }

    /**
     * Gets the 'sonata.admin.form.filter.type.datetime' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Type\Filter\DateTimeType A Sonata\AdminBundle\Form\Type\Filter\DateTimeType instance.
     */
    protected function getSonata_Admin_Form_Filter_Type_DatetimeService()
    {
        return $this->services['sonata.admin.form.filter.type.datetime'] = new \Sonata\AdminBundle\Form\Type\Filter\DateTimeType($this->get('translator'));
    }

    /**
     * Gets the 'sonata.admin.form.filter.type.datetime_range' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Type\Filter\DateTimeRangeType A Sonata\AdminBundle\Form\Type\Filter\DateTimeRangeType instance.
     */
    protected function getSonata_Admin_Form_Filter_Type_DatetimeRangeService()
    {
        return $this->services['sonata.admin.form.filter.type.datetime_range'] = new \Sonata\AdminBundle\Form\Type\Filter\DateTimeRangeType($this->get('translator'));
    }

    /**
     * Gets the 'sonata.admin.form.filter.type.default' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Type\Filter\DefaultType A Sonata\AdminBundle\Form\Type\Filter\DefaultType instance.
     */
    protected function getSonata_Admin_Form_Filter_Type_DefaultService()
    {
        return $this->services['sonata.admin.form.filter.type.default'] = new \Sonata\AdminBundle\Form\Type\Filter\DefaultType();
    }

    /**
     * Gets the 'sonata.admin.form.filter.type.number' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Type\Filter\NumberType A Sonata\AdminBundle\Form\Type\Filter\NumberType instance.
     */
    protected function getSonata_Admin_Form_Filter_Type_NumberService()
    {
        return $this->services['sonata.admin.form.filter.type.number'] = new \Sonata\AdminBundle\Form\Type\Filter\NumberType($this->get('translator'));
    }

    /**
     * Gets the 'sonata.admin.form.type.admin' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Type\AdminType A Sonata\AdminBundle\Form\Type\AdminType instance.
     */
    protected function getSonata_Admin_Form_Type_AdminService()
    {
        return $this->services['sonata.admin.form.type.admin'] = new \Sonata\AdminBundle\Form\Type\AdminType();
    }

    /**
     * Gets the 'sonata.admin.form.type.collection' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Type\CollectionType A Sonata\AdminBundle\Form\Type\CollectionType instance.
     */
    protected function getSonata_Admin_Form_Type_CollectionService()
    {
        return $this->services['sonata.admin.form.type.collection'] = new \Sonata\AdminBundle\Form\Type\CollectionType();
    }

    /**
     * Gets the 'sonata.admin.form.type.model_autocomplete' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Type\ModelAutocompleteType A Sonata\AdminBundle\Form\Type\ModelAutocompleteType instance.
     */
    protected function getSonata_Admin_Form_Type_ModelAutocompleteService()
    {
        return $this->services['sonata.admin.form.type.model_autocomplete'] = new \Sonata\AdminBundle\Form\Type\ModelAutocompleteType();
    }

    /**
     * Gets the 'sonata.admin.form.type.model_choice' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Type\ModelType A Sonata\AdminBundle\Form\Type\ModelType instance.
     */
    protected function getSonata_Admin_Form_Type_ModelChoiceService()
    {
        return $this->services['sonata.admin.form.type.model_choice'] = new \Sonata\AdminBundle\Form\Type\ModelType();
    }

    /**
     * Gets the 'sonata.admin.form.type.model_hidden' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Type\ModelHiddenType A Sonata\AdminBundle\Form\Type\ModelHiddenType instance.
     */
    protected function getSonata_Admin_Form_Type_ModelHiddenService()
    {
        return $this->services['sonata.admin.form.type.model_hidden'] = new \Sonata\AdminBundle\Form\Type\ModelHiddenType();
    }

    /**
     * Gets the 'sonata.admin.form.type.model_list' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Type\ModelTypeList A Sonata\AdminBundle\Form\Type\ModelTypeList instance.
     */
    protected function getSonata_Admin_Form_Type_ModelListService()
    {
        return $this->services['sonata.admin.form.type.model_list'] = new \Sonata\AdminBundle\Form\Type\ModelTypeList();
    }

    /**
     * Gets the 'sonata.admin.form.type.model_reference' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Form\Type\ModelReferenceType A Sonata\AdminBundle\Form\Type\ModelReferenceType instance.
     */
    protected function getSonata_Admin_Form_Type_ModelReferenceService()
    {
        return $this->services['sonata.admin.form.type.model_reference'] = new \Sonata\AdminBundle\Form\Type\ModelReferenceType();
    }

    /**
     * Gets the 'sonata.admin.guesser.orm_datagrid' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Guesser\FilterTypeGuesser A Sonata\DoctrineORMAdminBundle\Guesser\FilterTypeGuesser instance.
     */
    protected function getSonata_Admin_Guesser_OrmDatagridService()
    {
        return $this->services['sonata.admin.guesser.orm_datagrid'] = new \Sonata\DoctrineORMAdminBundle\Guesser\FilterTypeGuesser();
    }

    /**
     * Gets the 'sonata.admin.guesser.orm_datagrid_chain' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Guesser\TypeGuesserChain A Sonata\AdminBundle\Guesser\TypeGuesserChain instance.
     */
    protected function getSonata_Admin_Guesser_OrmDatagridChainService()
    {
        return $this->services['sonata.admin.guesser.orm_datagrid_chain'] = new \Sonata\AdminBundle\Guesser\TypeGuesserChain(array(0 => $this->get('sonata.admin.guesser.orm_datagrid')));
    }

    /**
     * Gets the 'sonata.admin.guesser.orm_list' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Guesser\TypeGuesser A Sonata\DoctrineORMAdminBundle\Guesser\TypeGuesser instance.
     */
    protected function getSonata_Admin_Guesser_OrmListService()
    {
        return $this->services['sonata.admin.guesser.orm_list'] = new \Sonata\DoctrineORMAdminBundle\Guesser\TypeGuesser();
    }

    /**
     * Gets the 'sonata.admin.guesser.orm_list_chain' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Guesser\TypeGuesserChain A Sonata\AdminBundle\Guesser\TypeGuesserChain instance.
     */
    protected function getSonata_Admin_Guesser_OrmListChainService()
    {
        return $this->services['sonata.admin.guesser.orm_list_chain'] = new \Sonata\AdminBundle\Guesser\TypeGuesserChain(array(0 => $this->get('sonata.admin.guesser.orm_list')));
    }

    /**
     * Gets the 'sonata.admin.guesser.orm_show' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Guesser\TypeGuesser A Sonata\DoctrineORMAdminBundle\Guesser\TypeGuesser instance.
     */
    protected function getSonata_Admin_Guesser_OrmShowService()
    {
        return $this->services['sonata.admin.guesser.orm_show'] = new \Sonata\DoctrineORMAdminBundle\Guesser\TypeGuesser();
    }

    /**
     * Gets the 'sonata.admin.guesser.orm_show_chain' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Guesser\TypeGuesserChain A Sonata\AdminBundle\Guesser\TypeGuesserChain instance.
     */
    protected function getSonata_Admin_Guesser_OrmShowChainService()
    {
        return $this->services['sonata.admin.guesser.orm_show_chain'] = new \Sonata\AdminBundle\Guesser\TypeGuesserChain(array(0 => $this->get('sonata.admin.guesser.orm_show')));
    }

    /**
     * Gets the 'sonata.admin.helper' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Admin\AdminHelper A Sonata\AdminBundle\Admin\AdminHelper instance.
     */
    protected function getSonata_Admin_HelperService()
    {
        return $this->services['sonata.admin.helper'] = new \Sonata\AdminBundle\Admin\AdminHelper($this->get('sonata.admin.pool'));
    }

    /**
     * Gets the 'sonata.admin.label.strategy.bc' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Translator\BCLabelTranslatorStrategy A Sonata\AdminBundle\Translator\BCLabelTranslatorStrategy instance.
     */
    protected function getSonata_Admin_Label_Strategy_BcService()
    {
        return $this->services['sonata.admin.label.strategy.bc'] = new \Sonata\AdminBundle\Translator\BCLabelTranslatorStrategy();
    }

    /**
     * Gets the 'sonata.admin.label.strategy.form_component' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Translator\FormLabelTranslatorStrategy A Sonata\AdminBundle\Translator\FormLabelTranslatorStrategy instance.
     */
    protected function getSonata_Admin_Label_Strategy_FormComponentService()
    {
        return $this->services['sonata.admin.label.strategy.form_component'] = new \Sonata\AdminBundle\Translator\FormLabelTranslatorStrategy();
    }

    /**
     * Gets the 'sonata.admin.label.strategy.native' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Translator\NativeLabelTranslatorStrategy A Sonata\AdminBundle\Translator\NativeLabelTranslatorStrategy instance.
     */
    protected function getSonata_Admin_Label_Strategy_NativeService()
    {
        return $this->services['sonata.admin.label.strategy.native'] = new \Sonata\AdminBundle\Translator\NativeLabelTranslatorStrategy();
    }

    /**
     * Gets the 'sonata.admin.label.strategy.noop' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Translator\NoopLabelTranslatorStrategy A Sonata\AdminBundle\Translator\NoopLabelTranslatorStrategy instance.
     */
    protected function getSonata_Admin_Label_Strategy_NoopService()
    {
        return $this->services['sonata.admin.label.strategy.noop'] = new \Sonata\AdminBundle\Translator\NoopLabelTranslatorStrategy();
    }

    /**
     * Gets the 'sonata.admin.label.strategy.underscore' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Translator\UnderscoreLabelTranslatorStrategy A Sonata\AdminBundle\Translator\UnderscoreLabelTranslatorStrategy instance.
     */
    protected function getSonata_Admin_Label_Strategy_UnderscoreService()
    {
        return $this->services['sonata.admin.label.strategy.underscore'] = new \Sonata\AdminBundle\Translator\UnderscoreLabelTranslatorStrategy();
    }

    /**
     * Gets the 'sonata.admin.manager.orm' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Model\ModelManager A Sonata\DoctrineORMAdminBundle\Model\ModelManager instance.
     */
    protected function getSonata_Admin_Manager_OrmService()
    {
        return $this->services['sonata.admin.manager.orm'] = new \Sonata\DoctrineORMAdminBundle\Model\ModelManager($this->get('doctrine'));
    }

    /**
     * Gets the 'sonata.admin.manipulator.acl.admin' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Util\AdminAclManipulator A Sonata\AdminBundle\Util\AdminAclManipulator instance.
     */
    protected function getSonata_Admin_Manipulator_Acl_AdminService()
    {
        return $this->services['sonata.admin.manipulator.acl.admin'] = new \Sonata\AdminBundle\Util\AdminAclManipulator('Sonata\\AdminBundle\\Security\\Acl\\Permission\\MaskBuilder');
    }

    /**
     * Gets the 'sonata.admin.manipulator.acl.object.orm' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Util\ObjectAclManipulator A Sonata\DoctrineORMAdminBundle\Util\ObjectAclManipulator instance.
     */
    protected function getSonata_Admin_Manipulator_Acl_Object_OrmService()
    {
        return $this->services['sonata.admin.manipulator.acl.object.orm'] = new \Sonata\DoctrineORMAdminBundle\Util\ObjectAclManipulator();
    }

    /**
     * Gets the 'sonata.admin.object.manipulator.acl.admin' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Util\AdminObjectAclManipulator A Sonata\AdminBundle\Util\AdminObjectAclManipulator instance.
     */
    protected function getSonata_Admin_Object_Manipulator_Acl_AdminService()
    {
        return $this->services['sonata.admin.object.manipulator.acl.admin'] = new \Sonata\AdminBundle\Util\AdminObjectAclManipulator($this->get('form.factory'), 'Sonata\\AdminBundle\\Security\\Acl\\Permission\\MaskBuilder');
    }

    /**
     * Gets the 'sonata.admin.orm.filter.type.boolean' service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Filter\BooleanFilter A Sonata\DoctrineORMAdminBundle\Filter\BooleanFilter instance.
     */
    protected function getSonata_Admin_Orm_Filter_Type_BooleanService()
    {
        return new \Sonata\DoctrineORMAdminBundle\Filter\BooleanFilter();
    }

    /**
     * Gets the 'sonata.admin.orm.filter.type.callback' service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Filter\CallbackFilter A Sonata\DoctrineORMAdminBundle\Filter\CallbackFilter instance.
     */
    protected function getSonata_Admin_Orm_Filter_Type_CallbackService()
    {
        return new \Sonata\DoctrineORMAdminBundle\Filter\CallbackFilter();
    }

    /**
     * Gets the 'sonata.admin.orm.filter.type.choice' service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Filter\ChoiceFilter A Sonata\DoctrineORMAdminBundle\Filter\ChoiceFilter instance.
     */
    protected function getSonata_Admin_Orm_Filter_Type_ChoiceService()
    {
        return new \Sonata\DoctrineORMAdminBundle\Filter\ChoiceFilter();
    }

    /**
     * Gets the 'sonata.admin.orm.filter.type.class' service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Filter\ClassFilter A Sonata\DoctrineORMAdminBundle\Filter\ClassFilter instance.
     */
    protected function getSonata_Admin_Orm_Filter_Type_ClassService()
    {
        return new \Sonata\DoctrineORMAdminBundle\Filter\ClassFilter();
    }

    /**
     * Gets the 'sonata.admin.orm.filter.type.date' service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Filter\DateFilter A Sonata\DoctrineORMAdminBundle\Filter\DateFilter instance.
     */
    protected function getSonata_Admin_Orm_Filter_Type_DateService()
    {
        return new \Sonata\DoctrineORMAdminBundle\Filter\DateFilter();
    }

    /**
     * Gets the 'sonata.admin.orm.filter.type.date_range' service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Filter\DateRangeFilter A Sonata\DoctrineORMAdminBundle\Filter\DateRangeFilter instance.
     */
    protected function getSonata_Admin_Orm_Filter_Type_DateRangeService()
    {
        return new \Sonata\DoctrineORMAdminBundle\Filter\DateRangeFilter();
    }

    /**
     * Gets the 'sonata.admin.orm.filter.type.datetime' service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Filter\DateTimeFilter A Sonata\DoctrineORMAdminBundle\Filter\DateTimeFilter instance.
     */
    protected function getSonata_Admin_Orm_Filter_Type_DatetimeService()
    {
        return new \Sonata\DoctrineORMAdminBundle\Filter\DateTimeFilter();
    }

    /**
     * Gets the 'sonata.admin.orm.filter.type.datetime_range' service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Filter\DateTimeRangeFilter A Sonata\DoctrineORMAdminBundle\Filter\DateTimeRangeFilter instance.
     */
    protected function getSonata_Admin_Orm_Filter_Type_DatetimeRangeService()
    {
        return new \Sonata\DoctrineORMAdminBundle\Filter\DateTimeRangeFilter();
    }

    /**
     * Gets the 'sonata.admin.orm.filter.type.model' service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Filter\ModelFilter A Sonata\DoctrineORMAdminBundle\Filter\ModelFilter instance.
     */
    protected function getSonata_Admin_Orm_Filter_Type_ModelService()
    {
        return new \Sonata\DoctrineORMAdminBundle\Filter\ModelFilter();
    }

    /**
     * Gets the 'sonata.admin.orm.filter.type.number' service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Filter\NumberFilter A Sonata\DoctrineORMAdminBundle\Filter\NumberFilter instance.
     */
    protected function getSonata_Admin_Orm_Filter_Type_NumberService()
    {
        return new \Sonata\DoctrineORMAdminBundle\Filter\NumberFilter();
    }

    /**
     * Gets the 'sonata.admin.orm.filter.type.string' service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Filter\StringFilter A Sonata\DoctrineORMAdminBundle\Filter\StringFilter instance.
     */
    protected function getSonata_Admin_Orm_Filter_Type_StringService()
    {
        return new \Sonata\DoctrineORMAdminBundle\Filter\StringFilter();
    }

    /**
     * Gets the 'sonata.admin.orm.filter.type.time' service.
     *
     * @return \Sonata\DoctrineORMAdminBundle\Filter\TimeFilter A Sonata\DoctrineORMAdminBundle\Filter\TimeFilter instance.
     */
    protected function getSonata_Admin_Orm_Filter_Type_TimeService()
    {
        return new \Sonata\DoctrineORMAdminBundle\Filter\TimeFilter();
    }

    /**
     * Gets the 'sonata.admin.pool' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Admin\Pool A Sonata\AdminBundle\Admin\Pool instance.
     */
    protected function getSonata_Admin_PoolService()
    {
        $this->services['sonata.admin.pool'] = $instance = new \Sonata\AdminBundle\Admin\Pool($this, 'EdgeWebMedia', 'bundles/employee/images/Koala.jpg', array('html5_validate' => true, 'confirm_exit' => true, 'use_select2' => true, 'use_icheck' => true, 'pager_links' => NULL, 'form_type' => 'standard', 'dropdown_number_groups_per_colums' => 2, 'title_mode' => 'both', 'javascripts' => array(0 => 'bundles/sonataadmin/vendor/jquery/dist/jquery.min.js', 1 => 'bundles/sonataadmin/vendor/jquery.scrollTo/jquery.scrollTo.min.js', 2 => 'bundles/sonatacore/vendor/moment/min/moment.min.js', 3 => 'bundles/sonataadmin/vendor/bootstrap/dist/js/bootstrap.min.js', 4 => 'bundles/sonatacore/vendor/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js', 5 => 'bundles/sonataadmin/vendor/jqueryui/ui/minified/jquery-ui.min.js', 6 => 'bundles/sonataadmin/vendor/jqueryui/ui/minified/i18n/jquery-ui-i18n.min.js', 7 => 'bundles/sonataadmin/jquery/jquery.form.js', 8 => 'bundles/sonataadmin/jquery/jquery.confirmExit.js', 9 => 'bundles/sonataadmin/vendor/x-editable/dist/bootstrap3-editable/js/bootstrap-editable.min.js', 10 => 'bundles/sonataadmin/vendor/select2/select2.min.js', 11 => 'bundles/sonataadmin/App.js', 12 => 'bundles/sonataadmin/Admin.js'), 'stylesheets' => array(0 => 'bundles/sonataadmin/vendor/bootstrap/dist/css/bootstrap.min.css', 1 => 'bundles/sonataadmin/vendor/AdminLTE/css/font-awesome.min.css', 2 => 'bundles/sonataadmin/vendor/AdminLTE/css/ionicons.min.css', 3 => 'bundles/sonataadmin/vendor/AdminLTE/css/AdminLTE.css', 4 => 'bundles/sonatacore/vendor/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css', 5 => 'bundles/sonataadmin/vendor/jqueryui/themes/base/jquery-ui.css', 6 => 'bundles/sonataadmin/vendor/select2/select2.css', 7 => 'bundles/sonataadmin/vendor/select2/select2-bootstrap.css', 8 => 'bundles/sonataadmin/vendor/x-editable/dist/bootstrap3-editable/css/bootstrap-editable.css', 9 => 'bundles/sonataadmin/css/styles.css', 10 => 'bundles/sonataadmin/css/layout.css')), array());

        $instance->setTemplates(array('search' => 'SonataAdminBundle:Core:search.html.twig', 'search_result_block' => 'SonataAdminBundle:Block:block_search_result.html.twig', 'user_block' => 'SonataAdminBundle:Core:user_block.html.twig', 'add_block' => 'SonataAdminBundle:Core:add_block.html.twig', 'layout' => 'SonataAdminBundle::standard_layout.html.twig', 'ajax' => 'SonataAdminBundle::ajax_layout.html.twig', 'dashboard' => 'SonataAdminBundle:Core:dashboard.html.twig', 'list' => 'SonataAdminBundle:CRUD:list.html.twig', 'filter' => 'SonataAdminBundle:Form:filter_admin_fields.html.twig', 'show' => 'SonataAdminBundle:CRUD:show.html.twig', 'show_compare' => 'SonataAdminBundle:CRUD:show_compare.html.twig', 'edit' => 'SonataAdminBundle:CRUD:edit.html.twig', 'preview' => 'SonataAdminBundle:CRUD:preview.html.twig', 'history' => 'SonataAdminBundle:CRUD:history.html.twig', 'acl' => 'SonataAdminBundle:CRUD:acl.html.twig', 'history_revision_timestamp' => 'SonataAdminBundle:CRUD:history_revision_timestamp.html.twig', 'action' => 'SonataAdminBundle:CRUD:action.html.twig', 'select' => 'SonataAdminBundle:CRUD:list__select.html.twig', 'list_block' => 'SonataAdminBundle:Block:block_admin_list.html.twig', 'short_object_description' => 'SonataAdminBundle:Helper:short-object-description.html.twig', 'delete' => 'SonataAdminBundle:CRUD:delete.html.twig', 'batch' => 'SonataAdminBundle:CRUD:list__batch.html.twig', 'batch_confirmation' => 'SonataAdminBundle:CRUD:batch_confirmation.html.twig', 'inner_list_row' => 'SonataAdminBundle:CRUD:list_inner_row.html.twig', 'base_list_field' => 'SonataAdminBundle:CRUD:base_list_field.html.twig', 'pager_links' => 'SonataAdminBundle:Pager:links.html.twig', 'pager_results' => 'SonataAdminBundle:Pager:results.html.twig', 'tab_menu_template' => 'SonataAdminBundle:Core:tab_menu_template.html.twig'));
        $instance->setAdminServiceIds(array(0 => 'admin.department', 1 => 'admin.project'));
        $instance->setAdminGroups(array('default' => array('label' => 'default', 'label_catalogue' => 'SonataAdminBundle', 'icon' => '<i class="fa fa-folder"></i>', 'roles' => array(), 'items' => array(0 => 'admin.department', 1 => 'admin.project'))));
        $instance->setAdminClasses(array('EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department' => array(0 => 'admin.department'), 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Project' => array(0 => 'admin.project')));

        return $instance;
    }

    /**
     * Gets the 'sonata.admin.route.cache' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Route\RoutesCache A Sonata\AdminBundle\Route\RoutesCache instance.
     */
    protected function getSonata_Admin_Route_CacheService()
    {
        return $this->services['sonata.admin.route.cache'] = new \Sonata\AdminBundle\Route\RoutesCache((__DIR__.'/sonata/admin'), true);
    }

    /**
     * Gets the 'sonata.admin.route.cache_warmup' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Route\RoutesCacheWarmUp A Sonata\AdminBundle\Route\RoutesCacheWarmUp instance.
     */
    protected function getSonata_Admin_Route_CacheWarmupService()
    {
        return $this->services['sonata.admin.route.cache_warmup'] = new \Sonata\AdminBundle\Route\RoutesCacheWarmUp($this->get('sonata.admin.route.cache'), $this->get('sonata.admin.pool'));
    }

    /**
     * Gets the 'sonata.admin.route.default_generator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Route\DefaultRouteGenerator A Sonata\AdminBundle\Route\DefaultRouteGenerator instance.
     */
    protected function getSonata_Admin_Route_DefaultGeneratorService()
    {
        return $this->services['sonata.admin.route.default_generator'] = new \Sonata\AdminBundle\Route\DefaultRouteGenerator($this->get('router'), $this->get('sonata.admin.route.cache'));
    }

    /**
     * Gets the 'sonata.admin.route.path_info' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Route\PathInfoBuilder A Sonata\AdminBundle\Route\PathInfoBuilder instance.
     */
    protected function getSonata_Admin_Route_PathInfoService()
    {
        return $this->services['sonata.admin.route.path_info'] = new \Sonata\AdminBundle\Route\PathInfoBuilder($this->get('sonata.admin.audit.manager'));
    }

    /**
     * Gets the 'sonata.admin.route.query_string' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Route\QueryStringBuilder A Sonata\AdminBundle\Route\QueryStringBuilder instance.
     */
    protected function getSonata_Admin_Route_QueryStringService()
    {
        return $this->services['sonata.admin.route.query_string'] = new \Sonata\AdminBundle\Route\QueryStringBuilder($this->get('sonata.admin.audit.manager'));
    }

    /**
     * Gets the 'sonata.admin.route_loader' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Route\AdminPoolLoader A Sonata\AdminBundle\Route\AdminPoolLoader instance.
     */
    protected function getSonata_Admin_RouteLoaderService()
    {
        return $this->services['sonata.admin.route_loader'] = new \Sonata\AdminBundle\Route\AdminPoolLoader($this->get('sonata.admin.pool'), array(0 => 'admin.department', 1 => 'admin.project'), $this);
    }

    /**
     * Gets the 'sonata.admin.search.handler' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Search\SearchHandler A Sonata\AdminBundle\Search\SearchHandler instance.
     */
    protected function getSonata_Admin_Search_HandlerService()
    {
        return $this->services['sonata.admin.search.handler'] = new \Sonata\AdminBundle\Search\SearchHandler($this->get('sonata.admin.pool'));
    }

    /**
     * Gets the 'sonata.admin.security.handler' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Security\Handler\NoopSecurityHandler A Sonata\AdminBundle\Security\Handler\NoopSecurityHandler instance.
     */
    protected function getSonata_Admin_Security_HandlerService()
    {
        return $this->services['sonata.admin.security.handler'] = new \Sonata\AdminBundle\Security\Handler\NoopSecurityHandler();
    }

    /**
     * Gets the 'sonata.admin.twig.extension' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Twig\Extension\SonataAdminExtension A Sonata\AdminBundle\Twig\Extension\SonataAdminExtension instance.
     */
    protected function getSonata_Admin_Twig_ExtensionService()
    {
        return $this->services['sonata.admin.twig.extension'] = new \Sonata\AdminBundle\Twig\Extension\SonataAdminExtension($this->get('sonata.admin.pool'), $this->get('logger', ContainerInterface::NULL_ON_INVALID_REFERENCE));
    }

    /**
     * Gets the 'sonata.admin.validator.inline' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\AdminBundle\Validator\InlineValidator A Sonata\AdminBundle\Validator\InlineValidator instance.
     */
    protected function getSonata_Admin_Validator_InlineService()
    {
        return $this->services['sonata.admin.validator.inline'] = new \Sonata\AdminBundle\Validator\InlineValidator($this, $this->get('validator.validator_factory'));
    }

    /**
     * Gets the 'sonata.block.cache.handler.default' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Cache\HttpCacheHandler A Sonata\BlockBundle\Cache\HttpCacheHandler instance.
     */
    protected function getSonata_Block_Cache_Handler_DefaultService()
    {
        return $this->services['sonata.block.cache.handler.default'] = new \Sonata\BlockBundle\Cache\HttpCacheHandler();
    }

    /**
     * Gets the 'sonata.block.cache.handler.noop' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Cache\NoopHttpCacheHandler A Sonata\BlockBundle\Cache\NoopHttpCacheHandler instance.
     */
    protected function getSonata_Block_Cache_Handler_NoopService()
    {
        return $this->services['sonata.block.cache.handler.noop'] = new \Sonata\BlockBundle\Cache\NoopHttpCacheHandler();
    }

    /**
     * Gets the 'sonata.block.context_manager.default' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Block\BlockContextManager A Sonata\BlockBundle\Block\BlockContextManager instance.
     */
    protected function getSonata_Block_ContextManager_DefaultService()
    {
        return $this->services['sonata.block.context_manager.default'] = new \Sonata\BlockBundle\Block\BlockContextManager($this->get('sonata.block.loader.chain'), $this->get('sonata.block.manager'), array('by_type' => array('sonata.admin.block.admin_list' => 'sonata.cache.noop')), $this->get('logger', ContainerInterface::NULL_ON_INVALID_REFERENCE));
    }

    /**
     * Gets the 'sonata.block.exception.filter.debug_only' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Exception\Filter\DebugOnlyFilter A Sonata\BlockBundle\Exception\Filter\DebugOnlyFilter instance.
     */
    protected function getSonata_Block_Exception_Filter_DebugOnlyService()
    {
        return $this->services['sonata.block.exception.filter.debug_only'] = new \Sonata\BlockBundle\Exception\Filter\DebugOnlyFilter(true);
    }

    /**
     * Gets the 'sonata.block.exception.filter.ignore_block_exception' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Exception\Filter\IgnoreClassFilter A Sonata\BlockBundle\Exception\Filter\IgnoreClassFilter instance.
     */
    protected function getSonata_Block_Exception_Filter_IgnoreBlockExceptionService()
    {
        return $this->services['sonata.block.exception.filter.ignore_block_exception'] = new \Sonata\BlockBundle\Exception\Filter\IgnoreClassFilter('Sonata\\BlockBundle\\Exception\\BlockExceptionInterface');
    }

    /**
     * Gets the 'sonata.block.exception.filter.keep_all' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Exception\Filter\KeepAllFilter A Sonata\BlockBundle\Exception\Filter\KeepAllFilter instance.
     */
    protected function getSonata_Block_Exception_Filter_KeepAllService()
    {
        return $this->services['sonata.block.exception.filter.keep_all'] = new \Sonata\BlockBundle\Exception\Filter\KeepAllFilter();
    }

    /**
     * Gets the 'sonata.block.exception.filter.keep_none' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Exception\Filter\KeepNoneFilter A Sonata\BlockBundle\Exception\Filter\KeepNoneFilter instance.
     */
    protected function getSonata_Block_Exception_Filter_KeepNoneService()
    {
        return $this->services['sonata.block.exception.filter.keep_none'] = new \Sonata\BlockBundle\Exception\Filter\KeepNoneFilter();
    }

    /**
     * Gets the 'sonata.block.exception.renderer.inline' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Exception\Renderer\InlineRenderer A Sonata\BlockBundle\Exception\Renderer\InlineRenderer instance.
     */
    protected function getSonata_Block_Exception_Renderer_InlineService()
    {
        return $this->services['sonata.block.exception.renderer.inline'] = new \Sonata\BlockBundle\Exception\Renderer\InlineRenderer($this->get('templating'), 'SonataBlockBundle:Block:block_exception.html.twig');
    }

    /**
     * Gets the 'sonata.block.exception.renderer.inline_debug' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Exception\Renderer\InlineDebugRenderer A Sonata\BlockBundle\Exception\Renderer\InlineDebugRenderer instance.
     */
    protected function getSonata_Block_Exception_Renderer_InlineDebugService()
    {
        return $this->services['sonata.block.exception.renderer.inline_debug'] = new \Sonata\BlockBundle\Exception\Renderer\InlineDebugRenderer($this->get('templating'), 'SonataBlockBundle:Block:block_exception_debug.html.twig', true, true);
    }

    /**
     * Gets the 'sonata.block.exception.renderer.throw' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Exception\Renderer\MonkeyThrowRenderer A Sonata\BlockBundle\Exception\Renderer\MonkeyThrowRenderer instance.
     */
    protected function getSonata_Block_Exception_Renderer_ThrowService()
    {
        return $this->services['sonata.block.exception.renderer.throw'] = new \Sonata\BlockBundle\Exception\Renderer\MonkeyThrowRenderer();
    }

    /**
     * Gets the 'sonata.block.exception.strategy.manager' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Exception\Strategy\StrategyManager A Sonata\BlockBundle\Exception\Strategy\StrategyManager instance.
     */
    protected function getSonata_Block_Exception_Strategy_ManagerService()
    {
        $this->services['sonata.block.exception.strategy.manager'] = $instance = new \Sonata\BlockBundle\Exception\Strategy\StrategyManager($this, array('debug_only' => 'sonata.block.exception.filter.debug_only', 'ignore_block_exception' => 'sonata.block.exception.filter.ignore_block_exception', 'keep_all' => 'sonata.block.exception.filter.keep_all', 'keep_none' => 'sonata.block.exception.filter.keep_none'), array('inline' => 'sonata.block.exception.renderer.inline', 'inline_debug' => 'sonata.block.exception.renderer.inline_debug', 'throw' => 'sonata.block.exception.renderer.throw'), array(), array());

        $instance->setDefaultFilter('debug_only');
        $instance->setDefaultRenderer('throw');

        return $instance;
    }

    /**
     * Gets the 'sonata.block.form.type.block' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Form\Type\ServiceListType A Sonata\BlockBundle\Form\Type\ServiceListType instance.
     */
    protected function getSonata_Block_Form_Type_BlockService()
    {
        return $this->services['sonata.block.form.type.block'] = new \Sonata\BlockBundle\Form\Type\ServiceListType($this->get('sonata.block.manager'));
    }

    /**
     * Gets the 'sonata.block.form.type.container_template' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Form\Type\ContainerTemplateType A Sonata\BlockBundle\Form\Type\ContainerTemplateType instance.
     */
    protected function getSonata_Block_Form_Type_ContainerTemplateService()
    {
        return $this->services['sonata.block.form.type.container_template'] = new \Sonata\BlockBundle\Form\Type\ContainerTemplateType(array('SonataBlockBundle:Block:block_container.html.twig' => 'SonataBlockBundle default template'));
    }

    /**
     * Gets the 'sonata.block.loader.chain' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Block\BlockLoaderChain A Sonata\BlockBundle\Block\BlockLoaderChain instance.
     */
    protected function getSonata_Block_Loader_ChainService()
    {
        return $this->services['sonata.block.loader.chain'] = new \Sonata\BlockBundle\Block\BlockLoaderChain(array(0 => $this->get('sonata.block.loader.service')));
    }

    /**
     * Gets the 'sonata.block.loader.service' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Block\Loader\ServiceLoader A Sonata\BlockBundle\Block\Loader\ServiceLoader instance.
     */
    protected function getSonata_Block_Loader_ServiceService()
    {
        return $this->services['sonata.block.loader.service'] = new \Sonata\BlockBundle\Block\Loader\ServiceLoader(array(0 => 'sonata.admin.block.admin_list'));
    }

    /**
     * Gets the 'sonata.block.renderer.default' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Block\BlockRenderer A Sonata\BlockBundle\Block\BlockRenderer instance.
     */
    protected function getSonata_Block_Renderer_DefaultService()
    {
        return $this->services['sonata.block.renderer.default'] = new \Sonata\BlockBundle\Block\BlockRenderer($this->get('sonata.block.manager'), $this->get('sonata.block.exception.strategy.manager'), $this->get('logger', ContainerInterface::NULL_ON_INVALID_REFERENCE), true);
    }

    /**
     * Gets the 'sonata.block.service.container' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Block\Service\ContainerBlockService A Sonata\BlockBundle\Block\Service\ContainerBlockService instance.
     */
    protected function getSonata_Block_Service_ContainerService()
    {
        return $this->services['sonata.block.service.container'] = new \Sonata\BlockBundle\Block\Service\ContainerBlockService('sonata.block.container', $this->get('templating'));
    }

    /**
     * Gets the 'sonata.block.service.empty' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Block\Service\EmptyBlockService A Sonata\BlockBundle\Block\Service\EmptyBlockService instance.
     */
    protected function getSonata_Block_Service_EmptyService()
    {
        return $this->services['sonata.block.service.empty'] = new \Sonata\BlockBundle\Block\Service\EmptyBlockService('sonata.block.empty', $this->get('templating'));
    }

    /**
     * Gets the 'sonata.block.service.menu' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Block\Service\MenuBlockService A Sonata\BlockBundle\Block\Service\MenuBlockService instance.
     */
    protected function getSonata_Block_Service_MenuService()
    {
        return $this->services['sonata.block.service.menu'] = new \Sonata\BlockBundle\Block\Service\MenuBlockService('sonata.block.menu', $this->get('templating'), $this->get('knp_menu.menu_provider'), array());
    }

    /**
     * Gets the 'sonata.block.service.rss' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Block\Service\RssBlockService A Sonata\BlockBundle\Block\Service\RssBlockService instance.
     */
    protected function getSonata_Block_Service_RssService()
    {
        return $this->services['sonata.block.service.rss'] = new \Sonata\BlockBundle\Block\Service\RssBlockService('sonata.block.rss', $this->get('templating'));
    }

    /**
     * Gets the 'sonata.block.service.template' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Block\Service\TemplateBlockService A Sonata\BlockBundle\Block\Service\TemplateBlockService instance.
     */
    protected function getSonata_Block_Service_TemplateService()
    {
        return $this->services['sonata.block.service.template'] = new \Sonata\BlockBundle\Block\Service\TemplateBlockService('sonata.block.template', $this->get('templating'));
    }

    /**
     * Gets the 'sonata.block.service.text' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Block\Service\TextBlockService A Sonata\BlockBundle\Block\Service\TextBlockService instance.
     */
    protected function getSonata_Block_Service_TextService()
    {
        return $this->services['sonata.block.service.text'] = new \Sonata\BlockBundle\Block\Service\TextBlockService('sonata.block.text', $this->get('templating'));
    }

    /**
     * Gets the 'sonata.block.templating.helper' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Templating\Helper\BlockHelper A Sonata\BlockBundle\Templating\Helper\BlockHelper instance.
     */
    protected function getSonata_Block_Templating_HelperService()
    {
        return $this->services['sonata.block.templating.helper'] = new \Sonata\BlockBundle\Templating\Helper\BlockHelper($this->get('sonata.block.manager'), array('by_type' => array('sonata.admin.block.admin_list' => 'sonata.cache.noop')), $this->get('sonata.block.renderer.default'), $this->get('sonata.block.context_manager.default'), $this->get('debug.event_dispatcher'), NULL, $this->get('sonata.block.cache.handler.default', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('debug.stopwatch', ContainerInterface::NULL_ON_INVALID_REFERENCE));
    }

    /**
     * Gets the 'sonata.block.twig.global' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\BlockBundle\Twig\GlobalVariables A Sonata\BlockBundle\Twig\GlobalVariables instance.
     */
    protected function getSonata_Block_Twig_GlobalService()
    {
        return $this->services['sonata.block.twig.global'] = new \Sonata\BlockBundle\Twig\GlobalVariables(array('block_base' => 'SonataBlockBundle:Block:block_base.html.twig', 'block_container' => 'SonataBlockBundle:Block:block_container.html.twig'));
    }

    /**
     * Gets the 'sonata.core.date.moment_format_converter' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Date\MomentFormatConverter A Sonata\CoreBundle\Date\MomentFormatConverter instance.
     */
    protected function getSonata_Core_Date_MomentFormatConverterService()
    {
        return $this->services['sonata.core.date.moment_format_converter'] = new \Sonata\CoreBundle\Date\MomentFormatConverter();
    }

    /**
     * Gets the 'sonata.core.flashmessage.manager' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\FlashMessage\FlashManager A Sonata\CoreBundle\FlashMessage\FlashManager instance.
     */
    protected function getSonata_Core_Flashmessage_ManagerService()
    {
        return $this->services['sonata.core.flashmessage.manager'] = new \Sonata\CoreBundle\FlashMessage\FlashManager($this->get('session'), $this->get('translator'), array('success' => array('success' => array('domain' => 'SonataCoreBundle'), 'sonata_flash_success' => array('domain' => 'SonataAdminBundle'), 'sonata_user_success' => array('domain' => 'SonataUserBundle'), 'fos_user_success' => array('domain' => 'FOSUserBundle')), 'warning' => array('warning' => array('domain' => 'SonataCoreBundle'), 'sonata_flash_info' => array('domain' => 'SonataAdminBundle')), 'danger' => array('error' => array('domain' => 'SonataCoreBundle'), 'sonata_flash_error' => array('domain' => 'SonataAdminBundle'), 'sonata_user_error' => array('domain' => 'SonataUserBundle'))), array('success' => 'success', 'warning' => 'warning', 'danger' => 'danger'));
    }

    /**
     * Gets the 'sonata.core.flashmessage.twig.extension' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Twig\Extension\FlashMessageExtension A Sonata\CoreBundle\Twig\Extension\FlashMessageExtension instance.
     */
    protected function getSonata_Core_Flashmessage_Twig_ExtensionService()
    {
        return $this->services['sonata.core.flashmessage.twig.extension'] = new \Sonata\CoreBundle\Twig\Extension\FlashMessageExtension($this->get('sonata.core.flashmessage.manager'));
    }

    /**
     * Gets the 'sonata.core.form.type.array' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Form\Type\ImmutableArrayType A Sonata\CoreBundle\Form\Type\ImmutableArrayType instance.
     */
    protected function getSonata_Core_Form_Type_ArrayService()
    {
        return $this->services['sonata.core.form.type.array'] = new \Sonata\CoreBundle\Form\Type\ImmutableArrayType();
    }

    /**
     * Gets the 'sonata.core.form.type.boolean' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Form\Type\BooleanType A Sonata\CoreBundle\Form\Type\BooleanType instance.
     */
    protected function getSonata_Core_Form_Type_BooleanService()
    {
        return $this->services['sonata.core.form.type.boolean'] = new \Sonata\CoreBundle\Form\Type\BooleanType();
    }

    /**
     * Gets the 'sonata.core.form.type.collection' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Form\Type\CollectionType A Sonata\CoreBundle\Form\Type\CollectionType instance.
     */
    protected function getSonata_Core_Form_Type_CollectionService()
    {
        return $this->services['sonata.core.form.type.collection'] = new \Sonata\CoreBundle\Form\Type\CollectionType();
    }

    /**
     * Gets the 'sonata.core.form.type.color_selector' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Form\Type\ColorSelectorType A Sonata\CoreBundle\Form\Type\ColorSelectorType instance.
     */
    protected function getSonata_Core_Form_Type_ColorSelectorService()
    {
        return $this->services['sonata.core.form.type.color_selector'] = new \Sonata\CoreBundle\Form\Type\ColorSelectorType();
    }

    /**
     * Gets the 'sonata.core.form.type.date_picker' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Form\Type\DatePickerType A Sonata\CoreBundle\Form\Type\DatePickerType instance.
     */
    protected function getSonata_Core_Form_Type_DatePickerService()
    {
        return $this->services['sonata.core.form.type.date_picker'] = new \Sonata\CoreBundle\Form\Type\DatePickerType($this->get('sonata.core.date.moment_format_converter'));
    }

    /**
     * Gets the 'sonata.core.form.type.date_range' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Form\Type\DateRangeType A Sonata\CoreBundle\Form\Type\DateRangeType instance.
     */
    protected function getSonata_Core_Form_Type_DateRangeService()
    {
        return $this->services['sonata.core.form.type.date_range'] = new \Sonata\CoreBundle\Form\Type\DateRangeType($this->get('translator'));
    }

    /**
     * Gets the 'sonata.core.form.type.date_range_picker' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Form\Type\DateRangePickerType A Sonata\CoreBundle\Form\Type\DateRangePickerType instance.
     */
    protected function getSonata_Core_Form_Type_DateRangePickerService()
    {
        return $this->services['sonata.core.form.type.date_range_picker'] = new \Sonata\CoreBundle\Form\Type\DateRangePickerType($this->get('translator'));
    }

    /**
     * Gets the 'sonata.core.form.type.datetime_picker' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Form\Type\DateTimePickerType A Sonata\CoreBundle\Form\Type\DateTimePickerType instance.
     */
    protected function getSonata_Core_Form_Type_DatetimePickerService()
    {
        return $this->services['sonata.core.form.type.datetime_picker'] = new \Sonata\CoreBundle\Form\Type\DateTimePickerType($this->get('sonata.core.date.moment_format_converter'));
    }

    /**
     * Gets the 'sonata.core.form.type.datetime_range' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Form\Type\DateTimeRangeType A Sonata\CoreBundle\Form\Type\DateTimeRangeType instance.
     */
    protected function getSonata_Core_Form_Type_DatetimeRangeService()
    {
        return $this->services['sonata.core.form.type.datetime_range'] = new \Sonata\CoreBundle\Form\Type\DateTimeRangeType($this->get('translator'));
    }

    /**
     * Gets the 'sonata.core.form.type.datetime_range_picker' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Form\Type\DateTimeRangePickerType A Sonata\CoreBundle\Form\Type\DateTimeRangePickerType instance.
     */
    protected function getSonata_Core_Form_Type_DatetimeRangePickerService()
    {
        return $this->services['sonata.core.form.type.datetime_range_picker'] = new \Sonata\CoreBundle\Form\Type\DateTimeRangePickerType($this->get('translator'));
    }

    /**
     * Gets the 'sonata.core.form.type.equal' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Form\Type\EqualType A Sonata\CoreBundle\Form\Type\EqualType instance.
     */
    protected function getSonata_Core_Form_Type_EqualService()
    {
        return $this->services['sonata.core.form.type.equal'] = new \Sonata\CoreBundle\Form\Type\EqualType($this->get('translator'));
    }

    /**
     * Gets the 'sonata.core.form.type.translatable_choice' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Form\Type\TranslatableChoiceType A Sonata\CoreBundle\Form\Type\TranslatableChoiceType instance.
     */
    protected function getSonata_Core_Form_Type_TranslatableChoiceService()
    {
        return $this->services['sonata.core.form.type.translatable_choice'] = new \Sonata\CoreBundle\Form\Type\TranslatableChoiceType($this->get('translator'));
    }

    /**
     * Gets the 'sonata.core.model.adapter.chain' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Model\Adapter\AdapterChain A Sonata\CoreBundle\Model\Adapter\AdapterChain instance.
     */
    protected function getSonata_Core_Model_Adapter_ChainService()
    {
        $this->services['sonata.core.model.adapter.chain'] = $instance = new \Sonata\CoreBundle\Model\Adapter\AdapterChain();

        $instance->addAdapter(new \Sonata\CoreBundle\Model\Adapter\DoctrineORMAdapter($this->get('doctrine', ContainerInterface::NULL_ON_INVALID_REFERENCE)));

        return $instance;
    }

    /**
     * Gets the 'sonata.core.slugify.cocur' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Cocur\Slugify\Slugify A Cocur\Slugify\Slugify instance.
     */
    protected function getSonata_Core_Slugify_CocurService()
    {
        return $this->services['sonata.core.slugify.cocur'] = new \Cocur\Slugify\Slugify();
    }

    /**
     * Gets the 'sonata.core.slugify.native' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Component\NativeSlugify A Sonata\CoreBundle\Component\NativeSlugify instance.
     */
    protected function getSonata_Core_Slugify_NativeService()
    {
        return $this->services['sonata.core.slugify.native'] = new \Sonata\CoreBundle\Component\NativeSlugify();
    }

    /**
     * Gets the 'sonata.core.twig.extension.text' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Twig_Extensions_Extension_Text A Twig_Extensions_Extension_Text instance.
     */
    protected function getSonata_Core_Twig_Extension_TextService()
    {
        return $this->services['sonata.core.twig.extension.text'] = new \Twig_Extensions_Extension_Text();
    }

    /**
     * Gets the 'sonata.core.twig.extension.wrapping' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Twig\Extension\FormTypeExtension A Sonata\CoreBundle\Twig\Extension\FormTypeExtension instance.
     */
    protected function getSonata_Core_Twig_Extension_WrappingService()
    {
        return $this->services['sonata.core.twig.extension.wrapping'] = new \Sonata\CoreBundle\Twig\Extension\FormTypeExtension('standard');
    }

    /**
     * Gets the 'sonata.core.twig.status_extension' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Twig\Extension\StatusExtension A Sonata\CoreBundle\Twig\Extension\StatusExtension instance.
     */
    protected function getSonata_Core_Twig_StatusExtensionService()
    {
        $this->services['sonata.core.twig.status_extension'] = $instance = new \Sonata\CoreBundle\Twig\Extension\StatusExtension();

        $instance->addStatusService($this->get('sonata.core.flashmessage.manager'));

        return $instance;
    }

    /**
     * Gets the 'sonata.core.twig.template_extension' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Twig\Extension\TemplateExtension A Sonata\CoreBundle\Twig\Extension\TemplateExtension instance.
     */
    protected function getSonata_Core_Twig_TemplateExtensionService()
    {
        return $this->services['sonata.core.twig.template_extension'] = new \Sonata\CoreBundle\Twig\Extension\TemplateExtension(true, $this->get('translator'), $this->get('sonata.core.model.adapter.chain'));
    }

    /**
     * Gets the 'sonata.core.validator.inline' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Sonata\CoreBundle\Validator\InlineValidator A Sonata\CoreBundle\Validator\InlineValidator instance.
     */
    protected function getSonata_Core_Validator_InlineService()
    {
        return $this->services['sonata.core.validator.inline'] = new \Sonata\CoreBundle\Validator\InlineValidator($this, $this->get('validator.validator_factory'));
    }

    /**
     * Gets the 'stof_doctrine_extensions.uploadable.manager' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Stof\DoctrineExtensionsBundle\Uploadable\UploadableManager A Stof\DoctrineExtensionsBundle\Uploadable\UploadableManager instance.
     */
    protected function getStofDoctrineExtensions_Uploadable_ManagerService()
    {
        $a = new \Gedmo\Uploadable\UploadableListener(new \Stof\DoctrineExtensionsBundle\Uploadable\MimeTypeGuesserAdapter());
        $a->setAnnotationReader($this->get('annotation_reader'));
        $a->setDefaultFileInfoClass('Stof\\DoctrineExtensionsBundle\\Uploadable\\UploadedFileInfo');

        return $this->services['stof_doctrine_extensions.uploadable.manager'] = new \Stof\DoctrineExtensionsBundle\Uploadable\UploadableManager($a, 'Stof\\DoctrineExtensionsBundle\\Uploadable\\UploadedFileInfo');
    }

    /**
     * Gets the 'streamed_response_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\StreamedResponseListener A Symfony\Component\HttpKernel\EventListener\StreamedResponseListener instance.
     */
    protected function getStreamedResponseListenerService()
    {
        return $this->services['streamed_response_listener'] = new \Symfony\Component\HttpKernel\EventListener\StreamedResponseListener();
    }

    /**
     * Gets the 'swiftmailer.email_sender.listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\SwiftmailerBundle\EventListener\EmailSenderListener A Symfony\Bundle\SwiftmailerBundle\EventListener\EmailSenderListener instance.
     */
    protected function getSwiftmailer_EmailSender_ListenerService()
    {
        return $this->services['swiftmailer.email_sender.listener'] = new \Symfony\Bundle\SwiftmailerBundle\EventListener\EmailSenderListener($this, $this->get('logger', ContainerInterface::NULL_ON_INVALID_REFERENCE));
    }

    /**
     * Gets the 'swiftmailer.mailer.default' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Swift_Mailer A Swift_Mailer instance.
     */
    protected function getSwiftmailer_Mailer_DefaultService()
    {
        return $this->services['swiftmailer.mailer.default'] = new \Swift_Mailer($this->get('swiftmailer.mailer.default.transport'));
    }

    /**
     * Gets the 'swiftmailer.mailer.default.plugin.messagelogger' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Swift_Plugins_MessageLogger A Swift_Plugins_MessageLogger instance.
     */
    protected function getSwiftmailer_Mailer_Default_Plugin_MessageloggerService()
    {
        return $this->services['swiftmailer.mailer.default.plugin.messagelogger'] = new \Swift_Plugins_MessageLogger();
    }

    /**
     * Gets the 'swiftmailer.mailer.default.spool' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Swift_MemorySpool A Swift_MemorySpool instance.
     */
    protected function getSwiftmailer_Mailer_Default_SpoolService()
    {
        return $this->services['swiftmailer.mailer.default.spool'] = new \Swift_MemorySpool();
    }

    /**
     * Gets the 'swiftmailer.mailer.default.transport' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Swift_Transport_SpoolTransport A Swift_Transport_SpoolTransport instance.
     */
    protected function getSwiftmailer_Mailer_Default_TransportService()
    {
        $this->services['swiftmailer.mailer.default.transport'] = $instance = new \Swift_Transport_SpoolTransport($this->get('swiftmailer.mailer.default.transport.eventdispatcher'), $this->get('swiftmailer.mailer.default.spool'));

        $instance->registerPlugin($this->get('swiftmailer.mailer.default.plugin.messagelogger'));

        return $instance;
    }

    /**
     * Gets the 'swiftmailer.mailer.default.transport.real' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Swift_Transport_EsmtpTransport A Swift_Transport_EsmtpTransport instance.
     */
    protected function getSwiftmailer_Mailer_Default_Transport_RealService()
    {
        $a = new \Swift_Transport_Esmtp_AuthHandler(array(0 => new \Swift_Transport_Esmtp_Auth_CramMd5Authenticator(), 1 => new \Swift_Transport_Esmtp_Auth_LoginAuthenticator(), 2 => new \Swift_Transport_Esmtp_Auth_PlainAuthenticator()));
        $a->setUsername(NULL);
        $a->setPassword(NULL);
        $a->setAuthMode(NULL);

        $this->services['swiftmailer.mailer.default.transport.real'] = $instance = new \Swift_Transport_EsmtpTransport(new \Swift_Transport_StreamBuffer(new \Swift_StreamFilters_StringReplacementFilterFactory()), array(0 => $a), $this->get('swiftmailer.mailer.default.transport.eventdispatcher'));

        $instance->setHost('127.0.0.1');
        $instance->setPort(25);
        $instance->setEncryption(NULL);
        $instance->setTimeout(30);
        $instance->setSourceIp(NULL);

        return $instance;
    }

    /**
     * Gets the 'templating' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\TwigBundle\TwigEngine A Symfony\Bundle\TwigBundle\TwigEngine instance.
     */
    protected function getTemplatingService()
    {
        return $this->services['templating'] = new \Symfony\Bundle\TwigBundle\TwigEngine($this->get('twig'), $this->get('templating.name_parser'), $this->get('templating.locator'));
    }

    /**
     * Gets the 'templating.filename_parser' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Templating\TemplateFilenameParser A Symfony\Bundle\FrameworkBundle\Templating\TemplateFilenameParser instance.
     */
    protected function getTemplating_FilenameParserService()
    {
        return $this->services['templating.filename_parser'] = new \Symfony\Bundle\FrameworkBundle\Templating\TemplateFilenameParser();
    }

    /**
     * Gets the 'templating.helper.assets' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Templating\Helper\AssetsHelper A Symfony\Bundle\FrameworkBundle\Templating\Helper\AssetsHelper instance.
     */
    protected function getTemplating_Helper_AssetsService()
    {
        return $this->services['templating.helper.assets'] = new \Symfony\Bundle\FrameworkBundle\Templating\Helper\AssetsHelper($this->get('assets.packages'), array());
    }

    /**
     * Gets the 'templating.helper.logout_url' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\SecurityBundle\Templating\Helper\LogoutUrlHelper A Symfony\Bundle\SecurityBundle\Templating\Helper\LogoutUrlHelper instance.
     */
    protected function getTemplating_Helper_LogoutUrlService()
    {
        return $this->services['templating.helper.logout_url'] = new \Symfony\Bundle\SecurityBundle\Templating\Helper\LogoutUrlHelper($this->get('security.logout_url_generator'));
    }

    /**
     * Gets the 'templating.helper.router' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Templating\Helper\RouterHelper A Symfony\Bundle\FrameworkBundle\Templating\Helper\RouterHelper instance.
     */
    protected function getTemplating_Helper_RouterService()
    {
        return $this->services['templating.helper.router'] = new \Symfony\Bundle\FrameworkBundle\Templating\Helper\RouterHelper($this->get('router'));
    }

    /**
     * Gets the 'templating.helper.security' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\SecurityBundle\Templating\Helper\SecurityHelper A Symfony\Bundle\SecurityBundle\Templating\Helper\SecurityHelper instance.
     */
    protected function getTemplating_Helper_SecurityService()
    {
        return $this->services['templating.helper.security'] = new \Symfony\Bundle\SecurityBundle\Templating\Helper\SecurityHelper($this->get('security.authorization_checker', ContainerInterface::NULL_ON_INVALID_REFERENCE));
    }

    /**
     * Gets the 'templating.loader' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Templating\Loader\FilesystemLoader A Symfony\Bundle\FrameworkBundle\Templating\Loader\FilesystemLoader instance.
     */
    protected function getTemplating_LoaderService()
    {
        return $this->services['templating.loader'] = new \Symfony\Bundle\FrameworkBundle\Templating\Loader\FilesystemLoader($this->get('templating.locator'));
    }

    /**
     * Gets the 'templating.name_parser' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Templating\TemplateNameParser A Symfony\Bundle\FrameworkBundle\Templating\TemplateNameParser instance.
     */
    protected function getTemplating_NameParserService()
    {
        return $this->services['templating.name_parser'] = new \Symfony\Bundle\FrameworkBundle\Templating\TemplateNameParser($this->get('kernel'));
    }

    /**
     * Gets the 'translation.dumper.csv' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Dumper\CsvFileDumper A Symfony\Component\Translation\Dumper\CsvFileDumper instance.
     */
    protected function getTranslation_Dumper_CsvService()
    {
        return $this->services['translation.dumper.csv'] = new \Symfony\Component\Translation\Dumper\CsvFileDumper();
    }

    /**
     * Gets the 'translation.dumper.ini' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Dumper\IniFileDumper A Symfony\Component\Translation\Dumper\IniFileDumper instance.
     */
    protected function getTranslation_Dumper_IniService()
    {
        return $this->services['translation.dumper.ini'] = new \Symfony\Component\Translation\Dumper\IniFileDumper();
    }

    /**
     * Gets the 'translation.dumper.json' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Dumper\JsonFileDumper A Symfony\Component\Translation\Dumper\JsonFileDumper instance.
     */
    protected function getTranslation_Dumper_JsonService()
    {
        return $this->services['translation.dumper.json'] = new \Symfony\Component\Translation\Dumper\JsonFileDumper();
    }

    /**
     * Gets the 'translation.dumper.mo' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Dumper\MoFileDumper A Symfony\Component\Translation\Dumper\MoFileDumper instance.
     */
    protected function getTranslation_Dumper_MoService()
    {
        return $this->services['translation.dumper.mo'] = new \Symfony\Component\Translation\Dumper\MoFileDumper();
    }

    /**
     * Gets the 'translation.dumper.php' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Dumper\PhpFileDumper A Symfony\Component\Translation\Dumper\PhpFileDumper instance.
     */
    protected function getTranslation_Dumper_PhpService()
    {
        return $this->services['translation.dumper.php'] = new \Symfony\Component\Translation\Dumper\PhpFileDumper();
    }

    /**
     * Gets the 'translation.dumper.po' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Dumper\PoFileDumper A Symfony\Component\Translation\Dumper\PoFileDumper instance.
     */
    protected function getTranslation_Dumper_PoService()
    {
        return $this->services['translation.dumper.po'] = new \Symfony\Component\Translation\Dumper\PoFileDumper();
    }

    /**
     * Gets the 'translation.dumper.qt' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Dumper\QtFileDumper A Symfony\Component\Translation\Dumper\QtFileDumper instance.
     */
    protected function getTranslation_Dumper_QtService()
    {
        return $this->services['translation.dumper.qt'] = new \Symfony\Component\Translation\Dumper\QtFileDumper();
    }

    /**
     * Gets the 'translation.dumper.res' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Dumper\IcuResFileDumper A Symfony\Component\Translation\Dumper\IcuResFileDumper instance.
     */
    protected function getTranslation_Dumper_ResService()
    {
        return $this->services['translation.dumper.res'] = new \Symfony\Component\Translation\Dumper\IcuResFileDumper();
    }

    /**
     * Gets the 'translation.dumper.xliff' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Dumper\XliffFileDumper A Symfony\Component\Translation\Dumper\XliffFileDumper instance.
     */
    protected function getTranslation_Dumper_XliffService()
    {
        return $this->services['translation.dumper.xliff'] = new \Symfony\Component\Translation\Dumper\XliffFileDumper();
    }

    /**
     * Gets the 'translation.dumper.yml' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Dumper\YamlFileDumper A Symfony\Component\Translation\Dumper\YamlFileDumper instance.
     */
    protected function getTranslation_Dumper_YmlService()
    {
        return $this->services['translation.dumper.yml'] = new \Symfony\Component\Translation\Dumper\YamlFileDumper();
    }

    /**
     * Gets the 'translation.extractor' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Extractor\ChainExtractor A Symfony\Component\Translation\Extractor\ChainExtractor instance.
     */
    protected function getTranslation_ExtractorService()
    {
        $this->services['translation.extractor'] = $instance = new \Symfony\Component\Translation\Extractor\ChainExtractor();

        $instance->addExtractor('php', $this->get('translation.extractor.php'));
        $instance->addExtractor('twig', $this->get('twig.translation.extractor'));

        return $instance;
    }

    /**
     * Gets the 'translation.extractor.php' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Translation\PhpExtractor A Symfony\Bundle\FrameworkBundle\Translation\PhpExtractor instance.
     */
    protected function getTranslation_Extractor_PhpService()
    {
        return $this->services['translation.extractor.php'] = new \Symfony\Bundle\FrameworkBundle\Translation\PhpExtractor();
    }

    /**
     * Gets the 'translation.loader' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Translation\TranslationLoader A Symfony\Bundle\FrameworkBundle\Translation\TranslationLoader instance.
     */
    protected function getTranslation_LoaderService()
    {
        $a = $this->get('translation.loader.xliff');

        $this->services['translation.loader'] = $instance = new \Symfony\Bundle\FrameworkBundle\Translation\TranslationLoader();

        $instance->addLoader('php', $this->get('translation.loader.php'));
        $instance->addLoader('yml', $this->get('translation.loader.yml'));
        $instance->addLoader('xlf', $a);
        $instance->addLoader('xliff', $a);
        $instance->addLoader('po', $this->get('translation.loader.po'));
        $instance->addLoader('mo', $this->get('translation.loader.mo'));
        $instance->addLoader('ts', $this->get('translation.loader.qt'));
        $instance->addLoader('csv', $this->get('translation.loader.csv'));
        $instance->addLoader('res', $this->get('translation.loader.res'));
        $instance->addLoader('dat', $this->get('translation.loader.dat'));
        $instance->addLoader('ini', $this->get('translation.loader.ini'));
        $instance->addLoader('json', $this->get('translation.loader.json'));

        return $instance;
    }

    /**
     * Gets the 'translation.loader.csv' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Loader\CsvFileLoader A Symfony\Component\Translation\Loader\CsvFileLoader instance.
     */
    protected function getTranslation_Loader_CsvService()
    {
        return $this->services['translation.loader.csv'] = new \Symfony\Component\Translation\Loader\CsvFileLoader();
    }

    /**
     * Gets the 'translation.loader.dat' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Loader\IcuDatFileLoader A Symfony\Component\Translation\Loader\IcuDatFileLoader instance.
     */
    protected function getTranslation_Loader_DatService()
    {
        return $this->services['translation.loader.dat'] = new \Symfony\Component\Translation\Loader\IcuDatFileLoader();
    }

    /**
     * Gets the 'translation.loader.ini' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Loader\IniFileLoader A Symfony\Component\Translation\Loader\IniFileLoader instance.
     */
    protected function getTranslation_Loader_IniService()
    {
        return $this->services['translation.loader.ini'] = new \Symfony\Component\Translation\Loader\IniFileLoader();
    }

    /**
     * Gets the 'translation.loader.json' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Loader\JsonFileLoader A Symfony\Component\Translation\Loader\JsonFileLoader instance.
     */
    protected function getTranslation_Loader_JsonService()
    {
        return $this->services['translation.loader.json'] = new \Symfony\Component\Translation\Loader\JsonFileLoader();
    }

    /**
     * Gets the 'translation.loader.mo' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Loader\MoFileLoader A Symfony\Component\Translation\Loader\MoFileLoader instance.
     */
    protected function getTranslation_Loader_MoService()
    {
        return $this->services['translation.loader.mo'] = new \Symfony\Component\Translation\Loader\MoFileLoader();
    }

    /**
     * Gets the 'translation.loader.php' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Loader\PhpFileLoader A Symfony\Component\Translation\Loader\PhpFileLoader instance.
     */
    protected function getTranslation_Loader_PhpService()
    {
        return $this->services['translation.loader.php'] = new \Symfony\Component\Translation\Loader\PhpFileLoader();
    }

    /**
     * Gets the 'translation.loader.po' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Loader\PoFileLoader A Symfony\Component\Translation\Loader\PoFileLoader instance.
     */
    protected function getTranslation_Loader_PoService()
    {
        return $this->services['translation.loader.po'] = new \Symfony\Component\Translation\Loader\PoFileLoader();
    }

    /**
     * Gets the 'translation.loader.qt' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Loader\QtFileLoader A Symfony\Component\Translation\Loader\QtFileLoader instance.
     */
    protected function getTranslation_Loader_QtService()
    {
        return $this->services['translation.loader.qt'] = new \Symfony\Component\Translation\Loader\QtFileLoader();
    }

    /**
     * Gets the 'translation.loader.res' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Loader\IcuResFileLoader A Symfony\Component\Translation\Loader\IcuResFileLoader instance.
     */
    protected function getTranslation_Loader_ResService()
    {
        return $this->services['translation.loader.res'] = new \Symfony\Component\Translation\Loader\IcuResFileLoader();
    }

    /**
     * Gets the 'translation.loader.xliff' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Loader\XliffFileLoader A Symfony\Component\Translation\Loader\XliffFileLoader instance.
     */
    protected function getTranslation_Loader_XliffService()
    {
        return $this->services['translation.loader.xliff'] = new \Symfony\Component\Translation\Loader\XliffFileLoader();
    }

    /**
     * Gets the 'translation.loader.yml' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Loader\YamlFileLoader A Symfony\Component\Translation\Loader\YamlFileLoader instance.
     */
    protected function getTranslation_Loader_YmlService()
    {
        return $this->services['translation.loader.yml'] = new \Symfony\Component\Translation\Loader\YamlFileLoader();
    }

    /**
     * Gets the 'translation.writer' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\Writer\TranslationWriter A Symfony\Component\Translation\Writer\TranslationWriter instance.
     */
    protected function getTranslation_WriterService()
    {
        $this->services['translation.writer'] = $instance = new \Symfony\Component\Translation\Writer\TranslationWriter();

        $instance->addDumper('php', $this->get('translation.dumper.php'));
        $instance->addDumper('xlf', $this->get('translation.dumper.xliff'));
        $instance->addDumper('po', $this->get('translation.dumper.po'));
        $instance->addDumper('mo', $this->get('translation.dumper.mo'));
        $instance->addDumper('yml', $this->get('translation.dumper.yml'));
        $instance->addDumper('ts', $this->get('translation.dumper.qt'));
        $instance->addDumper('csv', $this->get('translation.dumper.csv'));
        $instance->addDumper('ini', $this->get('translation.dumper.ini'));
        $instance->addDumper('json', $this->get('translation.dumper.json'));
        $instance->addDumper('res', $this->get('translation.dumper.res'));

        return $instance;
    }

    /**
     * Gets the 'translator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Translation\DataCollectorTranslator A Symfony\Component\Translation\DataCollectorTranslator instance.
     */
    protected function getTranslatorService()
    {
        return $this->services['translator'] = new \Symfony\Component\Translation\DataCollectorTranslator(new \Symfony\Component\Translation\LoggingTranslator($this->get('translator.default'), $this->get('monolog.logger.translation')));
    }

    /**
     * Gets the 'translator.default' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Translation\Translator A Symfony\Bundle\FrameworkBundle\Translation\Translator instance.
     */
    protected function getTranslator_DefaultService()
    {
        $this->services['translator.default'] = $instance = new \Symfony\Bundle\FrameworkBundle\Translation\Translator($this, new \Symfony\Component\Translation\MessageSelector(), array('translation.loader.php' => array(0 => 'php'), 'translation.loader.yml' => array(0 => 'yml'), 'translation.loader.xliff' => array(0 => 'xlf', 1 => 'xliff'), 'translation.loader.po' => array(0 => 'po'), 'translation.loader.mo' => array(0 => 'mo'), 'translation.loader.qt' => array(0 => 'ts'), 'translation.loader.csv' => array(0 => 'csv'), 'translation.loader.res' => array(0 => 'res'), 'translation.loader.dat' => array(0 => 'dat'), 'translation.loader.ini' => array(0 => 'ini'), 'translation.loader.json' => array(0 => 'json')), array('cache_dir' => (__DIR__.'/translations'), 'debug' => true, 'resource_files' => array('af' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.af.xlf')), 'ar' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.ar.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.ar.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.ar.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.ar.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.ar.yml'), 5 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.ar.xliff'), 6 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.ar.xliff')), 'az' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.az.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.az.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.az.xlf')), 'bg' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.bg.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.bg.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.bg.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.bg.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.bg.yml'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.bg.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.bg.xlf'), 7 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.bg.xliff'), 8 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.bg.xliff')), 'ca' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.ca.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.ca.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.ca.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.ca.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.ca.yml'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.ca.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.ca.xlf'), 7 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.ca.xliff'), 8 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.ca.xliff')), 'cs' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.cs.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.cs.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.cs.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.cs.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.cs.yml'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.cs.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.cs.xlf'), 7 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.cs.xliff'), 8 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.cs.xliff')), 'cy' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.cy.xlf')), 'da' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.da.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.da.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.da.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.da.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.da.yml')), 'de' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.de.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.de.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.de.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.de.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.de.yml'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.de.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.de.xlf'), 7 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.de.xliff'), 8 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.de.xliff')), 'el' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.el.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.el.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.el.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.el.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.el.yml')), 'en' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.en.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.en.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.en.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.en.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.en.yml'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.en.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.en.xlf'), 7 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.en.xliff'), 8 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.en.xliff')), 'es' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.es.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.es.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.es.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.es.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.es.yml'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.es.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.es.xlf'), 7 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.es.xliff'), 8 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.es.xliff')), 'et' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.et.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.et.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.et.yml')), 'eu' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.eu.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.eu.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.eu.yml'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.eu.yml'), 4 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.eu.xlf'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.eu.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.eu.xliff'), 7 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.eu.xliff')), 'fa' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.fa.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.fa.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.fa.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.fa.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.fa.yml'), 5 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.fa.xliff'), 6 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.fa.xliff')), 'fi' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.fi.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.fi.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.fi.yml'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.fi.yml'), 4 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.fi.xliff')), 'fr' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.fr.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.fr.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.fr.xlf'), 3 => ($this->targetDirs[3].'\\src\\EdgeWeb\\Project\\EmployeeBundle/Resources/translations\\messages.fr.xlf'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.fr.yml'), 5 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.fr.yml'), 6 => ($this->targetDirs[3].'\\src\\EdgeWeb\\Project\\UserBundle/Resources/translations\\messages.fr.xlf'), 7 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.fr.xlf'), 8 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.fr.xlf'), 9 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.fr.xliff'), 10 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.fr.xliff'), 11 => ($this->targetDirs[3].'\\src\\EdgeWeb\\Project\\PaycomBundle/Resources/translations\\messages.fr.xlf')), 'gl' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.gl.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.gl.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.gl.xlf')), 'he' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.he.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.he.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.he.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.he.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.he.yml')), 'hr' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.hr.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.hr.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.hr.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.hr.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.hr.yml'), 5 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.hr.xliff'), 6 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.hr.xliff')), 'hu' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.hu.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.hu.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.hu.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.hu.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.hu.yml'), 5 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.hu.xliff'), 6 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.hu.xliff')), 'hy' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.hy.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.hy.xlf')), 'id' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.id.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.id.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.id.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.id.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.id.yml')), 'it' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.it.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.it.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.it.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.it.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.it.yml'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.it.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.it.xlf'), 7 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.it.xliff'), 8 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.it.xliff')), 'ja' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.ja.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.ja.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.ja.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.ja.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.ja.yml'), 5 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.ja.xliff'), 6 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.ja.xliff')), 'lb' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.lb.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.lb.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.lb.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.lb.yml'), 4 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.lb.xliff'), 5 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.lb.xliff')), 'lt' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.lt.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.lt.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.lt.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.lt.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.lt.yml'), 5 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.lt.xliff'), 6 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.lt.xliff')), 'mn' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.mn.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.mn.xlf')), 'nl' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.nl.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.nl.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.nl.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.nl.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.nl.yml'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.nl.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.nl.xlf'), 7 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.nl.xliff'), 8 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.nl.xliff')), 'nn' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.nn.xlf')), 'no' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.no.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.no.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.no.xlf')), 'pl' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.pl.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.pl.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.pl.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.pl.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.pl.yml'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.pl.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.pl.xlf'), 7 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.pl.xliff'), 8 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.pl.xliff')), 'pt' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.pt.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.pt.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.pt.yml'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.pt.yml'), 4 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.pt.xlf'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.pt.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.pt.xliff'), 7 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.pt.xliff')), 'pt_BR' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.pt_BR.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.pt_BR.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.pt_BR.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.pt_BR.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.pt_BR.yml'), 5 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.pt_BR.xliff'), 6 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.pt_BR.xliff')), 'ro' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.ro.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.ro.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.ro.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.ro.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.ro.yml'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.ro.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.ro.xlf'), 7 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.ro.xliff'), 8 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.ro.xliff')), 'ru' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.ru.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.ru.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.ru.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.ru.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.ru.yml'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.ru.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.ru.xlf'), 7 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.ru.xliff'), 8 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.ru.xliff')), 'sk' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.sk.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.sk.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.sk.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.sk.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.sk.yml'), 5 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.sk.xliff'), 6 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.sk.xliff')), 'sl' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.sl.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.sl.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.sl.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.sl.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.sl.yml'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.sl.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.sl.xlf'), 7 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.sl.xliff'), 8 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.sl.xliff')), 'sq' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.sq.xlf')), 'sr_Cyrl' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.sr_Cyrl.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.sr_Cyrl.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.sr_Cyrl.xlf')), 'sr_Latn' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.sr_Latn.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.sr_Latn.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.sr_Latn.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.sr_Latn.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.sr_Latn.yml')), 'sv' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.sv.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.sv.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.sv.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.sv.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.sv.yml'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.sv.xlf'), 6 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.sv.xlf')), 'th' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.th.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.th.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.th.yml'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.th.yml')), 'tr' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.tr.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.tr.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.tr.yml'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.tr.yml'), 4 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\EasyAdminBundle.tr.xlf'), 5 => ($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/translations\\messages.tr.xlf')), 'uk' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.uk.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.uk.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.uk.yml'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.uk.yml'), 4 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.uk.xliff'), 5 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.uk.xliff')), 'vi' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.vi.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.vi.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.vi.yml'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.vi.yml')), 'zh_CN' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.zh_CN.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.zh_CN.xlf'), 2 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.zh_CN.xlf'), 3 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.zh_CN.yml'), 4 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.zh_CN.yml'), 5 => ($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/translations\\SonataCoreBundle.zh_CN.xliff'), 6 => ($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/translations\\SonataAdminBundle.zh_CN.xliff')), 'zh_TW' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Validator/Resources/translations\\validators.zh_TW.xlf')), 'lv' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/translations\\validators.lv.xlf'), 1 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.lv.yml'), 2 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.lv.yml')), 'pt_PT' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.pt_PT.xlf')), 'ua' => array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Security\\Core\\Exception/../Resources/translations\\security.ua.xlf')), 'nb' => array(0 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\FOSUserBundle.nb.yml'), 1 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/translations\\validators.nb.yml')))), array());

        $instance->setFallbackLocales(array(0 => 'en'));

        return $instance;
    }

    /**
     * Gets the 'translator_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\TranslatorListener A Symfony\Component\HttpKernel\EventListener\TranslatorListener instance.
     */
    protected function getTranslatorListenerService()
    {
        return $this->services['translator_listener'] = new \Symfony\Component\HttpKernel\EventListener\TranslatorListener($this->get('translator'), $this->get('request_stack'));
    }

    /**
     * Gets the 'twig' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Twig_Environment A Twig_Environment instance.
     */
    protected function getTwigService()
    {
        $a = $this->get('debug.stopwatch', ContainerInterface::NULL_ON_INVALID_REFERENCE);
        $b = $this->get('request_stack');
        $c = $this->get('router.request_context', ContainerInterface::NULL_ON_INVALID_REFERENCE);
        $d = $this->get('fragment.handler');

        $e = new \Symfony\Bridge\Twig\Extension\HttpFoundationExtension($b, $c);

        $f = new \Knp\Menu\Util\MenuManipulator();

        $g = new \Symfony\Bridge\Twig\AppVariable();
        $g->setEnvironment('dev');
        $g->setDebug(true);
        if ($this->has('security.token_storage')) {
            $g->setTokenStorage($this->get('security.token_storage', ContainerInterface::NULL_ON_INVALID_REFERENCE));
        }
        if ($this->has('request_stack')) {
            $g->setRequestStack($b);
        }
        $g->setContainer($this);

        $this->services['twig'] = $instance = new \Twig_Environment($this->get('twig.loader'), array('debug' => true, 'strict_variables' => true, 'exception_controller' => 'twig.controller.exception:showAction', 'form_themes' => array(0 => 'form_div_layout.html.twig', 1 => 'bootstrap_3_horizontal_layout.html.twig'), 'autoescape' => 'filename', 'cache' => (__DIR__.'/twig'), 'charset' => 'UTF-8', 'paths' => array(), 'date' => array('format' => 'F j, Y H:i', 'interval_format' => '%d days', 'timezone' => NULL), 'number_format' => array('decimals' => 0, 'decimal_point' => '.', 'thousands_separator' => ',')));

        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\LogoutUrlExtension($this->get('security.logout_url_generator')));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\SecurityExtension($this->get('security.authorization_checker', ContainerInterface::NULL_ON_INVALID_REFERENCE)));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\ProfilerExtension($this->get('twig.profile'), $a));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\TranslationExtension($this->get('translator')));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\AssetExtension($this->get('assets.packages'), $e));
        $instance->addExtension(new \Symfony\Bundle\TwigBundle\Extension\ActionsExtension($d));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\CodeExtension(NULL, $this->targetDirs[2], 'UTF-8'));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\RoutingExtension($this->get('router')));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\YamlExtension());
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\StopwatchExtension($a, true));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\ExpressionExtension());
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\HttpKernelExtension($d));
        $instance->addExtension($e);
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\FormExtension(new \Symfony\Bridge\Twig\Form\TwigRenderer(new \Symfony\Bridge\Twig\Form\TwigRendererEngine(array(0 => 'form_div_layout.html.twig', 1 => 'bootstrap_3_horizontal_layout.html.twig')), $this->get('security.csrf.token_manager', ContainerInterface::NULL_ON_INVALID_REFERENCE))));
        $instance->addExtension(new \Twig_Extension_Debug());
        $instance->addExtension(new \Symfony\Bundle\AsseticBundle\Twig\AsseticExtension($this->get('assetic.asset_factory'), $this->get('templating.name_parser'), true, array(), array(), new \Symfony\Bundle\AsseticBundle\DefaultValueSupplier($this)));
        $instance->addExtension(new \Doctrine\Bundle\DoctrineBundle\Twig\DoctrineExtension());
        $instance->addExtension(new \JMS\Serializer\Twig\SerializerExtension($this->get('jms_serializer')));
        $instance->addExtension($this->get('employee.twig.number_work_extension'));
        $instance->addExtension($this->get('employee.alreadytimedin_extension'));
        $instance->addExtension($this->get('employee.projectname_extension'));
        $instance->addExtension($this->get('employee.currentidproject_extension'));
        $instance->addExtension($this->get('employee.projecttask_extension'));
        $instance->addExtension(new \JavierEguiluz\Bundle\EasyAdminBundle\Twig\EasyAdminTwigExtension($this->get('easyadmin.configurator'), $this->get('property_accessor'), true));
        $instance->addExtension($this->get('sonata.core.flashmessage.twig.extension'));
        $instance->addExtension($this->get('sonata.core.twig.extension.wrapping'));
        $instance->addExtension($this->get('sonata.core.twig.extension.text'));
        $instance->addExtension($this->get('sonata.core.twig.status_extension'));
        $instance->addExtension($this->get('sonata.core.twig.template_extension'));
        $instance->addExtension(new \Sonata\BlockBundle\Twig\Extension\BlockExtension($this->get('sonata.block.templating.helper')));
        $instance->addExtension(new \Knp\Menu\Twig\MenuExtension(new \Knp\Menu\Twig\Helper($this->get('knp_menu.renderer_provider'), $this->get('knp_menu.menu_provider'), $f), $this->get('knp_menu.matcher'), $f));
        $instance->addExtension($this->get('sonata.admin.twig.extension'));
        $instance->addExtension($this->get('knp_paginator.twig.extension.pagination'));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\DumpExtension($this->get('var_dumper.cloner')));
        $instance->addExtension(new \Symfony\Bundle\WebProfilerBundle\Twig\WebProfilerExtension());
        $instance->addGlobal('app', $g);
        $instance->addGlobal('sonata_block', $this->get('sonata.block.twig.global'));
        call_user_func(array(new \Symfony\Bundle\TwigBundle\DependencyInjection\Configurator\EnvironmentConfigurator('F j, Y H:i', '%d days', NULL, 0, '.', ','), 'configure'), $instance);

        return $instance;
    }

    /**
     * Gets the 'twig.controller.exception' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\TwigBundle\Controller\ExceptionController A Symfony\Bundle\TwigBundle\Controller\ExceptionController instance.
     */
    protected function getTwig_Controller_ExceptionService()
    {
        return $this->services['twig.controller.exception'] = new \Symfony\Bundle\TwigBundle\Controller\ExceptionController($this->get('twig'), true);
    }

    /**
     * Gets the 'twig.controller.preview_error' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\TwigBundle\Controller\PreviewErrorController A Symfony\Bundle\TwigBundle\Controller\PreviewErrorController instance.
     */
    protected function getTwig_Controller_PreviewErrorService()
    {
        return $this->services['twig.controller.preview_error'] = new \Symfony\Bundle\TwigBundle\Controller\PreviewErrorController($this->get('http_kernel'), 'twig.controller.exception:showAction');
    }

    /**
     * Gets the 'twig.exception_listener' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\ExceptionListener A Symfony\Component\HttpKernel\EventListener\ExceptionListener instance.
     */
    protected function getTwig_ExceptionListenerService()
    {
        return $this->services['twig.exception_listener'] = new \Symfony\Component\HttpKernel\EventListener\ExceptionListener('twig.controller.exception:showAction', $this->get('monolog.logger.request', ContainerInterface::NULL_ON_INVALID_REFERENCE));
    }

    /**
     * Gets the 'twig.loader' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\TwigBundle\Loader\FilesystemLoader A Symfony\Bundle\TwigBundle\Loader\FilesystemLoader instance.
     */
    protected function getTwig_LoaderService()
    {
        $this->services['twig.loader'] = $instance = new \Symfony\Bundle\TwigBundle\Loader\FilesystemLoader($this->get('templating.locator'), $this->get('templating.name_parser'));

        $instance->addPath(($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle/Resources/views'), 'Framework');
        $instance->addPath(($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\SecurityBundle/Resources/views'), 'Security');
        $instance->addPath(($this->targetDirs[2].'/Resources/TwigBundle/views'), 'Twig');
        $instance->addPath(($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views'), 'Twig');
        $instance->addPath(($this->targetDirs[3].'\\vendor\\symfony\\swiftmailer-bundle/Resources/views'), 'Swiftmailer');
        $instance->addPath(($this->targetDirs[3].'\\vendor\\doctrine\\doctrine-bundle/Resources/views'), 'Doctrine');
        $instance->addPath(($this->targetDirs[3].'\\src\\EdgeWeb\\Project\\EmployeeBundle/Resources/views'), 'Employee');
        $instance->addPath(($this->targetDirs[2].'/Resources/FOSUserBundle/views'), 'FOSUser');
        $instance->addPath(($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle/Resources/views'), 'FOSUser');
        $instance->addPath(($this->targetDirs[3].'\\src\\EdgeWeb\\Project\\UserBundle/Resources/views'), 'User');
        $instance->addPath(($this->targetDirs[3].'\\vendor\\javiereguiluz\\easyadmin-bundle/Resources/views'), 'EasyAdmin');
        $instance->addPath(($this->targetDirs[3].'\\vendor\\sonata-project\\core-bundle/Resources/views'), 'SonataCore');
        $instance->addPath(($this->targetDirs[3].'\\vendor\\sonata-project\\block-bundle/Resources/views'), 'SonataBlock');
        $instance->addPath(($this->targetDirs[3].'\\vendor\\sonata-project\\doctrine-orm-admin-bundle/Resources/views'), 'SonataDoctrineORMAdmin');
        $instance->addPath(($this->targetDirs[2].'/Resources/SonataAdminBundle/views'), 'SonataAdmin');
        $instance->addPath(($this->targetDirs[3].'\\vendor\\sonata-project\\admin-bundle/Resources/views'), 'SonataAdmin');
        $instance->addPath(($this->targetDirs[3].'\\vendor\\knplabs\\knp-paginator-bundle/Resources/views'), 'KnpPaginator');
        $instance->addPath(($this->targetDirs[3].'\\src\\EdgeWeb\\Project\\PaycomBundle/Resources/views'), 'Paycom');
        $instance->addPath(($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\DebugBundle/Resources/views'), 'Debug');
        $instance->addPath(($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views'), 'WebProfiler');
        $instance->addPath(($this->targetDirs[3].'\\vendor\\sensio\\distribution-bundle\\Sensio\\Bundle\\DistributionBundle/Resources/views'), 'SensioDistribution');
        $instance->addPath(($this->targetDirs[2].'/Resources/views'));
        $instance->addPath(($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Bridge\\Twig/Resources/views/Form'));
        $instance->addPath(($this->targetDirs[3].'\\vendor\\knplabs\\knp-menu\\src\\Knp\\Menu/Resources/views'));

        return $instance;
    }

    /**
     * Gets the 'twig.profile' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Twig_Profiler_Profile A Twig_Profiler_Profile instance.
     */
    protected function getTwig_ProfileService()
    {
        return $this->services['twig.profile'] = new \Twig_Profiler_Profile();
    }

    /**
     * Gets the 'twig.translation.extractor' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bridge\Twig\Translation\TwigExtractor A Symfony\Bridge\Twig\Translation\TwigExtractor instance.
     */
    protected function getTwig_Translation_ExtractorService()
    {
        return $this->services['twig.translation.extractor'] = new \Symfony\Bridge\Twig\Translation\TwigExtractor($this->get('twig'));
    }

    /**
     * Gets the 'uri_signer' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\HttpKernel\UriSigner A Symfony\Component\HttpKernel\UriSigner instance.
     */
    protected function getUriSignerService()
    {
        return $this->services['uri_signer'] = new \Symfony\Component\HttpKernel\UriSigner('ThisTokenIsNotSoSecretChangeIt');
    }

    /**
     * Gets the 'validator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Validator\Validator\ValidatorInterface A Symfony\Component\Validator\Validator\ValidatorInterface instance.
     */
    protected function getValidatorService()
    {
        return $this->services['validator'] = $this->get('validator.builder')->getValidator();
    }

    /**
     * Gets the 'validator.builder' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Validator\ValidatorBuilderInterface A Symfony\Component\Validator\ValidatorBuilderInterface instance.
     */
    protected function getValidator_BuilderService()
    {
        $this->services['validator.builder'] = $instance = \Symfony\Component\Validator\Validation::createValidatorBuilder();

        $instance->setConstraintValidatorFactory($this->get('validator.validator_factory'));
        $instance->setTranslator($this->get('translator'));
        $instance->setTranslationDomain('validators');
        $instance->addXmlMappings(array(0 => ($this->targetDirs[3].'\\vendor\\symfony\\symfony\\src\\Symfony\\Component\\Form/Resources/config/validation.xml'), 1 => ($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle\\Resources\\config\\validation.xml')));
        $instance->addYamlMappings(array(0 => ($this->targetDirs[3].'\\src\\EdgeWeb\\Project\\EmployeeBundle\\Resources\\config\\validation.yml')));
        $instance->enableAnnotationMapping($this->get('annotation_reader'));
        $instance->addMethodMapping('loadValidatorMetadata');
        $instance->addObjectInitializers(array(0 => $this->get('doctrine.orm.validator_initializer'), 1 => new \FOS\UserBundle\Validator\Initializer($this->get('fos_user.user_manager'))));
        $instance->addXmlMapping(($this->targetDirs[3].'\\vendor\\friendsofsymfony\\user-bundle\\DependencyInjection\\Compiler/../../Resources/config/storage-validation/orm.xml'));

        return $instance;
    }

    /**
     * Gets the 'validator.email' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Validator\Constraints\EmailValidator A Symfony\Component\Validator\Constraints\EmailValidator instance.
     */
    protected function getValidator_EmailService()
    {
        return $this->services['validator.email'] = new \Symfony\Component\Validator\Constraints\EmailValidator(false);
    }

    /**
     * Gets the 'validator.expression' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\Validator\Constraints\ExpressionValidator A Symfony\Component\Validator\Constraints\ExpressionValidator instance.
     */
    protected function getValidator_ExpressionService()
    {
        return $this->services['validator.expression'] = new \Symfony\Component\Validator\Constraints\ExpressionValidator($this->get('property_accessor'));
    }

    /**
     * Gets the 'var_dumper.cli_dumper' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\VarDumper\Dumper\CliDumper A Symfony\Component\VarDumper\Dumper\CliDumper instance.
     */
    protected function getVarDumper_CliDumperService()
    {
        return $this->services['var_dumper.cli_dumper'] = new \Symfony\Component\VarDumper\Dumper\CliDumper(NULL, 'UTF-8');
    }

    /**
     * Gets the 'var_dumper.cloner' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Component\VarDumper\Cloner\VarCloner A Symfony\Component\VarDumper\Cloner\VarCloner instance.
     */
    protected function getVarDumper_ClonerService()
    {
        $this->services['var_dumper.cloner'] = $instance = new \Symfony\Component\VarDumper\Cloner\VarCloner();

        $instance->setMaxItems(2500);
        $instance->setMaxString(-1);

        return $instance;
    }

    /**
     * Gets the 'web_profiler.controller.exception' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\WebProfilerBundle\Controller\ExceptionController A Symfony\Bundle\WebProfilerBundle\Controller\ExceptionController instance.
     */
    protected function getWebProfiler_Controller_ExceptionService()
    {
        return $this->services['web_profiler.controller.exception'] = new \Symfony\Bundle\WebProfilerBundle\Controller\ExceptionController($this->get('profiler', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('twig'), true);
    }

    /**
     * Gets the 'web_profiler.controller.profiler' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\WebProfilerBundle\Controller\ProfilerController A Symfony\Bundle\WebProfilerBundle\Controller\ProfilerController instance.
     */
    protected function getWebProfiler_Controller_ProfilerService()
    {
        return $this->services['web_profiler.controller.profiler'] = new \Symfony\Bundle\WebProfilerBundle\Controller\ProfilerController($this->get('router', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('profiler', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('twig'), array('data_collector.config' => array(0 => 'config', 1 => '@WebProfiler/Collector/config.html.twig'), 'data_collector.request' => array(0 => 'request', 1 => '@WebProfiler/Collector/request.html.twig'), 'data_collector.ajax' => array(0 => 'ajax', 1 => '@WebProfiler/Collector/ajax.html.twig'), 'data_collector.exception' => array(0 => 'exception', 1 => '@WebProfiler/Collector/exception.html.twig'), 'data_collector.events' => array(0 => 'events', 1 => '@WebProfiler/Collector/events.html.twig'), 'data_collector.logger' => array(0 => 'logger', 1 => '@WebProfiler/Collector/logger.html.twig'), 'data_collector.time' => array(0 => 'time', 1 => '@WebProfiler/Collector/time.html.twig'), 'data_collector.memory' => array(0 => 'memory', 1 => '@WebProfiler/Collector/memory.html.twig'), 'data_collector.router' => array(0 => 'router', 1 => '@WebProfiler/Collector/router.html.twig'), 'data_collector.form' => array(0 => 'form', 1 => '@WebProfiler/Collector/form.html.twig'), 'data_collector.translation' => array(0 => 'translation', 1 => '@WebProfiler/Collector/translation.html.twig'), 'data_collector.twig' => array(0 => 'twig', 1 => '@WebProfiler/Collector/twig.html.twig'), 'data_collector.doctrine' => array(0 => 'db', 1 => '@Doctrine/Collector/db.html.twig'), 'swiftmailer.data_collector' => array(0 => 'swiftmailer', 1 => '@Swiftmailer/Collector/swiftmailer.html.twig'), 'data_collector.security' => array(0 => 'security', 1 => '@Security/Collector/security.html.twig'), 'easyadmin.data_collector' => array(0 => 'easyadmin', 1 => '@EasyAdmin/data_collector/easyadmin.html.twig'), 'sonata.block.data_collector' => array(0 => 'block', 1 => 'SonataBlockBundle:Profiler:block.html.twig'), 'data_collector.dump' => array(0 => 'dump', 1 => '@Debug/Profiler/dump.html.twig')), 'bottom');
    }

    /**
     * Gets the 'web_profiler.controller.router' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\WebProfilerBundle\Controller\RouterController A Symfony\Bundle\WebProfilerBundle\Controller\RouterController instance.
     */
    protected function getWebProfiler_Controller_RouterService()
    {
        return $this->services['web_profiler.controller.router'] = new \Symfony\Bundle\WebProfilerBundle\Controller\RouterController($this->get('profiler', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('twig'), $this->get('router', ContainerInterface::NULL_ON_INVALID_REFERENCE));
    }

    /**
     * Gets the 'web_profiler.debug_toolbar' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * @return \Symfony\Bundle\WebProfilerBundle\EventListener\WebDebugToolbarListener A Symfony\Bundle\WebProfilerBundle\EventListener\WebDebugToolbarListener instance.
     */
    protected function getWebProfiler_DebugToolbarService()
    {
        return $this->services['web_profiler.debug_toolbar'] = new \Symfony\Bundle\WebProfilerBundle\EventListener\WebDebugToolbarListener($this->get('twig'), false, 2, 'bottom', $this->get('router', ContainerInterface::NULL_ON_INVALID_REFERENCE), '^/(app(_[\\w]+)?\\.php/)?_wdt');
    }

    /**
     * Gets the 'assetic.asset_factory' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Symfony\Bundle\AsseticBundle\Factory\AssetFactory A Symfony\Bundle\AsseticBundle\Factory\AssetFactory instance.
     */
    protected function getAssetic_AssetFactoryService()
    {
        $this->services['assetic.asset_factory'] = $instance = new \Symfony\Bundle\AsseticBundle\Factory\AssetFactory($this->get('kernel'), $this, $this->getParameterBag(), ($this->targetDirs[2].'/../web'), true);

        $instance->addWorker(new \Symfony\Bundle\AsseticBundle\Factory\Worker\UseControllerWorker());

        return $instance;
    }

    /**
     * Gets the 'controller_name_converter' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Controller\ControllerNameParser A Symfony\Bundle\FrameworkBundle\Controller\ControllerNameParser instance.
     */
    protected function getControllerNameConverterService()
    {
        return $this->services['controller_name_converter'] = new \Symfony\Bundle\FrameworkBundle\Controller\ControllerNameParser($this->get('kernel'));
    }

    /**
     * Gets the 'doctrine.dbal.logger.profiling.default' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Doctrine\DBAL\Logging\DebugStack A Doctrine\DBAL\Logging\DebugStack instance.
     */
    protected function getDoctrine_Dbal_Logger_Profiling_DefaultService()
    {
        return $this->services['doctrine.dbal.logger.profiling.default'] = new \Doctrine\DBAL\Logging\DebugStack();
    }

    /**
     * Gets the 'fos_user.user_provider.username' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \FOS\UserBundle\Security\UserProvider A FOS\UserBundle\Security\UserProvider instance.
     */
    protected function getFosUser_UserProvider_UsernameService()
    {
        return $this->services['fos_user.user_provider.username'] = new \FOS\UserBundle\Security\UserProvider($this->get('fos_user.user_manager'));
    }

    /**
     * Gets the 'jms_serializer.unserialize_object_constructor' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \JMS\Serializer\Construction\UnserializeObjectConstructor A JMS\Serializer\Construction\UnserializeObjectConstructor instance.
     */
    protected function getJmsSerializer_UnserializeObjectConstructorService()
    {
        return $this->services['jms_serializer.unserialize_object_constructor'] = new \JMS\Serializer\Construction\UnserializeObjectConstructor();
    }

    /**
     * Gets the 'router.request_context' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Symfony\Component\Routing\RequestContext A Symfony\Component\Routing\RequestContext instance.
     */
    protected function getRouter_RequestContextService()
    {
        return $this->services['router.request_context'] = new \Symfony\Component\Routing\RequestContext('', 'GET', 'localhost', 'http', 80, 443);
    }

    /**
     * Gets the 'security.access.decision_manager' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Symfony\Component\Security\Core\Authorization\AccessDecisionManager A Symfony\Component\Security\Core\Authorization\AccessDecisionManager instance.
     */
    protected function getSecurity_Access_DecisionManagerService()
    {
        $a = $this->get('security.role_hierarchy');
        $b = $this->get('security.authentication.trust_resolver');

        return $this->services['security.access.decision_manager'] = new \Symfony\Component\Security\Core\Authorization\AccessDecisionManager(array(0 => new \Symfony\Component\Security\Core\Authorization\Voter\RoleHierarchyVoter($a), 1 => new \Symfony\Component\Security\Core\Authorization\Voter\ExpressionVoter(new \Symfony\Component\Security\Core\Authorization\ExpressionLanguage(), $b, $a), 2 => new \Symfony\Component\Security\Core\Authorization\Voter\AuthenticatedVoter($b), 3 => new \Symfony\Component\Security\Acl\Voter\AclVoter($this->get('security.acl.provider'), new \Symfony\Component\Security\Acl\Domain\ObjectIdentityRetrievalStrategy(), new \Symfony\Component\Security\Acl\Domain\SecurityIdentityRetrievalStrategy($a, $b), new \Symfony\Component\Security\Acl\Permission\BasicPermissionMap(), $this->get('monolog.logger.security', ContainerInterface::NULL_ON_INVALID_REFERENCE), true)), 'affirmative', false, true);
    }

    /**
     * Gets the 'security.authentication.manager' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Symfony\Component\Security\Core\Authentication\AuthenticationProviderManager A Symfony\Component\Security\Core\Authentication\AuthenticationProviderManager instance.
     */
    protected function getSecurity_Authentication_ManagerService()
    {
        $this->services['security.authentication.manager'] = $instance = new \Symfony\Component\Security\Core\Authentication\AuthenticationProviderManager(array(0 => new \Symfony\Component\Security\Core\Authentication\Provider\DaoAuthenticationProvider($this->get('fos_user.user_provider.username'), $this->get('security.user_checker'), 'main', $this->get('security.encoder_factory'), true), 1 => new \Symfony\Component\Security\Core\Authentication\Provider\AnonymousAuthenticationProvider('56fb31d31482b7.98455892')), true);

        $instance->setEventDispatcher($this->get('debug.event_dispatcher'));

        return $instance;
    }

    /**
     * Gets the 'security.authentication.session_strategy' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Symfony\Component\Security\Http\Session\SessionAuthenticationStrategy A Symfony\Component\Security\Http\Session\SessionAuthenticationStrategy instance.
     */
    protected function getSecurity_Authentication_SessionStrategyService()
    {
        return $this->services['security.authentication.session_strategy'] = new \Symfony\Component\Security\Http\Session\SessionAuthenticationStrategy('migrate');
    }

    /**
     * Gets the 'security.authentication.trust_resolver' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Symfony\Component\Security\Core\Authentication\AuthenticationTrustResolver A Symfony\Component\Security\Core\Authentication\AuthenticationTrustResolver instance.
     */
    protected function getSecurity_Authentication_TrustResolverService()
    {
        return $this->services['security.authentication.trust_resolver'] = new \Symfony\Component\Security\Core\Authentication\AuthenticationTrustResolver('Symfony\\Component\\Security\\Core\\Authentication\\Token\\AnonymousToken', 'Symfony\\Component\\Security\\Core\\Authentication\\Token\\RememberMeToken');
    }

    /**
     * Gets the 'security.logout_url_generator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Symfony\Component\Security\Http\Logout\LogoutUrlGenerator A Symfony\Component\Security\Http\Logout\LogoutUrlGenerator instance.
     */
    protected function getSecurity_LogoutUrlGeneratorService()
    {
        $this->services['security.logout_url_generator'] = $instance = new \Symfony\Component\Security\Http\Logout\LogoutUrlGenerator($this->get('request_stack', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('router', ContainerInterface::NULL_ON_INVALID_REFERENCE), $this->get('security.token_storage', ContainerInterface::NULL_ON_INVALID_REFERENCE));

        $instance->registerListener('main', '/logout', 'logout', '_csrf_token', NULL);

        return $instance;
    }

    /**
     * Gets the 'security.role_hierarchy' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Symfony\Component\Security\Core\Role\RoleHierarchy A Symfony\Component\Security\Core\Role\RoleHierarchy instance.
     */
    protected function getSecurity_RoleHierarchyService()
    {
        return $this->services['security.role_hierarchy'] = new \Symfony\Component\Security\Core\Role\RoleHierarchy(array('ROLE_ADMIN' => array(0 => 'ROLE_USER'), 'ROLE_SUPER_ADMIN' => array(0 => 'ROLE_ADMIN')));
    }

    /**
     * Gets the 'security.user_checker' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Symfony\Component\Security\Core\User\UserChecker A Symfony\Component\Security\Core\User\UserChecker instance.
     */
    protected function getSecurity_UserCheckerService()
    {
        return $this->services['security.user_checker'] = new \Symfony\Component\Security\Core\User\UserChecker();
    }

    /**
     * Gets the 'session.storage.metadata_bag' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Symfony\Component\HttpFoundation\Session\Storage\MetadataBag A Symfony\Component\HttpFoundation\Session\Storage\MetadataBag instance.
     */
    protected function getSession_Storage_MetadataBagService()
    {
        return $this->services['session.storage.metadata_bag'] = new \Symfony\Component\HttpFoundation\Session\Storage\MetadataBag('_sf2_meta', '0');
    }

    /**
     * Gets the 'sonata.block.manager' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Sonata\BlockBundle\Block\BlockServiceManager A Sonata\BlockBundle\Block\BlockServiceManager instance.
     */
    protected function getSonata_Block_ManagerService()
    {
        $this->services['sonata.block.manager'] = $instance = new \Sonata\BlockBundle\Block\BlockServiceManager($this, true, $this->get('logger', ContainerInterface::NULL_ON_INVALID_REFERENCE));

        $instance->add('sonata.block.service.container', 'sonata.block.service.container', array());
        $instance->add('sonata.block.service.empty', 'sonata.block.service.empty', array());
        $instance->add('sonata.block.service.text', 'sonata.block.service.text', array());
        $instance->add('sonata.block.service.rss', 'sonata.block.service.rss', array());
        $instance->add('sonata.block.service.menu', 'sonata.block.service.menu', array());
        $instance->add('sonata.block.service.template', 'sonata.block.service.template', array());
        $instance->add('sonata.admin.block.admin_list', 'sonata.admin.block.admin_list', array(0 => 'admin'));
        $instance->add('sonata.admin.block.search_result', 'sonata.admin.block.search_result', array());

        return $instance;
    }

    /**
     * Gets the 'swiftmailer.mailer.default.transport.eventdispatcher' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Swift_Events_SimpleEventDispatcher A Swift_Events_SimpleEventDispatcher instance.
     */
    protected function getSwiftmailer_Mailer_Default_Transport_EventdispatcherService()
    {
        return $this->services['swiftmailer.mailer.default.transport.eventdispatcher'] = new \Swift_Events_SimpleEventDispatcher();
    }

    /**
     * Gets the 'templating.locator' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Templating\Loader\TemplateLocator A Symfony\Bundle\FrameworkBundle\Templating\Loader\TemplateLocator instance.
     */
    protected function getTemplating_LocatorService()
    {
        return $this->services['templating.locator'] = new \Symfony\Bundle\FrameworkBundle\Templating\Loader\TemplateLocator($this->get('file_locator'), __DIR__);
    }

    /**
     * Gets the 'validator.validator_factory' service.
     *
     * This service is shared.
     * This method always returns the same instance of the service.
     *
     * This service is private.
     * If you want to be able to request this service from the container directly,
     * make it public, otherwise you might end up with broken code.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Validator\ConstraintValidatorFactory A Symfony\Bundle\FrameworkBundle\Validator\ConstraintValidatorFactory instance.
     */
    protected function getValidator_ValidatorFactoryService()
    {
        return $this->services['validator.validator_factory'] = new \Symfony\Bundle\FrameworkBundle\Validator\ConstraintValidatorFactory($this, array('validator.expression' => 'validator.expression', 'Symfony\\Component\\Validator\\Constraints\\ExpressionValidator' => 'validator.expression', 'Symfony\\Component\\Validator\\Constraints\\EmailValidator' => 'validator.email', 'security.validator.user_password' => 'security.validator.user_password', 'Symfony\\Component\\Security\\Core\\Validator\\Constraints\\UserPasswordValidator' => 'security.validator.user_password', 'doctrine.orm.validator.unique' => 'doctrine.orm.validator.unique', 'Symfony\\Bridge\\Doctrine\\Validator\\Constraints\\UniqueEntityValidator' => 'doctrine.orm.validator.unique', 'sonata.core.validator.inline' => 'sonata.core.validator.inline', 'Sonata\\CoreBundle\\Validator\\InlineValidator' => 'sonata.core.validator.inline', 'sonata.admin.validator.inline' => 'sonata.admin.validator.inline', 'Sonata\\AdminBundle\\Validator\\InlineValidator' => 'sonata.admin.validator.inline'));
    }

    /**
     * {@inheritdoc}
     */
    public function getParameter($name)
    {
        $name = strtolower($name);

        if (!(isset($this->parameters[$name]) || array_key_exists($name, $this->parameters))) {
            throw new InvalidArgumentException(sprintf('The parameter "%s" must be defined.', $name));
        }

        return $this->parameters[$name];
    }

    /**
     * {@inheritdoc}
     */
    public function hasParameter($name)
    {
        $name = strtolower($name);

        return isset($this->parameters[$name]) || array_key_exists($name, $this->parameters);
    }

    /**
     * {@inheritdoc}
     */
    public function setParameter($name, $value)
    {
        throw new LogicException('Impossible to call set() on a frozen ParameterBag.');
    }

    /**
     * {@inheritdoc}
     */
    public function getParameterBag()
    {
        if (null === $this->parameterBag) {
            $this->parameterBag = new FrozenParameterBag($this->parameters);
        }

        return $this->parameterBag;
    }

    /**
     * Gets the default parameters.
     *
     * @return array An array of the default parameters
     */
    protected function getDefaultParameters()
    {
        return array(
            'kernel.root_dir' => $this->targetDirs[2],
            'kernel.environment' => 'dev',
            'kernel.debug' => true,
            'kernel.name' => 'app',
            'kernel.cache_dir' => __DIR__,
            'kernel.logs_dir' => ($this->targetDirs[2].'\\logs'),
            'kernel.bundles' => array(
                'FrameworkBundle' => 'Symfony\\Bundle\\FrameworkBundle\\FrameworkBundle',
                'SecurityBundle' => 'Symfony\\Bundle\\SecurityBundle\\SecurityBundle',
                'TwigBundle' => 'Symfony\\Bundle\\TwigBundle\\TwigBundle',
                'MonologBundle' => 'Symfony\\Bundle\\MonologBundle\\MonologBundle',
                'SwiftmailerBundle' => 'Symfony\\Bundle\\SwiftmailerBundle\\SwiftmailerBundle',
                'AsseticBundle' => 'Symfony\\Bundle\\AsseticBundle\\AsseticBundle',
                'DoctrineBundle' => 'Doctrine\\Bundle\\DoctrineBundle\\DoctrineBundle',
                'SensioFrameworkExtraBundle' => 'Sensio\\Bundle\\FrameworkExtraBundle\\SensioFrameworkExtraBundle',
                'AppBundle' => 'AppBundle\\AppBundle',
                'JMSSerializerBundle' => 'JMS\\SerializerBundle\\JMSSerializerBundle',
                'EmployeeBundle' => 'EdgeWeb\\Project\\EmployeeBundle\\EmployeeBundle',
                'StofDoctrineExtensionsBundle' => 'Stof\\DoctrineExtensionsBundle\\StofDoctrineExtensionsBundle',
                'FOSUserBundle' => 'FOS\\UserBundle\\FOSUserBundle',
                'UserBundle' => 'EdgeWeb\\Project\\UserBundle\\UserBundle',
                'EasyAdminBundle' => 'JavierEguiluz\\Bundle\\EasyAdminBundle\\EasyAdminBundle',
                'DoctrineBehaviorsBundle' => 'Knp\\DoctrineBehaviors\\Bundle\\DoctrineBehaviorsBundle',
                'SonataCoreBundle' => 'Sonata\\CoreBundle\\SonataCoreBundle',
                'SonataBlockBundle' => 'Sonata\\BlockBundle\\SonataBlockBundle',
                'KnpMenuBundle' => 'Knp\\Bundle\\MenuBundle\\KnpMenuBundle',
                'SonataDoctrineORMAdminBundle' => 'Sonata\\DoctrineORMAdminBundle\\SonataDoctrineORMAdminBundle',
                'SonataAdminBundle' => 'Sonata\\AdminBundle\\SonataAdminBundle',
                'KnpPaginatorBundle' => 'Knp\\Bundle\\PaginatorBundle\\KnpPaginatorBundle',
                'PaycomBundle' => 'EdgeWeb\\Project\\PaycomBundle\\PaycomBundle',
                'DebugBundle' => 'Symfony\\Bundle\\DebugBundle\\DebugBundle',
                'WebProfilerBundle' => 'Symfony\\Bundle\\WebProfilerBundle\\WebProfilerBundle',
                'SensioDistributionBundle' => 'Sensio\\Bundle\\DistributionBundle\\SensioDistributionBundle',
                'SensioGeneratorBundle' => 'Sensio\\Bundle\\GeneratorBundle\\SensioGeneratorBundle',
            ),
            'kernel.charset' => 'UTF-8',
            'kernel.container_class' => 'appDevDebugProjectContainer',
            'database_host' => '127.0.0.1',
            'database_port' => NULL,
            'database_name' => 'edge',
            'database_user' => 'root',
            'database_password' => NULL,
            'mailer_transport' => 'smtp',
            'mailer_host' => '127.0.0.1',
            'mailer_user' => NULL,
            'mailer_password' => NULL,
            'secret' => 'ThisTokenIsNotSoSecretChangeIt',
            'locale' => 'en',
            'controller_resolver.class' => 'Symfony\\Bundle\\FrameworkBundle\\Controller\\ControllerResolver',
            'controller_name_converter.class' => 'Symfony\\Bundle\\FrameworkBundle\\Controller\\ControllerNameParser',
            'response_listener.class' => 'Symfony\\Component\\HttpKernel\\EventListener\\ResponseListener',
            'streamed_response_listener.class' => 'Symfony\\Component\\HttpKernel\\EventListener\\StreamedResponseListener',
            'locale_listener.class' => 'Symfony\\Component\\HttpKernel\\EventListener\\LocaleListener',
            'event_dispatcher.class' => 'Symfony\\Component\\EventDispatcher\\ContainerAwareEventDispatcher',
            'http_kernel.class' => 'Symfony\\Component\\HttpKernel\\DependencyInjection\\ContainerAwareHttpKernel',
            'filesystem.class' => 'Symfony\\Component\\Filesystem\\Filesystem',
            'cache_warmer.class' => 'Symfony\\Component\\HttpKernel\\CacheWarmer\\CacheWarmerAggregate',
            'cache_clearer.class' => 'Symfony\\Component\\HttpKernel\\CacheClearer\\ChainCacheClearer',
            'file_locator.class' => 'Symfony\\Component\\HttpKernel\\Config\\FileLocator',
            'uri_signer.class' => 'Symfony\\Component\\HttpKernel\\UriSigner',
            'request_stack.class' => 'Symfony\\Component\\HttpFoundation\\RequestStack',
            'fragment.handler.class' => 'Symfony\\Component\\HttpKernel\\DependencyInjection\\LazyLoadingFragmentHandler',
            'fragment.renderer.inline.class' => 'Symfony\\Component\\HttpKernel\\Fragment\\InlineFragmentRenderer',
            'fragment.renderer.hinclude.class' => 'Symfony\\Component\\HttpKernel\\Fragment\\HIncludeFragmentRenderer',
            'fragment.renderer.hinclude.global_template' => NULL,
            'fragment.renderer.esi.class' => 'Symfony\\Component\\HttpKernel\\Fragment\\EsiFragmentRenderer',
            'fragment.path' => '/_fragment',
            'translator.class' => 'Symfony\\Bundle\\FrameworkBundle\\Translation\\Translator',
            'translator.identity.class' => 'Symfony\\Component\\Translation\\IdentityTranslator',
            'translator.selector.class' => 'Symfony\\Component\\Translation\\MessageSelector',
            'translation.loader.php.class' => 'Symfony\\Component\\Translation\\Loader\\PhpFileLoader',
            'translation.loader.yml.class' => 'Symfony\\Component\\Translation\\Loader\\YamlFileLoader',
            'translation.loader.xliff.class' => 'Symfony\\Component\\Translation\\Loader\\XliffFileLoader',
            'translation.loader.po.class' => 'Symfony\\Component\\Translation\\Loader\\PoFileLoader',
            'translation.loader.mo.class' => 'Symfony\\Component\\Translation\\Loader\\MoFileLoader',
            'translation.loader.qt.class' => 'Symfony\\Component\\Translation\\Loader\\QtFileLoader',
            'translation.loader.csv.class' => 'Symfony\\Component\\Translation\\Loader\\CsvFileLoader',
            'translation.loader.res.class' => 'Symfony\\Component\\Translation\\Loader\\IcuResFileLoader',
            'translation.loader.dat.class' => 'Symfony\\Component\\Translation\\Loader\\IcuDatFileLoader',
            'translation.loader.ini.class' => 'Symfony\\Component\\Translation\\Loader\\IniFileLoader',
            'translation.loader.json.class' => 'Symfony\\Component\\Translation\\Loader\\JsonFileLoader',
            'translation.dumper.php.class' => 'Symfony\\Component\\Translation\\Dumper\\PhpFileDumper',
            'translation.dumper.xliff.class' => 'Symfony\\Component\\Translation\\Dumper\\XliffFileDumper',
            'translation.dumper.po.class' => 'Symfony\\Component\\Translation\\Dumper\\PoFileDumper',
            'translation.dumper.mo.class' => 'Symfony\\Component\\Translation\\Dumper\\MoFileDumper',
            'translation.dumper.yml.class' => 'Symfony\\Component\\Translation\\Dumper\\YamlFileDumper',
            'translation.dumper.qt.class' => 'Symfony\\Component\\Translation\\Dumper\\QtFileDumper',
            'translation.dumper.csv.class' => 'Symfony\\Component\\Translation\\Dumper\\CsvFileDumper',
            'translation.dumper.ini.class' => 'Symfony\\Component\\Translation\\Dumper\\IniFileDumper',
            'translation.dumper.json.class' => 'Symfony\\Component\\Translation\\Dumper\\JsonFileDumper',
            'translation.dumper.res.class' => 'Symfony\\Component\\Translation\\Dumper\\IcuResFileDumper',
            'translation.extractor.php.class' => 'Symfony\\Bundle\\FrameworkBundle\\Translation\\PhpExtractor',
            'translation.loader.class' => 'Symfony\\Bundle\\FrameworkBundle\\Translation\\TranslationLoader',
            'translation.extractor.class' => 'Symfony\\Component\\Translation\\Extractor\\ChainExtractor',
            'translation.writer.class' => 'Symfony\\Component\\Translation\\Writer\\TranslationWriter',
            'property_accessor.class' => 'Symfony\\Component\\PropertyAccess\\PropertyAccessor',
            'kernel.secret' => 'ThisTokenIsNotSoSecretChangeIt',
            'kernel.http_method_override' => true,
            'kernel.trusted_hosts' => array(

            ),
            'kernel.trusted_proxies' => array(

            ),
            'kernel.default_locale' => 'en',
            'session.class' => 'Symfony\\Component\\HttpFoundation\\Session\\Session',
            'session.flashbag.class' => 'Symfony\\Component\\HttpFoundation\\Session\\Flash\\FlashBag',
            'session.attribute_bag.class' => 'Symfony\\Component\\HttpFoundation\\Session\\Attribute\\AttributeBag',
            'session.storage.metadata_bag.class' => 'Symfony\\Component\\HttpFoundation\\Session\\Storage\\MetadataBag',
            'session.metadata.storage_key' => '_sf2_meta',
            'session.storage.native.class' => 'Symfony\\Component\\HttpFoundation\\Session\\Storage\\NativeSessionStorage',
            'session.storage.php_bridge.class' => 'Symfony\\Component\\HttpFoundation\\Session\\Storage\\PhpBridgeSessionStorage',
            'session.storage.mock_file.class' => 'Symfony\\Component\\HttpFoundation\\Session\\Storage\\MockFileSessionStorage',
            'session.handler.native_file.class' => 'Symfony\\Component\\HttpFoundation\\Session\\Storage\\Handler\\NativeFileSessionHandler',
            'session.handler.write_check.class' => 'Symfony\\Component\\HttpFoundation\\Session\\Storage\\Handler\\WriteCheckSessionHandler',
            'session_listener.class' => 'Symfony\\Bundle\\FrameworkBundle\\EventListener\\SessionListener',
            'session.storage.options' => array(
                'gc_probability' => 0,
            ),
            'session.save_path' => (__DIR__.'/sessions'),
            'session.metadata.update_threshold' => '0',
            'security.secure_random.class' => 'Symfony\\Component\\Security\\Core\\Util\\SecureRandom',
            'form.resolved_type_factory.class' => 'Symfony\\Component\\Form\\ResolvedFormTypeFactory',
            'form.registry.class' => 'Symfony\\Component\\Form\\FormRegistry',
            'form.factory.class' => 'Symfony\\Component\\Form\\FormFactory',
            'form.extension.class' => 'Symfony\\Component\\Form\\Extension\\DependencyInjection\\DependencyInjectionExtension',
            'form.type_guesser.validator.class' => 'Symfony\\Component\\Form\\Extension\\Validator\\ValidatorTypeGuesser',
            'form.type_extension.form.request_handler.class' => 'Symfony\\Component\\Form\\Extension\\HttpFoundation\\HttpFoundationRequestHandler',
            'form.type_extension.csrf.enabled' => true,
            'form.type_extension.csrf.field_name' => '_token',
            'security.csrf.token_generator.class' => 'Symfony\\Component\\Security\\Csrf\\TokenGenerator\\UriSafeTokenGenerator',
            'security.csrf.token_storage.class' => 'Symfony\\Component\\Security\\Csrf\\TokenStorage\\SessionTokenStorage',
            'security.csrf.token_manager.class' => 'Symfony\\Component\\Security\\Csrf\\CsrfTokenManager',
            'templating.engine.delegating.class' => 'Symfony\\Bundle\\FrameworkBundle\\Templating\\DelegatingEngine',
            'templating.name_parser.class' => 'Symfony\\Bundle\\FrameworkBundle\\Templating\\TemplateNameParser',
            'templating.filename_parser.class' => 'Symfony\\Bundle\\FrameworkBundle\\Templating\\TemplateFilenameParser',
            'templating.cache_warmer.template_paths.class' => 'Symfony\\Bundle\\FrameworkBundle\\CacheWarmer\\TemplatePathsCacheWarmer',
            'templating.locator.class' => 'Symfony\\Bundle\\FrameworkBundle\\Templating\\Loader\\TemplateLocator',
            'templating.loader.filesystem.class' => 'Symfony\\Bundle\\FrameworkBundle\\Templating\\Loader\\FilesystemLoader',
            'templating.loader.cache.class' => 'Symfony\\Component\\Templating\\Loader\\CacheLoader',
            'templating.loader.chain.class' => 'Symfony\\Component\\Templating\\Loader\\ChainLoader',
            'templating.finder.class' => 'Symfony\\Bundle\\FrameworkBundle\\CacheWarmer\\TemplateFinder',
            'templating.helper.assets.class' => 'Symfony\\Bundle\\FrameworkBundle\\Templating\\Helper\\AssetsHelper',
            'templating.helper.router.class' => 'Symfony\\Bundle\\FrameworkBundle\\Templating\\Helper\\RouterHelper',
            'templating.helper.code.file_link_format' => NULL,
            'templating.loader.cache.path' => NULL,
            'templating.engines' => array(
                0 => 'twig',
            ),
            'validator.class' => 'Symfony\\Component\\Validator\\Validator\\ValidatorInterface',
            'validator.builder.class' => 'Symfony\\Component\\Validator\\ValidatorBuilderInterface',
            'validator.builder.factory.class' => 'Symfony\\Component\\Validator\\Validation',
            'validator.mapping.cache.apc.class' => 'Symfony\\Component\\Validator\\Mapping\\Cache\\ApcCache',
            'validator.mapping.cache.prefix' => '',
            'validator.validator_factory.class' => 'Symfony\\Bundle\\FrameworkBundle\\Validator\\ConstraintValidatorFactory',
            'validator.expression.class' => 'Symfony\\Component\\Validator\\Constraints\\ExpressionValidator',
            'validator.email.class' => 'Symfony\\Component\\Validator\\Constraints\\EmailValidator',
            'validator.translation_domain' => 'validators',
            'validator.api' => '2.5-bc',
            'fragment.listener.class' => 'Symfony\\Component\\HttpKernel\\EventListener\\FragmentListener',
            'translator.logging' => true,
            'profiler.class' => 'Symfony\\Component\\HttpKernel\\Profiler\\Profiler',
            'profiler_listener.class' => 'Symfony\\Component\\HttpKernel\\EventListener\\ProfilerListener',
            'data_collector.config.class' => 'Symfony\\Component\\HttpKernel\\DataCollector\\ConfigDataCollector',
            'data_collector.request.class' => 'Symfony\\Component\\HttpKernel\\DataCollector\\RequestDataCollector',
            'data_collector.exception.class' => 'Symfony\\Component\\HttpKernel\\DataCollector\\ExceptionDataCollector',
            'data_collector.events.class' => 'Symfony\\Component\\HttpKernel\\DataCollector\\EventDataCollector',
            'data_collector.logger.class' => 'Symfony\\Component\\HttpKernel\\DataCollector\\LoggerDataCollector',
            'data_collector.time.class' => 'Symfony\\Component\\HttpKernel\\DataCollector\\TimeDataCollector',
            'data_collector.memory.class' => 'Symfony\\Component\\HttpKernel\\DataCollector\\MemoryDataCollector',
            'data_collector.router.class' => 'Symfony\\Bundle\\FrameworkBundle\\DataCollector\\RouterDataCollector',
            'form.resolved_type_factory.data_collector_proxy.class' => 'Symfony\\Component\\Form\\Extension\\DataCollector\\Proxy\\ResolvedTypeFactoryDataCollectorProxy',
            'form.type_extension.form.data_collector.class' => 'Symfony\\Component\\Form\\Extension\\DataCollector\\Type\\DataCollectorTypeExtension',
            'data_collector.form.class' => 'Symfony\\Component\\Form\\Extension\\DataCollector\\FormDataCollector',
            'data_collector.form.extractor.class' => 'Symfony\\Component\\Form\\Extension\\DataCollector\\FormDataExtractor',
            'profiler_listener.only_exceptions' => false,
            'profiler_listener.only_master_requests' => false,
            'profiler.storage.dsn' => ('file:'.__DIR__.'/profiler'),
            'profiler.storage.username' => '',
            'profiler.storage.password' => '',
            'profiler.storage.lifetime' => 86400,
            'router.class' => 'Symfony\\Bundle\\FrameworkBundle\\Routing\\Router',
            'router.request_context.class' => 'Symfony\\Component\\Routing\\RequestContext',
            'routing.loader.class' => 'Symfony\\Bundle\\FrameworkBundle\\Routing\\DelegatingLoader',
            'routing.resolver.class' => 'Symfony\\Component\\Config\\Loader\\LoaderResolver',
            'routing.loader.xml.class' => 'Symfony\\Component\\Routing\\Loader\\XmlFileLoader',
            'routing.loader.yml.class' => 'Symfony\\Component\\Routing\\Loader\\YamlFileLoader',
            'routing.loader.php.class' => 'Symfony\\Component\\Routing\\Loader\\PhpFileLoader',
            'router.options.generator_class' => 'Symfony\\Component\\Routing\\Generator\\UrlGenerator',
            'router.options.generator_base_class' => 'Symfony\\Component\\Routing\\Generator\\UrlGenerator',
            'router.options.generator_dumper_class' => 'Symfony\\Component\\Routing\\Generator\\Dumper\\PhpGeneratorDumper',
            'router.options.matcher_class' => 'Symfony\\Bundle\\FrameworkBundle\\Routing\\RedirectableUrlMatcher',
            'router.options.matcher_base_class' => 'Symfony\\Bundle\\FrameworkBundle\\Routing\\RedirectableUrlMatcher',
            'router.options.matcher_dumper_class' => 'Symfony\\Component\\Routing\\Matcher\\Dumper\\PhpMatcherDumper',
            'router.cache_warmer.class' => 'Symfony\\Bundle\\FrameworkBundle\\CacheWarmer\\RouterCacheWarmer',
            'router.options.matcher.cache_class' => 'appDevUrlMatcher',
            'router.options.generator.cache_class' => 'appDevUrlGenerator',
            'router_listener.class' => 'Symfony\\Component\\HttpKernel\\EventListener\\RouterListener',
            'router.request_context.host' => 'localhost',
            'router.request_context.scheme' => 'http',
            'router.request_context.base_url' => '',
            'router.resource' => (__DIR__.'/assetic/routing.yml'),
            'router.cache_class_prefix' => 'appDev',
            'request_listener.http_port' => 80,
            'request_listener.https_port' => 443,
            'annotations.reader.class' => 'Doctrine\\Common\\Annotations\\AnnotationReader',
            'annotations.cached_reader.class' => 'Doctrine\\Common\\Annotations\\CachedReader',
            'annotations.file_cache_reader.class' => 'Doctrine\\Common\\Annotations\\FileCacheReader',
            'debug.debug_handlers_listener.class' => 'Symfony\\Component\\HttpKernel\\EventListener\\DebugHandlersListener',
            'debug.stopwatch.class' => 'Symfony\\Component\\Stopwatch\\Stopwatch',
            'debug.error_handler.throw_at' => -1,
            'debug.event_dispatcher.class' => 'Symfony\\Component\\HttpKernel\\Debug\\TraceableEventDispatcher',
            'debug.container.dump' => (__DIR__.'/appDevDebugProjectContainer.xml'),
            'debug.controller_resolver.class' => 'Symfony\\Component\\HttpKernel\\Controller\\TraceableControllerResolver',
            'security.context.class' => 'Symfony\\Component\\Security\\Core\\SecurityContext',
            'security.user_checker.class' => 'Symfony\\Component\\Security\\Core\\User\\UserChecker',
            'security.encoder_factory.generic.class' => 'Symfony\\Component\\Security\\Core\\Encoder\\EncoderFactory',
            'security.encoder.digest.class' => 'Symfony\\Component\\Security\\Core\\Encoder\\MessageDigestPasswordEncoder',
            'security.encoder.plain.class' => 'Symfony\\Component\\Security\\Core\\Encoder\\PlaintextPasswordEncoder',
            'security.encoder.pbkdf2.class' => 'Symfony\\Component\\Security\\Core\\Encoder\\Pbkdf2PasswordEncoder',
            'security.encoder.bcrypt.class' => 'Symfony\\Component\\Security\\Core\\Encoder\\BCryptPasswordEncoder',
            'security.user.provider.in_memory.class' => 'Symfony\\Component\\Security\\Core\\User\\InMemoryUserProvider',
            'security.user.provider.in_memory.user.class' => 'Symfony\\Component\\Security\\Core\\User\\User',
            'security.user.provider.chain.class' => 'Symfony\\Component\\Security\\Core\\User\\ChainUserProvider',
            'security.authentication.trust_resolver.class' => 'Symfony\\Component\\Security\\Core\\Authentication\\AuthenticationTrustResolver',
            'security.authentication.trust_resolver.anonymous_class' => 'Symfony\\Component\\Security\\Core\\Authentication\\Token\\AnonymousToken',
            'security.authentication.trust_resolver.rememberme_class' => 'Symfony\\Component\\Security\\Core\\Authentication\\Token\\RememberMeToken',
            'security.authentication.manager.class' => 'Symfony\\Component\\Security\\Core\\Authentication\\AuthenticationProviderManager',
            'security.authentication.session_strategy.class' => 'Symfony\\Component\\Security\\Http\\Session\\SessionAuthenticationStrategy',
            'security.access.decision_manager.class' => 'Symfony\\Component\\Security\\Core\\Authorization\\AccessDecisionManager',
            'security.access.simple_role_voter.class' => 'Symfony\\Component\\Security\\Core\\Authorization\\Voter\\RoleVoter',
            'security.access.authenticated_voter.class' => 'Symfony\\Component\\Security\\Core\\Authorization\\Voter\\AuthenticatedVoter',
            'security.access.role_hierarchy_voter.class' => 'Symfony\\Component\\Security\\Core\\Authorization\\Voter\\RoleHierarchyVoter',
            'security.access.expression_voter.class' => 'Symfony\\Component\\Security\\Core\\Authorization\\Voter\\ExpressionVoter',
            'security.firewall.class' => 'Symfony\\Component\\Security\\Http\\Firewall',
            'security.firewall.map.class' => 'Symfony\\Bundle\\SecurityBundle\\Security\\FirewallMap',
            'security.firewall.context.class' => 'Symfony\\Bundle\\SecurityBundle\\Security\\FirewallContext',
            'security.matcher.class' => 'Symfony\\Component\\HttpFoundation\\RequestMatcher',
            'security.expression_matcher.class' => 'Symfony\\Component\\HttpFoundation\\ExpressionRequestMatcher',
            'security.role_hierarchy.class' => 'Symfony\\Component\\Security\\Core\\Role\\RoleHierarchy',
            'security.http_utils.class' => 'Symfony\\Component\\Security\\Http\\HttpUtils',
            'security.validator.user_password.class' => 'Symfony\\Component\\Security\\Core\\Validator\\Constraints\\UserPasswordValidator',
            'security.expression_language.class' => 'Symfony\\Component\\Security\\Core\\Authorization\\ExpressionLanguage',
            'security.authentication.retry_entry_point.class' => 'Symfony\\Component\\Security\\Http\\EntryPoint\\RetryAuthenticationEntryPoint',
            'security.channel_listener.class' => 'Symfony\\Component\\Security\\Http\\Firewall\\ChannelListener',
            'security.authentication.form_entry_point.class' => 'Symfony\\Component\\Security\\Http\\EntryPoint\\FormAuthenticationEntryPoint',
            'security.authentication.listener.form.class' => 'Symfony\\Component\\Security\\Http\\Firewall\\UsernamePasswordFormAuthenticationListener',
            'security.authentication.listener.simple_form.class' => 'Symfony\\Component\\Security\\Http\\Firewall\\SimpleFormAuthenticationListener',
            'security.authentication.listener.simple_preauth.class' => 'Symfony\\Component\\Security\\Http\\Firewall\\SimplePreAuthenticationListener',
            'security.authentication.listener.basic.class' => 'Symfony\\Component\\Security\\Http\\Firewall\\BasicAuthenticationListener',
            'security.authentication.basic_entry_point.class' => 'Symfony\\Component\\Security\\Http\\EntryPoint\\BasicAuthenticationEntryPoint',
            'security.authentication.listener.digest.class' => 'Symfony\\Component\\Security\\Http\\Firewall\\DigestAuthenticationListener',
            'security.authentication.digest_entry_point.class' => 'Symfony\\Component\\Security\\Http\\EntryPoint\\DigestAuthenticationEntryPoint',
            'security.authentication.listener.x509.class' => 'Symfony\\Component\\Security\\Http\\Firewall\\X509AuthenticationListener',
            'security.authentication.listener.anonymous.class' => 'Symfony\\Component\\Security\\Http\\Firewall\\AnonymousAuthenticationListener',
            'security.authentication.switchuser_listener.class' => 'Symfony\\Component\\Security\\Http\\Firewall\\SwitchUserListener',
            'security.logout_listener.class' => 'Symfony\\Component\\Security\\Http\\Firewall\\LogoutListener',
            'security.logout.handler.session.class' => 'Symfony\\Component\\Security\\Http\\Logout\\SessionLogoutHandler',
            'security.logout.handler.cookie_clearing.class' => 'Symfony\\Component\\Security\\Http\\Logout\\CookieClearingLogoutHandler',
            'security.logout.success_handler.class' => 'Symfony\\Component\\Security\\Http\\Logout\\DefaultLogoutSuccessHandler',
            'security.access_listener.class' => 'Symfony\\Component\\Security\\Http\\Firewall\\AccessListener',
            'security.access_map.class' => 'Symfony\\Component\\Security\\Http\\AccessMap',
            'security.exception_listener.class' => 'Symfony\\Component\\Security\\Http\\Firewall\\ExceptionListener',
            'security.context_listener.class' => 'Symfony\\Component\\Security\\Http\\Firewall\\ContextListener',
            'security.authentication.provider.dao.class' => 'Symfony\\Component\\Security\\Core\\Authentication\\Provider\\DaoAuthenticationProvider',
            'security.authentication.provider.simple.class' => 'Symfony\\Component\\Security\\Core\\Authentication\\Provider\\SimpleAuthenticationProvider',
            'security.authentication.provider.pre_authenticated.class' => 'Symfony\\Component\\Security\\Core\\Authentication\\Provider\\PreAuthenticatedAuthenticationProvider',
            'security.authentication.provider.anonymous.class' => 'Symfony\\Component\\Security\\Core\\Authentication\\Provider\\AnonymousAuthenticationProvider',
            'security.authentication.success_handler.class' => 'Symfony\\Component\\Security\\Http\\Authentication\\DefaultAuthenticationSuccessHandler',
            'security.authentication.failure_handler.class' => 'Symfony\\Component\\Security\\Http\\Authentication\\DefaultAuthenticationFailureHandler',
            'security.authentication.simple_success_failure_handler.class' => 'Symfony\\Component\\Security\\Http\\Authentication\\SimpleAuthenticationHandler',
            'security.authentication.provider.rememberme.class' => 'Symfony\\Component\\Security\\Core\\Authentication\\Provider\\RememberMeAuthenticationProvider',
            'security.authentication.listener.rememberme.class' => 'Symfony\\Component\\Security\\Http\\Firewall\\RememberMeListener',
            'security.rememberme.token.provider.in_memory.class' => 'Symfony\\Component\\Security\\Core\\Authentication\\RememberMe\\InMemoryTokenProvider',
            'security.authentication.rememberme.services.persistent.class' => 'Symfony\\Component\\Security\\Http\\RememberMe\\PersistentTokenBasedRememberMeServices',
            'security.authentication.rememberme.services.simplehash.class' => 'Symfony\\Component\\Security\\Http\\RememberMe\\TokenBasedRememberMeServices',
            'security.rememberme.response_listener.class' => 'Symfony\\Component\\Security\\Http\\RememberMe\\ResponseListener',
            'templating.helper.logout_url.class' => 'Symfony\\Bundle\\SecurityBundle\\Templating\\Helper\\LogoutUrlHelper',
            'templating.helper.security.class' => 'Symfony\\Bundle\\SecurityBundle\\Templating\\Helper\\SecurityHelper',
            'twig.extension.logout_url.class' => 'Symfony\\Bridge\\Twig\\Extension\\LogoutUrlExtension',
            'twig.extension.security.class' => 'Symfony\\Bridge\\Twig\\Extension\\SecurityExtension',
            'data_collector.security.class' => 'Symfony\\Bundle\\SecurityBundle\\DataCollector\\SecurityDataCollector',
            'security.access.denied_url' => NULL,
            'security.authentication.manager.erase_credentials' => true,
            'security.authentication.session_strategy.strategy' => 'migrate',
            'security.access.always_authenticate_before_granting' => false,
            'security.authentication.hide_user_not_found' => true,
            'security.role_hierarchy.roles' => array(
                'ROLE_ADMIN' => array(
                    0 => 'ROLE_USER',
                ),
                'ROLE_SUPER_ADMIN' => array(
                    0 => 'ROLE_ADMIN',
                ),
            ),
            'security.acl.permission_granting_strategy.class' => 'Symfony\\Component\\Security\\Acl\\Domain\\PermissionGrantingStrategy',
            'security.acl.voter.class' => 'Symfony\\Component\\Security\\Acl\\Voter\\AclVoter',
            'security.acl.permission.map.class' => 'Symfony\\Component\\Security\\Acl\\Permission\\BasicPermissionMap',
            'security.acl.object_identity_retrieval_strategy.class' => 'Symfony\\Component\\Security\\Acl\\Domain\\ObjectIdentityRetrievalStrategy',
            'security.acl.security_identity_retrieval_strategy.class' => 'Symfony\\Component\\Security\\Acl\\Domain\\SecurityIdentityRetrievalStrategy',
            'security.acl.collection_cache.class' => 'Symfony\\Component\\Security\\Acl\\Domain\\AclCollectionCache',
            'security.acl.cache.doctrine.class' => 'Symfony\\Component\\Security\\Acl\\Domain\\DoctrineAclCache',
            'security.acl.dbal.provider.class' => 'Symfony\\Component\\Security\\Acl\\Dbal\\MutableAclProvider',
            'security.acl.dbal.schema.class' => 'Symfony\\Component\\Security\\Acl\\Dbal\\Schema',
            'security.acl.dbal.schema_listener.class' => 'Symfony\\Bundle\\SecurityBundle\\EventListener\\AclSchemaListener',
            'security.acl.dbal.class_table_name' => 'acl_classes',
            'security.acl.dbal.entry_table_name' => 'acl_entries',
            'security.acl.dbal.oid_table_name' => 'acl_object_identities',
            'security.acl.dbal.oid_ancestors_table_name' => 'acl_object_identity_ancestors',
            'security.acl.dbal.sid_table_name' => 'acl_security_identities',
            'twig.class' => 'Twig_Environment',
            'twig.loader.filesystem.class' => 'Symfony\\Bundle\\TwigBundle\\Loader\\FilesystemLoader',
            'twig.loader.chain.class' => 'Twig_Loader_Chain',
            'templating.engine.twig.class' => 'Symfony\\Bundle\\TwigBundle\\TwigEngine',
            'twig.cache_warmer.class' => 'Symfony\\Bundle\\TwigBundle\\CacheWarmer\\TemplateCacheCacheWarmer',
            'twig.extension.trans.class' => 'Symfony\\Bridge\\Twig\\Extension\\TranslationExtension',
            'twig.extension.actions.class' => 'Symfony\\Bundle\\TwigBundle\\Extension\\ActionsExtension',
            'twig.extension.code.class' => 'Symfony\\Bridge\\Twig\\Extension\\CodeExtension',
            'twig.extension.routing.class' => 'Symfony\\Bridge\\Twig\\Extension\\RoutingExtension',
            'twig.extension.yaml.class' => 'Symfony\\Bridge\\Twig\\Extension\\YamlExtension',
            'twig.extension.form.class' => 'Symfony\\Bridge\\Twig\\Extension\\FormExtension',
            'twig.extension.httpkernel.class' => 'Symfony\\Bridge\\Twig\\Extension\\HttpKernelExtension',
            'twig.extension.debug.stopwatch.class' => 'Symfony\\Bridge\\Twig\\Extension\\StopwatchExtension',
            'twig.extension.expression.class' => 'Symfony\\Bridge\\Twig\\Extension\\ExpressionExtension',
            'twig.form.engine.class' => 'Symfony\\Bridge\\Twig\\Form\\TwigRendererEngine',
            'twig.form.renderer.class' => 'Symfony\\Bridge\\Twig\\Form\\TwigRenderer',
            'twig.translation.extractor.class' => 'Symfony\\Bridge\\Twig\\Translation\\TwigExtractor',
            'twig.exception_listener.class' => 'Symfony\\Component\\HttpKernel\\EventListener\\ExceptionListener',
            'twig.controller.exception.class' => 'Symfony\\Bundle\\TwigBundle\\Controller\\ExceptionController',
            'twig.controller.preview_error.class' => 'Symfony\\Bundle\\TwigBundle\\Controller\\PreviewErrorController',
            'twig.exception_listener.controller' => 'twig.controller.exception:showAction',
            'twig.form.resources' => array(
                0 => 'form_div_layout.html.twig',
                1 => 'bootstrap_3_horizontal_layout.html.twig',
            ),
            'monolog.logger.class' => 'Symfony\\Bridge\\Monolog\\Logger',
            'monolog.gelf.publisher.class' => 'Gelf\\MessagePublisher',
            'monolog.gelfphp.publisher.class' => 'Gelf\\Publisher',
            'monolog.handler.stream.class' => 'Monolog\\Handler\\StreamHandler',
            'monolog.handler.console.class' => 'Symfony\\Bridge\\Monolog\\Handler\\ConsoleHandler',
            'monolog.handler.group.class' => 'Monolog\\Handler\\GroupHandler',
            'monolog.handler.buffer.class' => 'Monolog\\Handler\\BufferHandler',
            'monolog.handler.rotating_file.class' => 'Monolog\\Handler\\RotatingFileHandler',
            'monolog.handler.syslog.class' => 'Monolog\\Handler\\SyslogHandler',
            'monolog.handler.syslogudp.class' => 'Monolog\\Handler\\SyslogUdpHandler',
            'monolog.handler.null.class' => 'Monolog\\Handler\\NullHandler',
            'monolog.handler.test.class' => 'Monolog\\Handler\\TestHandler',
            'monolog.handler.gelf.class' => 'Monolog\\Handler\\GelfHandler',
            'monolog.handler.rollbar.class' => 'Monolog\\Handler\\RollbarHandler',
            'monolog.handler.flowdock.class' => 'Monolog\\Handler\\FlowdockHandler',
            'monolog.handler.browser_console.class' => 'Monolog\\Handler\\BrowserConsoleHandler',
            'monolog.handler.firephp.class' => 'Symfony\\Bridge\\Monolog\\Handler\\FirePHPHandler',
            'monolog.handler.chromephp.class' => 'Symfony\\Bridge\\Monolog\\Handler\\ChromePhpHandler',
            'monolog.handler.debug.class' => 'Symfony\\Bridge\\Monolog\\Handler\\DebugHandler',
            'monolog.handler.swift_mailer.class' => 'Symfony\\Bridge\\Monolog\\Handler\\SwiftMailerHandler',
            'monolog.handler.native_mailer.class' => 'Monolog\\Handler\\NativeMailerHandler',
            'monolog.handler.socket.class' => 'Monolog\\Handler\\SocketHandler',
            'monolog.handler.pushover.class' => 'Monolog\\Handler\\PushoverHandler',
            'monolog.handler.raven.class' => 'Monolog\\Handler\\RavenHandler',
            'monolog.handler.newrelic.class' => 'Monolog\\Handler\\NewRelicHandler',
            'monolog.handler.hipchat.class' => 'Monolog\\Handler\\HipChatHandler',
            'monolog.handler.slack.class' => 'Monolog\\Handler\\SlackHandler',
            'monolog.handler.cube.class' => 'Monolog\\Handler\\CubeHandler',
            'monolog.handler.amqp.class' => 'Monolog\\Handler\\AmqpHandler',
            'monolog.handler.error_log.class' => 'Monolog\\Handler\\ErrorLogHandler',
            'monolog.handler.loggly.class' => 'Monolog\\Handler\\LogglyHandler',
            'monolog.handler.logentries.class' => 'Monolog\\Handler\\LogEntriesHandler',
            'monolog.handler.whatfailuregroup.class' => 'Monolog\\Handler\\WhatFailureGroupHandler',
            'monolog.activation_strategy.not_found.class' => 'Symfony\\Bundle\\MonologBundle\\NotFoundActivationStrategy',
            'monolog.handler.fingers_crossed.class' => 'Monolog\\Handler\\FingersCrossedHandler',
            'monolog.handler.fingers_crossed.error_level_activation_strategy.class' => 'Monolog\\Handler\\FingersCrossed\\ErrorLevelActivationStrategy',
            'monolog.handler.filter.class' => 'Monolog\\Handler\\FilterHandler',
            'monolog.handler.mongo.class' => 'Monolog\\Handler\\MongoDBHandler',
            'monolog.mongo.client.class' => 'MongoClient',
            'monolog.handler.elasticsearch.class' => 'Monolog\\Handler\\ElasticSearchHandler',
            'monolog.elastica.client.class' => 'Elastica\\Client',
            'monolog.swift_mailer.handlers' => array(

            ),
            'monolog.handlers_to_channels' => array(
                'monolog.handler.console_very_verbose' => array(
                    'type' => 'inclusive',
                    'elements' => array(
                        0 => 'doctrine',
                    ),
                ),
                'monolog.handler.console' => array(
                    'type' => 'exclusive',
                    'elements' => array(
                        0 => 'doctrine',
                    ),
                ),
                'monolog.handler.main' => NULL,
            ),
            'swiftmailer.class' => 'Swift_Mailer',
            'swiftmailer.transport.sendmail.class' => 'Swift_Transport_SendmailTransport',
            'swiftmailer.transport.mail.class' => 'Swift_Transport_MailTransport',
            'swiftmailer.transport.failover.class' => 'Swift_Transport_FailoverTransport',
            'swiftmailer.plugin.redirecting.class' => 'Swift_Plugins_RedirectingPlugin',
            'swiftmailer.plugin.impersonate.class' => 'Swift_Plugins_ImpersonatePlugin',
            'swiftmailer.plugin.messagelogger.class' => 'Swift_Plugins_MessageLogger',
            'swiftmailer.plugin.antiflood.class' => 'Swift_Plugins_AntiFloodPlugin',
            'swiftmailer.transport.smtp.class' => 'Swift_Transport_EsmtpTransport',
            'swiftmailer.plugin.blackhole.class' => 'Swift_Plugins_BlackholePlugin',
            'swiftmailer.spool.file.class' => 'Swift_FileSpool',
            'swiftmailer.spool.memory.class' => 'Swift_MemorySpool',
            'swiftmailer.email_sender.listener.class' => 'Symfony\\Bundle\\SwiftmailerBundle\\EventListener\\EmailSenderListener',
            'swiftmailer.data_collector.class' => 'Symfony\\Bundle\\SwiftmailerBundle\\DataCollector\\MessageDataCollector',
            'swiftmailer.mailer.default.transport.name' => 'smtp',
            'swiftmailer.mailer.default.delivery.enabled' => true,
            'swiftmailer.mailer.default.transport.smtp.encryption' => NULL,
            'swiftmailer.mailer.default.transport.smtp.port' => 25,
            'swiftmailer.mailer.default.transport.smtp.host' => '127.0.0.1',
            'swiftmailer.mailer.default.transport.smtp.username' => NULL,
            'swiftmailer.mailer.default.transport.smtp.password' => NULL,
            'swiftmailer.mailer.default.transport.smtp.auth_mode' => NULL,
            'swiftmailer.mailer.default.transport.smtp.timeout' => 30,
            'swiftmailer.mailer.default.transport.smtp.source_ip' => NULL,
            'swiftmailer.spool.default.memory.path' => (__DIR__.'/swiftmailer/spool/default'),
            'swiftmailer.mailer.default.spool.enabled' => true,
            'swiftmailer.mailer.default.plugin.impersonate' => NULL,
            'swiftmailer.mailer.default.single_address' => NULL,
            'swiftmailer.spool.enabled' => true,
            'swiftmailer.delivery.enabled' => true,
            'swiftmailer.single_address' => NULL,
            'swiftmailer.mailers' => array(
                'default' => 'swiftmailer.mailer.default',
            ),
            'swiftmailer.default_mailer' => 'default',
            'assetic.asset_factory.class' => 'Symfony\\Bundle\\AsseticBundle\\Factory\\AssetFactory',
            'assetic.asset_manager.class' => 'Assetic\\Factory\\LazyAssetManager',
            'assetic.asset_manager_cache_warmer.class' => 'Symfony\\Bundle\\AsseticBundle\\CacheWarmer\\AssetManagerCacheWarmer',
            'assetic.cached_formula_loader.class' => 'Assetic\\Factory\\Loader\\CachedFormulaLoader',
            'assetic.config_cache.class' => 'Assetic\\Cache\\ConfigCache',
            'assetic.config_loader.class' => 'Symfony\\Bundle\\AsseticBundle\\Factory\\Loader\\ConfigurationLoader',
            'assetic.config_resource.class' => 'Symfony\\Bundle\\AsseticBundle\\Factory\\Resource\\ConfigurationResource',
            'assetic.coalescing_directory_resource.class' => 'Symfony\\Bundle\\AsseticBundle\\Factory\\Resource\\CoalescingDirectoryResource',
            'assetic.directory_resource.class' => 'Symfony\\Bundle\\AsseticBundle\\Factory\\Resource\\DirectoryResource',
            'assetic.filter_manager.class' => 'Symfony\\Bundle\\AsseticBundle\\FilterManager',
            'assetic.worker.ensure_filter.class' => 'Assetic\\Factory\\Worker\\EnsureFilterWorker',
            'assetic.worker.cache_busting.class' => 'Assetic\\Factory\\Worker\\CacheBustingWorker',
            'assetic.value_supplier.class' => 'Symfony\\Bundle\\AsseticBundle\\DefaultValueSupplier',
            'assetic.node.paths' => array(

            ),
            'assetic.cache_dir' => (__DIR__.'/assetic'),
            'assetic.bundles' => array(

            ),
            'assetic.twig_extension.class' => 'Symfony\\Bundle\\AsseticBundle\\Twig\\AsseticExtension',
            'assetic.twig_formula_loader.class' => 'Assetic\\Extension\\Twig\\TwigFormulaLoader',
            'assetic.helper.dynamic.class' => 'Symfony\\Bundle\\AsseticBundle\\Templating\\DynamicAsseticHelper',
            'assetic.helper.static.class' => 'Symfony\\Bundle\\AsseticBundle\\Templating\\StaticAsseticHelper',
            'assetic.php_formula_loader.class' => 'Symfony\\Bundle\\AsseticBundle\\Factory\\Loader\\AsseticHelperFormulaLoader',
            'assetic.debug' => true,
            'assetic.use_controller' => true,
            'assetic.enable_profiler' => false,
            'assetic.read_from' => ($this->targetDirs[2].'/../web'),
            'assetic.write_to' => ($this->targetDirs[2].'/../web'),
            'assetic.variables' => array(

            ),
            'assetic.java.bin' => '/usr/bin/java',
            'assetic.node.bin' => '/usr/bin/node',
            'assetic.ruby.bin' => '/usr/bin/ruby',
            'assetic.sass.bin' => '/usr/bin/sass',
            'assetic.reactjsx.bin' => '/usr/bin/jsx',
            'assetic.filter.cssrewrite.class' => 'Assetic\\Filter\\CssRewriteFilter',
            'assetic.twig_extension.functions' => array(

            ),
            'assetic.controller.class' => 'Symfony\\Bundle\\AsseticBundle\\Controller\\AsseticController',
            'assetic.routing_loader.class' => 'Symfony\\Bundle\\AsseticBundle\\Routing\\AsseticLoader',
            'assetic.cache.class' => 'Assetic\\Cache\\FilesystemCache',
            'assetic.use_controller_worker.class' => 'Symfony\\Bundle\\AsseticBundle\\Factory\\Worker\\UseControllerWorker',
            'assetic.request_listener.class' => 'Symfony\\Bundle\\AsseticBundle\\EventListener\\RequestListener',
            'doctrine_cache.apc.class' => 'Doctrine\\Common\\Cache\\ApcCache',
            'doctrine_cache.apcu.class' => 'Doctrine\\Common\\Cache\\ApcuCache',
            'doctrine_cache.array.class' => 'Doctrine\\Common\\Cache\\ArrayCache',
            'doctrine_cache.chain.class' => 'Doctrine\\Common\\Cache\\ChainCache',
            'doctrine_cache.couchbase.class' => 'Doctrine\\Common\\Cache\\CouchbaseCache',
            'doctrine_cache.couchbase.connection.class' => 'Couchbase',
            'doctrine_cache.couchbase.hostnames' => 'localhost:8091',
            'doctrine_cache.file_system.class' => 'Doctrine\\Common\\Cache\\FilesystemCache',
            'doctrine_cache.php_file.class' => 'Doctrine\\Common\\Cache\\PhpFileCache',
            'doctrine_cache.memcache.class' => 'Doctrine\\Common\\Cache\\MemcacheCache',
            'doctrine_cache.memcache.connection.class' => 'Memcache',
            'doctrine_cache.memcache.host' => 'localhost',
            'doctrine_cache.memcache.port' => 11211,
            'doctrine_cache.memcached.class' => 'Doctrine\\Common\\Cache\\MemcachedCache',
            'doctrine_cache.memcached.connection.class' => 'Memcached',
            'doctrine_cache.memcached.host' => 'localhost',
            'doctrine_cache.memcached.port' => 11211,
            'doctrine_cache.mongodb.class' => 'Doctrine\\Common\\Cache\\MongoDBCache',
            'doctrine_cache.mongodb.collection.class' => 'MongoCollection',
            'doctrine_cache.mongodb.connection.class' => 'MongoClient',
            'doctrine_cache.mongodb.server' => 'localhost:27017',
            'doctrine_cache.predis.client.class' => 'Predis\\Client',
            'doctrine_cache.predis.scheme' => 'tcp',
            'doctrine_cache.predis.host' => 'localhost',
            'doctrine_cache.predis.port' => 6379,
            'doctrine_cache.redis.class' => 'Doctrine\\Common\\Cache\\RedisCache',
            'doctrine_cache.redis.connection.class' => 'Redis',
            'doctrine_cache.redis.host' => 'localhost',
            'doctrine_cache.redis.port' => 6379,
            'doctrine_cache.riak.class' => 'Doctrine\\Common\\Cache\\RiakCache',
            'doctrine_cache.riak.bucket.class' => 'Riak\\Bucket',
            'doctrine_cache.riak.connection.class' => 'Riak\\Connection',
            'doctrine_cache.riak.bucket_property_list.class' => 'Riak\\BucketPropertyList',
            'doctrine_cache.riak.host' => 'localhost',
            'doctrine_cache.riak.port' => 8087,
            'doctrine_cache.sqlite3.class' => 'Doctrine\\Common\\Cache\\SQLite3Cache',
            'doctrine_cache.sqlite3.connection.class' => 'SQLite3',
            'doctrine_cache.void.class' => 'Doctrine\\Common\\Cache\\VoidCache',
            'doctrine_cache.wincache.class' => 'Doctrine\\Common\\Cache\\WinCacheCache',
            'doctrine_cache.xcache.class' => 'Doctrine\\Common\\Cache\\XcacheCache',
            'doctrine_cache.zenddata.class' => 'Doctrine\\Common\\Cache\\ZendDataCache',
            'doctrine_cache.security.acl.cache.class' => 'Doctrine\\Bundle\\DoctrineCacheBundle\\Acl\\Model\\AclCache',
            'doctrine.dbal.logger.chain.class' => 'Doctrine\\DBAL\\Logging\\LoggerChain',
            'doctrine.dbal.logger.profiling.class' => 'Doctrine\\DBAL\\Logging\\DebugStack',
            'doctrine.dbal.logger.class' => 'Symfony\\Bridge\\Doctrine\\Logger\\DbalLogger',
            'doctrine.dbal.configuration.class' => 'Doctrine\\DBAL\\Configuration',
            'doctrine.data_collector.class' => 'Doctrine\\Bundle\\DoctrineBundle\\DataCollector\\DoctrineDataCollector',
            'doctrine.dbal.connection.event_manager.class' => 'Symfony\\Bridge\\Doctrine\\ContainerAwareEventManager',
            'doctrine.dbal.connection_factory.class' => 'Doctrine\\Bundle\\DoctrineBundle\\ConnectionFactory',
            'doctrine.dbal.events.mysql_session_init.class' => 'Doctrine\\DBAL\\Event\\Listeners\\MysqlSessionInit',
            'doctrine.dbal.events.oracle_session_init.class' => 'Doctrine\\DBAL\\Event\\Listeners\\OracleSessionInit',
            'doctrine.class' => 'Doctrine\\Bundle\\DoctrineBundle\\Registry',
            'doctrine.entity_managers' => array(
                'default' => 'doctrine.orm.default_entity_manager',
            ),
            'doctrine.default_entity_manager' => 'default',
            'doctrine.dbal.connection_factory.types' => array(

            ),
            'doctrine.connections' => array(
                'default' => 'doctrine.dbal.default_connection',
            ),
            'doctrine.default_connection' => 'default',
            'doctrine.orm.configuration.class' => 'Doctrine\\ORM\\Configuration',
            'doctrine.orm.entity_manager.class' => 'Doctrine\\ORM\\EntityManager',
            'doctrine.orm.manager_configurator.class' => 'Doctrine\\Bundle\\DoctrineBundle\\ManagerConfigurator',
            'doctrine.orm.cache.array.class' => 'Doctrine\\Common\\Cache\\ArrayCache',
            'doctrine.orm.cache.apc.class' => 'Doctrine\\Common\\Cache\\ApcCache',
            'doctrine.orm.cache.memcache.class' => 'Doctrine\\Common\\Cache\\MemcacheCache',
            'doctrine.orm.cache.memcache_host' => 'localhost',
            'doctrine.orm.cache.memcache_port' => 11211,
            'doctrine.orm.cache.memcache_instance.class' => 'Memcache',
            'doctrine.orm.cache.memcached.class' => 'Doctrine\\Common\\Cache\\MemcachedCache',
            'doctrine.orm.cache.memcached_host' => 'localhost',
            'doctrine.orm.cache.memcached_port' => 11211,
            'doctrine.orm.cache.memcached_instance.class' => 'Memcached',
            'doctrine.orm.cache.redis.class' => 'Doctrine\\Common\\Cache\\RedisCache',
            'doctrine.orm.cache.redis_host' => 'localhost',
            'doctrine.orm.cache.redis_port' => 6379,
            'doctrine.orm.cache.redis_instance.class' => 'Redis',
            'doctrine.orm.cache.xcache.class' => 'Doctrine\\Common\\Cache\\XcacheCache',
            'doctrine.orm.cache.wincache.class' => 'Doctrine\\Common\\Cache\\WinCacheCache',
            'doctrine.orm.cache.zenddata.class' => 'Doctrine\\Common\\Cache\\ZendDataCache',
            'doctrine.orm.metadata.driver_chain.class' => 'Doctrine\\Common\\Persistence\\Mapping\\Driver\\MappingDriverChain',
            'doctrine.orm.metadata.annotation.class' => 'Doctrine\\ORM\\Mapping\\Driver\\AnnotationDriver',
            'doctrine.orm.metadata.xml.class' => 'Doctrine\\ORM\\Mapping\\Driver\\SimplifiedXmlDriver',
            'doctrine.orm.metadata.yml.class' => 'Doctrine\\ORM\\Mapping\\Driver\\SimplifiedYamlDriver',
            'doctrine.orm.metadata.php.class' => 'Doctrine\\ORM\\Mapping\\Driver\\PHPDriver',
            'doctrine.orm.metadata.staticphp.class' => 'Doctrine\\ORM\\Mapping\\Driver\\StaticPHPDriver',
            'doctrine.orm.proxy_cache_warmer.class' => 'Symfony\\Bridge\\Doctrine\\CacheWarmer\\ProxyCacheWarmer',
            'form.type_guesser.doctrine.class' => 'Symfony\\Bridge\\Doctrine\\Form\\DoctrineOrmTypeGuesser',
            'doctrine.orm.validator.unique.class' => 'Symfony\\Bridge\\Doctrine\\Validator\\Constraints\\UniqueEntityValidator',
            'doctrine.orm.validator_initializer.class' => 'Symfony\\Bridge\\Doctrine\\Validator\\DoctrineInitializer',
            'doctrine.orm.security.user.provider.class' => 'Symfony\\Bridge\\Doctrine\\Security\\User\\EntityUserProvider',
            'doctrine.orm.listeners.resolve_target_entity.class' => 'Doctrine\\ORM\\Tools\\ResolveTargetEntityListener',
            'doctrine.orm.listeners.attach_entity_listeners.class' => 'Doctrine\\ORM\\Tools\\AttachEntityListenersListener',
            'doctrine.orm.naming_strategy.default.class' => 'Doctrine\\ORM\\Mapping\\DefaultNamingStrategy',
            'doctrine.orm.naming_strategy.underscore.class' => 'Doctrine\\ORM\\Mapping\\UnderscoreNamingStrategy',
            'doctrine.orm.quote_strategy.default.class' => 'Doctrine\\ORM\\Mapping\\DefaultQuoteStrategy',
            'doctrine.orm.quote_strategy.ansi.class' => 'Doctrine\\ORM\\Mapping\\AnsiQuoteStrategy',
            'doctrine.orm.entity_listener_resolver.class' => 'Doctrine\\ORM\\Mapping\\DefaultEntityListenerResolver',
            'doctrine.orm.second_level_cache.default_cache_factory.class' => 'Doctrine\\ORM\\Cache\\DefaultCacheFactory',
            'doctrine.orm.second_level_cache.default_region.class' => 'Doctrine\\ORM\\Cache\\Region\\DefaultRegion',
            'doctrine.orm.second_level_cache.filelock_region.class' => 'Doctrine\\ORM\\Cache\\Region\\FileLockRegion',
            'doctrine.orm.second_level_cache.logger_chain.class' => 'Doctrine\\ORM\\Cache\\Logging\\CacheLoggerChain',
            'doctrine.orm.second_level_cache.logger_statistics.class' => 'Doctrine\\ORM\\Cache\\Logging\\StatisticsCacheLogger',
            'doctrine.orm.second_level_cache.cache_configuration.class' => 'Doctrine\\ORM\\Cache\\CacheConfiguration',
            'doctrine.orm.second_level_cache.regions_configuration.class' => 'Doctrine\\ORM\\Cache\\RegionsConfiguration',
            'doctrine.orm.auto_generate_proxy_classes' => true,
            'doctrine.orm.proxy_dir' => (__DIR__.'/doctrine/orm/Proxies'),
            'doctrine.orm.proxy_namespace' => 'Proxies',
            'sensio_framework_extra.view.guesser.class' => 'Sensio\\Bundle\\FrameworkExtraBundle\\Templating\\TemplateGuesser',
            'sensio_framework_extra.controller.listener.class' => 'Sensio\\Bundle\\FrameworkExtraBundle\\EventListener\\ControllerListener',
            'sensio_framework_extra.routing.loader.annot_dir.class' => 'Symfony\\Component\\Routing\\Loader\\AnnotationDirectoryLoader',
            'sensio_framework_extra.routing.loader.annot_file.class' => 'Symfony\\Component\\Routing\\Loader\\AnnotationFileLoader',
            'sensio_framework_extra.routing.loader.annot_class.class' => 'Sensio\\Bundle\\FrameworkExtraBundle\\Routing\\AnnotatedRouteControllerLoader',
            'sensio_framework_extra.converter.listener.class' => 'Sensio\\Bundle\\FrameworkExtraBundle\\EventListener\\ParamConverterListener',
            'sensio_framework_extra.converter.manager.class' => 'Sensio\\Bundle\\FrameworkExtraBundle\\Request\\ParamConverter\\ParamConverterManager',
            'sensio_framework_extra.converter.doctrine.class' => 'Sensio\\Bundle\\FrameworkExtraBundle\\Request\\ParamConverter\\DoctrineParamConverter',
            'sensio_framework_extra.converter.datetime.class' => 'Sensio\\Bundle\\FrameworkExtraBundle\\Request\\ParamConverter\\DateTimeParamConverter',
            'sensio_framework_extra.view.listener.class' => 'Sensio\\Bundle\\FrameworkExtraBundle\\EventListener\\TemplateListener',
            'jms_serializer.metadata.file_locator.class' => 'Metadata\\Driver\\FileLocator',
            'jms_serializer.metadata.annotation_driver.class' => 'JMS\\Serializer\\Metadata\\Driver\\AnnotationDriver',
            'jms_serializer.metadata.chain_driver.class' => 'Metadata\\Driver\\DriverChain',
            'jms_serializer.metadata.yaml_driver.class' => 'JMS\\Serializer\\Metadata\\Driver\\YamlDriver',
            'jms_serializer.metadata.xml_driver.class' => 'JMS\\Serializer\\Metadata\\Driver\\XmlDriver',
            'jms_serializer.metadata.php_driver.class' => 'JMS\\Serializer\\Metadata\\Driver\\PhpDriver',
            'jms_serializer.metadata.doctrine_type_driver.class' => 'JMS\\Serializer\\Metadata\\Driver\\DoctrineTypeDriver',
            'jms_serializer.metadata.doctrine_phpcr_type_driver.class' => 'JMS\\Serializer\\Metadata\\Driver\\DoctrinePHPCRTypeDriver',
            'jms_serializer.metadata.lazy_loading_driver.class' => 'Metadata\\Driver\\LazyLoadingDriver',
            'jms_serializer.metadata.metadata_factory.class' => 'Metadata\\MetadataFactory',
            'jms_serializer.metadata.cache.file_cache.class' => 'Metadata\\Cache\\FileCache',
            'jms_serializer.event_dispatcher.class' => 'JMS\\Serializer\\EventDispatcher\\LazyEventDispatcher',
            'jms_serializer.camel_case_naming_strategy.class' => 'JMS\\Serializer\\Naming\\CamelCaseNamingStrategy',
            'jms_serializer.serialized_name_annotation_strategy.class' => 'JMS\\Serializer\\Naming\\SerializedNameAnnotationStrategy',
            'jms_serializer.cache_naming_strategy.class' => 'JMS\\Serializer\\Naming\\CacheNamingStrategy',
            'jms_serializer.doctrine_object_constructor.class' => 'JMS\\Serializer\\Construction\\DoctrineObjectConstructor',
            'jms_serializer.unserialize_object_constructor.class' => 'JMS\\Serializer\\Construction\\UnserializeObjectConstructor',
            'jms_serializer.version_exclusion_strategy.class' => 'JMS\\Serializer\\Exclusion\\VersionExclusionStrategy',
            'jms_serializer.serializer.class' => 'JMS\\Serializer\\Serializer',
            'jms_serializer.twig_extension.class' => 'JMS\\Serializer\\Twig\\SerializerExtension',
            'jms_serializer.templating.helper.class' => 'JMS\\SerializerBundle\\Templating\\SerializerHelper',
            'jms_serializer.json_serialization_visitor.class' => 'JMS\\Serializer\\JsonSerializationVisitor',
            'jms_serializer.json_serialization_visitor.options' => 0,
            'jms_serializer.json_deserialization_visitor.class' => 'JMS\\Serializer\\JsonDeserializationVisitor',
            'jms_serializer.xml_serialization_visitor.class' => 'JMS\\Serializer\\XmlSerializationVisitor',
            'jms_serializer.xml_deserialization_visitor.class' => 'JMS\\Serializer\\XmlDeserializationVisitor',
            'jms_serializer.xml_deserialization_visitor.doctype_whitelist' => array(

            ),
            'jms_serializer.yaml_serialization_visitor.class' => 'JMS\\Serializer\\YamlSerializationVisitor',
            'jms_serializer.handler_registry.class' => 'JMS\\Serializer\\Handler\\LazyHandlerRegistry',
            'jms_serializer.datetime_handler.class' => 'JMS\\Serializer\\Handler\\DateHandler',
            'jms_serializer.array_collection_handler.class' => 'JMS\\Serializer\\Handler\\ArrayCollectionHandler',
            'jms_serializer.php_collection_handler.class' => 'JMS\\Serializer\\Handler\\PhpCollectionHandler',
            'jms_serializer.form_error_handler.class' => 'JMS\\Serializer\\Handler\\FormErrorHandler',
            'jms_serializer.constraint_violation_handler.class' => 'JMS\\Serializer\\Handler\\ConstraintViolationHandler',
            'jms_serializer.doctrine_proxy_subscriber.class' => 'JMS\\Serializer\\EventDispatcher\\Subscriber\\DoctrineProxySubscriber',
            'jms_serializer.stopwatch_subscriber.class' => 'JMS\\SerializerBundle\\Serializer\\StopwatchEventSubscriber',
            'stof_doctrine_extensions.event_listener.locale.class' => 'Stof\\DoctrineExtensionsBundle\\EventListener\\LocaleListener',
            'stof_doctrine_extensions.event_listener.logger.class' => 'Stof\\DoctrineExtensionsBundle\\EventListener\\LoggerListener',
            'stof_doctrine_extensions.event_listener.blame.class' => 'Stof\\DoctrineExtensionsBundle\\EventListener\\BlameListener',
            'stof_doctrine_extensions.uploadable.manager.class' => 'Stof\\DoctrineExtensionsBundle\\Uploadable\\UploadableManager',
            'stof_doctrine_extensions.uploadable.mime_type_guesser.class' => 'Stof\\DoctrineExtensionsBundle\\Uploadable\\MimeTypeGuesserAdapter',
            'stof_doctrine_extensions.uploadable.default_file_info.class' => 'Stof\\DoctrineExtensionsBundle\\Uploadable\\UploadedFileInfo',
            'stof_doctrine_extensions.default_locale' => 'en',
            'stof_doctrine_extensions.default_file_path' => NULL,
            'stof_doctrine_extensions.translation_fallback' => false,
            'stof_doctrine_extensions.persist_default_translation' => false,
            'stof_doctrine_extensions.skip_translation_on_load' => false,
            'stof_doctrine_extensions.uploadable.validate_writable_directory' => true,
            'stof_doctrine_extensions.listener.translatable.class' => 'Gedmo\\Translatable\\TranslatableListener',
            'stof_doctrine_extensions.listener.timestampable.class' => 'Gedmo\\Timestampable\\TimestampableListener',
            'stof_doctrine_extensions.listener.blameable.class' => 'Gedmo\\Blameable\\BlameableListener',
            'stof_doctrine_extensions.listener.sluggable.class' => 'Gedmo\\Sluggable\\SluggableListener',
            'stof_doctrine_extensions.listener.tree.class' => 'Gedmo\\Tree\\TreeListener',
            'stof_doctrine_extensions.listener.loggable.class' => 'Gedmo\\Loggable\\LoggableListener',
            'stof_doctrine_extensions.listener.sortable.class' => 'Gedmo\\Sortable\\SortableListener',
            'stof_doctrine_extensions.listener.softdeleteable.class' => 'Gedmo\\SoftDeleteable\\SoftDeleteableListener',
            'stof_doctrine_extensions.listener.uploadable.class' => 'Gedmo\\Uploadable\\UploadableListener',
            'stof_doctrine_extensions.listener.reference_integrity.class' => 'Gedmo\\ReferenceIntegrity\\ReferenceIntegrityListener',
            'fos_user.backend_type_orm' => true,
            'fos_user.security.interactive_login_listener.class' => 'FOS\\UserBundle\\EventListener\\LastLoginListener',
            'fos_user.security.login_manager.class' => 'FOS\\UserBundle\\Security\\LoginManager',
            'fos_user.resetting.email.template' => 'FOSUserBundle:Resetting:email.txt.twig',
            'fos_user.registration.confirmation.template' => 'FOSUserBundle:Registration:email.txt.twig',
            'fos_user.storage' => 'orm',
            'fos_user.firewall_name' => 'main',
            'fos_user.model_manager_name' => NULL,
            'fos_user.model.user.class' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
            'fos_user.profile.form.type' => 'app_user_profile',
            'fos_user.profile.form.name' => 'fos_user_profile_form',
            'fos_user.profile.form.validation_groups' => array(
                0 => 'Profile',
                1 => 'Default',
            ),
            'fos_user.registration.confirmation.from_email' => array(
                'webmaster@example.com' => 'webmaster',
            ),
            'fos_user.registration.confirmation.enabled' => false,
            'fos_user.registration.form.type' => 'app_user_registration',
            'fos_user.registration.form.name' => 'fos_user_registration_form',
            'fos_user.registration.form.validation_groups' => array(
                0 => 'Registration',
                1 => 'Default',
            ),
            'fos_user.change_password.form.type' => 'fos_user_change_password',
            'fos_user.change_password.form.name' => 'fos_user_change_password_form',
            'fos_user.change_password.form.validation_groups' => array(
                0 => 'ChangePassword',
                1 => 'Default',
            ),
            'fos_user.resetting.email.from_email' => array(
                'webmaster@example.com' => 'webmaster',
            ),
            'fos_user.resetting.token_ttl' => 86400,
            'fos_user.resetting.form.type' => 'fos_user_resetting',
            'fos_user.resetting.form.name' => 'fos_user_resetting_form',
            'fos_user.resetting.form.validation_groups' => array(
                0 => 'ResetPassword',
                1 => 'Default',
            ),
            'easyadmin.config' => array(
                'entities' => array(
                    'User' => array(
                        'class' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                        'name' => 'User',
                        'label' => 'User',
                        'edit' => array(
                            'fields' => array(
                                'username' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'username',
                                    'columnName' => 'username',
                                    'length' => 255,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'username',
                                ),
                                'usernameCanonical' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'usernameCanonical',
                                    'columnName' => 'username_canonical',
                                    'length' => 255,
                                    'unique' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'usernameCanonical',
                                ),
                                'email' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'email',
                                    'columnName' => 'email',
                                    'length' => 255,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'email',
                                ),
                                'emailCanonical' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'emailCanonical',
                                    'columnName' => 'email_canonical',
                                    'length' => 255,
                                    'unique' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'emailCanonical',
                                ),
                                'enabled' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'boolean',
                                    'fieldType' => 'checkbox',
                                    'dataType' => 'toggle',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'enabled',
                                    'columnName' => 'enabled',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'enabled',
                                ),
                                'salt' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'salt',
                                    'columnName' => 'salt',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'salt',
                                ),
                                'password' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'password',
                                    'columnName' => 'password',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'password',
                                ),
                                'lastLogin' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'lastLogin',
                                    'columnName' => 'last_login',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'lastLogin',
                                ),
                                'locked' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'boolean',
                                    'fieldType' => 'checkbox',
                                    'dataType' => 'toggle',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'locked',
                                    'columnName' => 'locked',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'locked',
                                ),
                                'expired' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'boolean',
                                    'fieldType' => 'checkbox',
                                    'dataType' => 'toggle',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'expired',
                                    'columnName' => 'expired',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'expired',
                                ),
                                'expiresAt' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'expiresAt',
                                    'columnName' => 'expires_at',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'expiresAt',
                                ),
                                'confirmationToken' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'confirmationToken',
                                    'columnName' => 'confirmation_token',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'confirmationToken',
                                ),
                                'passwordRequestedAt' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'passwordRequestedAt',
                                    'columnName' => 'password_requested_at',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'passwordRequestedAt',
                                ),
                                'roles' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'array',
                                    'fieldType' => 'collection',
                                    'dataType' => 'array',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'roles',
                                    'columnName' => 'roles',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'roles',
                                ),
                                'credentialsExpired' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'boolean',
                                    'fieldType' => 'checkbox',
                                    'dataType' => 'toggle',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'credentialsExpired',
                                    'columnName' => 'credentials_expired',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'credentialsExpired',
                                ),
                                'credentialsExpireAt' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'credentialsExpireAt',
                                    'columnName' => 'credentials_expire_at',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'credentialsExpireAt',
                                ),
                                'timerecords' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'timerecords',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Timerecord',
                                    'mappedBy' => 'users',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'timerecords',
                                ),
                                'payrolls' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'payrolls',
                                    'targetEntity' => 'EdgeWeb\\Project\\PaycomBundle\\Entity\\Payroll',
                                    'mappedBy' => 'users',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'payrolls',
                                ),
                                'position' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'position',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                    'inversedBy' => 'users',
                                    'joinColumns' => array(
                                        0 => array(
                                            'referencedColumnName' => 'id',
                                            'name' => 'position_id',
                                        ),
                                    ),
                                    'cascade' => array(

                                    ),
                                    'mappedBy' => NULL,
                                    'isOwningSide' => true,
                                    'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                    'fetch' => 2,
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'sourceToTargetKeyColumns' => array(
                                        'position_id' => 'id',
                                    ),
                                    'joinColumnFieldNames' => array(
                                        'position_id' => 'position_id',
                                    ),
                                    'targetToSourceKeyColumns' => array(
                                        'id' => 'position_id',
                                    ),
                                    'orphanRemoval' => false,
                                    'associationType' => 2,
                                    'property' => 'position',
                                ),
                            ),
                            'form_options' => array(

                            ),
                            'actions' => array(
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'btn btn-default action-delete',
                                    'icon' => 'trash-o',
                                ),
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'list' => array(
                            'fields' => array(
                                'username' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'username',
                                    'columnName' => 'username',
                                    'length' => 255,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'username',
                                ),
                                'usernameCanonical' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'usernameCanonical',
                                    'columnName' => 'username_canonical',
                                    'length' => 255,
                                    'unique' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'usernameCanonical',
                                ),
                                'email' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'email',
                                    'columnName' => 'email',
                                    'length' => 255,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'email',
                                ),
                                'emailCanonical' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'emailCanonical',
                                    'columnName' => 'email_canonical',
                                    'length' => 255,
                                    'unique' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'emailCanonical',
                                ),
                                'enabled' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'boolean',
                                    'fieldType' => 'checkbox',
                                    'dataType' => 'toggle',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_toggle.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'enabled',
                                    'columnName' => 'enabled',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'enabled',
                                ),
                                'lastLogin' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'lastLogin',
                                    'columnName' => 'last_login',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'lastLogin',
                                ),
                                'locked' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'boolean',
                                    'fieldType' => 'checkbox',
                                    'dataType' => 'toggle',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_toggle.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'locked',
                                    'columnName' => 'locked',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'locked',
                                ),
                            ),
                            'actions' => array(
                                'edit' => array(
                                    'name' => 'edit',
                                    'type' => 'method',
                                    'label' => 'action.edit',
                                    'css_class' => 'text-primary action-edit',
                                    'icon' => NULL,
                                ),
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'text-danger action-delete',
                                    'icon' => NULL,
                                ),
                                'new' => array(
                                    'name' => 'new',
                                    'type' => 'method',
                                    'label' => 'action.new',
                                    'css_class' => 'btn btn-primary action-new',
                                    'icon' => NULL,
                                ),
                                'search' => array(
                                    'name' => 'search',
                                    'type' => 'method',
                                    'label' => 'action.search',
                                    'css_class' => ' action-search',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'new' => array(
                            'fields' => array(
                                'username' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'username',
                                    'columnName' => 'username',
                                    'length' => 255,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'username',
                                ),
                                'usernameCanonical' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'usernameCanonical',
                                    'columnName' => 'username_canonical',
                                    'length' => 255,
                                    'unique' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'usernameCanonical',
                                ),
                                'email' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'email',
                                    'columnName' => 'email',
                                    'length' => 255,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'email',
                                ),
                                'emailCanonical' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'emailCanonical',
                                    'columnName' => 'email_canonical',
                                    'length' => 255,
                                    'unique' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'emailCanonical',
                                ),
                                'enabled' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'boolean',
                                    'fieldType' => 'checkbox',
                                    'dataType' => 'toggle',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'enabled',
                                    'columnName' => 'enabled',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'enabled',
                                ),
                                'salt' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'salt',
                                    'columnName' => 'salt',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'salt',
                                ),
                                'password' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'password',
                                    'columnName' => 'password',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'password',
                                ),
                                'lastLogin' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'lastLogin',
                                    'columnName' => 'last_login',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'lastLogin',
                                ),
                                'locked' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'boolean',
                                    'fieldType' => 'checkbox',
                                    'dataType' => 'toggle',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'locked',
                                    'columnName' => 'locked',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'locked',
                                ),
                                'expired' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'boolean',
                                    'fieldType' => 'checkbox',
                                    'dataType' => 'toggle',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'expired',
                                    'columnName' => 'expired',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'expired',
                                ),
                                'expiresAt' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'expiresAt',
                                    'columnName' => 'expires_at',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'expiresAt',
                                ),
                                'confirmationToken' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'confirmationToken',
                                    'columnName' => 'confirmation_token',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'confirmationToken',
                                ),
                                'passwordRequestedAt' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'passwordRequestedAt',
                                    'columnName' => 'password_requested_at',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'passwordRequestedAt',
                                ),
                                'roles' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'array',
                                    'fieldType' => 'collection',
                                    'dataType' => 'array',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'roles',
                                    'columnName' => 'roles',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'roles',
                                ),
                                'credentialsExpired' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'boolean',
                                    'fieldType' => 'checkbox',
                                    'dataType' => 'toggle',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'credentialsExpired',
                                    'columnName' => 'credentials_expired',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'credentialsExpired',
                                ),
                                'credentialsExpireAt' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'credentialsExpireAt',
                                    'columnName' => 'credentials_expire_at',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'credentialsExpireAt',
                                ),
                                'timerecords' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'timerecords',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Timerecord',
                                    'mappedBy' => 'users',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'timerecords',
                                ),
                                'payrolls' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'payrolls',
                                    'targetEntity' => 'EdgeWeb\\Project\\PaycomBundle\\Entity\\Payroll',
                                    'mappedBy' => 'users',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'payrolls',
                                ),
                                'position' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'position',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                    'inversedBy' => 'users',
                                    'joinColumns' => array(
                                        0 => array(
                                            'referencedColumnName' => 'id',
                                            'name' => 'position_id',
                                        ),
                                    ),
                                    'cascade' => array(

                                    ),
                                    'mappedBy' => NULL,
                                    'isOwningSide' => true,
                                    'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                    'fetch' => 2,
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'sourceToTargetKeyColumns' => array(
                                        'position_id' => 'id',
                                    ),
                                    'joinColumnFieldNames' => array(
                                        'position_id' => 'position_id',
                                    ),
                                    'targetToSourceKeyColumns' => array(
                                        'id' => 'position_id',
                                    ),
                                    'orphanRemoval' => false,
                                    'associationType' => 2,
                                    'property' => 'position',
                                ),
                            ),
                            'form_options' => array(

                            ),
                            'actions' => array(
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'search' => array(
                            'fields' => array(
                                'username' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'username',
                                    'columnName' => 'username',
                                    'length' => 255,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'username',
                                ),
                                'usernameCanonical' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'usernameCanonical',
                                    'columnName' => 'username_canonical',
                                    'length' => 255,
                                    'unique' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'usernameCanonical',
                                ),
                                'email' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'email',
                                    'columnName' => 'email',
                                    'length' => 255,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'email',
                                ),
                                'emailCanonical' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'emailCanonical',
                                    'columnName' => 'email_canonical',
                                    'length' => 255,
                                    'unique' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'emailCanonical',
                                ),
                                'confirmationToken' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'confirmationToken',
                                    'columnName' => 'confirmation_token',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'confirmationToken',
                                ),
                                'roles' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'array',
                                    'fieldType' => 'collection',
                                    'dataType' => 'array',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'roles',
                                    'columnName' => 'roles',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'roles',
                                ),
                                'id' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => 'ID',
                                    'type' => 'integer',
                                    'fieldType' => 'integer',
                                    'dataType' => 'integer',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'id' => true,
                                    'fieldName' => 'id',
                                    'columnName' => 'id',
                                    'property' => 'id',
                                ),
                            ),
                        ),
                        'show' => array(
                            'fields' => array(
                                'username' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'username',
                                    'columnName' => 'username',
                                    'length' => 255,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'username',
                                ),
                                'usernameCanonical' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'usernameCanonical',
                                    'columnName' => 'username_canonical',
                                    'length' => 255,
                                    'unique' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'usernameCanonical',
                                ),
                                'email' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'email',
                                    'columnName' => 'email',
                                    'length' => 255,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'email',
                                ),
                                'emailCanonical' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'emailCanonical',
                                    'columnName' => 'email_canonical',
                                    'length' => 255,
                                    'unique' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'emailCanonical',
                                ),
                                'enabled' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'boolean',
                                    'fieldType' => 'checkbox',
                                    'dataType' => 'toggle',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_toggle.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'enabled',
                                    'columnName' => 'enabled',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'enabled',
                                ),
                                'salt' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'salt',
                                    'columnName' => 'salt',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'salt',
                                ),
                                'password' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'password',
                                    'columnName' => 'password',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'password',
                                ),
                                'lastLogin' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'lastLogin',
                                    'columnName' => 'last_login',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'lastLogin',
                                ),
                                'locked' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'boolean',
                                    'fieldType' => 'checkbox',
                                    'dataType' => 'toggle',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_toggle.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'locked',
                                    'columnName' => 'locked',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'locked',
                                ),
                                'expired' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'boolean',
                                    'fieldType' => 'checkbox',
                                    'dataType' => 'toggle',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_toggle.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'expired',
                                    'columnName' => 'expired',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'expired',
                                ),
                                'expiresAt' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'expiresAt',
                                    'columnName' => 'expires_at',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'expiresAt',
                                ),
                                'confirmationToken' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'confirmationToken',
                                    'columnName' => 'confirmation_token',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'confirmationToken',
                                ),
                                'passwordRequestedAt' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'passwordRequestedAt',
                                    'columnName' => 'password_requested_at',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'passwordRequestedAt',
                                ),
                                'roles' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'array',
                                    'fieldType' => 'collection',
                                    'dataType' => 'array',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_array.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'roles',
                                    'columnName' => 'roles',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'roles',
                                ),
                                'credentialsExpired' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'boolean',
                                    'fieldType' => 'checkbox',
                                    'dataType' => 'toggle',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_toggle.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'credentialsExpired',
                                    'columnName' => 'credentials_expired',
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'credentialsExpired',
                                ),
                                'credentialsExpireAt' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'credentialsExpireAt',
                                    'columnName' => 'credentials_expire_at',
                                    'nullable' => true,
                                    'declared' => 'FOS\\UserBundle\\Model\\User',
                                    'property' => 'credentialsExpireAt',
                                ),
                                'id' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => 'ID',
                                    'type' => 'integer',
                                    'fieldType' => 'integer',
                                    'dataType' => 'integer',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_id.html.twig',
                                    'type_options' => array(

                                    ),
                                    'id' => true,
                                    'fieldName' => 'id',
                                    'columnName' => 'id',
                                    'property' => 'id',
                                ),
                                'timerecords' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => '@EasyAdmin/default/field_association.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'timerecords',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Timerecord',
                                    'mappedBy' => 'users',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'timerecords',
                                ),
                                'payrolls' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => '@EasyAdmin/default/field_association.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'payrolls',
                                    'targetEntity' => 'EdgeWeb\\Project\\PaycomBundle\\Entity\\Payroll',
                                    'mappedBy' => 'users',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'payrolls',
                                ),
                                'position' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_association.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'position',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                    'inversedBy' => 'users',
                                    'joinColumns' => array(
                                        0 => array(
                                            'referencedColumnName' => 'id',
                                            'name' => 'position_id',
                                        ),
                                    ),
                                    'cascade' => array(

                                    ),
                                    'mappedBy' => NULL,
                                    'isOwningSide' => true,
                                    'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                    'fetch' => 2,
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'sourceToTargetKeyColumns' => array(
                                        'position_id' => 'id',
                                    ),
                                    'joinColumnFieldNames' => array(
                                        'position_id' => 'position_id',
                                    ),
                                    'targetToSourceKeyColumns' => array(
                                        'id' => 'position_id',
                                    ),
                                    'orphanRemoval' => false,
                                    'associationType' => 2,
                                    'property' => 'position',
                                ),
                            ),
                            'actions' => array(
                                'edit' => array(
                                    'name' => 'edit',
                                    'type' => 'method',
                                    'label' => 'action.edit',
                                    'css_class' => 'btn btn-primary action-edit',
                                    'icon' => 'edit',
                                ),
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'btn btn-default action-delete',
                                    'icon' => 'trash-o',
                                ),
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'disabled_actions' => array(

                        ),
                        'primary_key_field_name' => 'id',
                        'properties' => array(
                            'username' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'username',
                                'columnName' => 'username',
                                'length' => 255,
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'username',
                            ),
                            'usernameCanonical' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'usernameCanonical',
                                'columnName' => 'username_canonical',
                                'length' => 255,
                                'unique' => true,
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'usernameCanonical',
                            ),
                            'email' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'email',
                                'columnName' => 'email',
                                'length' => 255,
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'email',
                            ),
                            'emailCanonical' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'emailCanonical',
                                'columnName' => 'email_canonical',
                                'length' => 255,
                                'unique' => true,
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'emailCanonical',
                            ),
                            'enabled' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'boolean',
                                'fieldType' => 'checkbox',
                                'dataType' => 'toggle',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'enabled',
                                'columnName' => 'enabled',
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'enabled',
                            ),
                            'salt' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'salt',
                                'columnName' => 'salt',
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'salt',
                            ),
                            'password' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'password',
                                'columnName' => 'password',
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'password',
                            ),
                            'lastLogin' => array(
                                'css_class' => '',
                                'format' => 'F j, Y H:i',
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'datetime',
                                'fieldType' => 'datetime',
                                'dataType' => 'datetime',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'lastLogin',
                                'columnName' => 'last_login',
                                'nullable' => true,
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'lastLogin',
                            ),
                            'locked' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'boolean',
                                'fieldType' => 'checkbox',
                                'dataType' => 'toggle',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'locked',
                                'columnName' => 'locked',
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'locked',
                            ),
                            'expired' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'boolean',
                                'fieldType' => 'checkbox',
                                'dataType' => 'toggle',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'expired',
                                'columnName' => 'expired',
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'expired',
                            ),
                            'expiresAt' => array(
                                'css_class' => '',
                                'format' => 'F j, Y H:i',
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'datetime',
                                'fieldType' => 'datetime',
                                'dataType' => 'datetime',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'expiresAt',
                                'columnName' => 'expires_at',
                                'nullable' => true,
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'expiresAt',
                            ),
                            'confirmationToken' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'confirmationToken',
                                'columnName' => 'confirmation_token',
                                'nullable' => true,
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'confirmationToken',
                            ),
                            'passwordRequestedAt' => array(
                                'css_class' => '',
                                'format' => 'F j, Y H:i',
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'datetime',
                                'fieldType' => 'datetime',
                                'dataType' => 'datetime',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'passwordRequestedAt',
                                'columnName' => 'password_requested_at',
                                'nullable' => true,
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'passwordRequestedAt',
                            ),
                            'roles' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'array',
                                'fieldType' => 'collection',
                                'dataType' => 'array',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'roles',
                                'columnName' => 'roles',
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'roles',
                            ),
                            'credentialsExpired' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'boolean',
                                'fieldType' => 'checkbox',
                                'dataType' => 'toggle',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'credentialsExpired',
                                'columnName' => 'credentials_expired',
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'credentialsExpired',
                            ),
                            'credentialsExpireAt' => array(
                                'css_class' => '',
                                'format' => 'F j, Y H:i',
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'datetime',
                                'fieldType' => 'datetime',
                                'dataType' => 'datetime',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'credentialsExpireAt',
                                'columnName' => 'credentials_expire_at',
                                'nullable' => true,
                                'declared' => 'FOS\\UserBundle\\Model\\User',
                                'property' => 'credentialsExpireAt',
                            ),
                            'id' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'integer',
                                'fieldType' => 'integer',
                                'dataType' => 'integer',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'id' => true,
                                'fieldName' => 'id',
                                'columnName' => 'id',
                                'property' => 'id',
                            ),
                            'timerecords' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'association',
                                'fieldType' => 'entity',
                                'dataType' => 'association',
                                'virtual' => false,
                                'sortable' => false,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'timerecords',
                                'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Timerecord',
                                'mappedBy' => 'users',
                                'inversedBy' => NULL,
                                'isOwningSide' => false,
                                'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                'fetch' => 2,
                                'cascade' => array(

                                ),
                                'isCascadeRemove' => false,
                                'isCascadePersist' => false,
                                'isCascadeRefresh' => false,
                                'isCascadeMerge' => false,
                                'isCascadeDetach' => false,
                                'orphanRemoval' => false,
                                'associationType' => 4,
                                'property' => 'timerecords',
                            ),
                            'payrolls' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'association',
                                'fieldType' => 'entity',
                                'dataType' => 'association',
                                'virtual' => false,
                                'sortable' => false,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'payrolls',
                                'targetEntity' => 'EdgeWeb\\Project\\PaycomBundle\\Entity\\Payroll',
                                'mappedBy' => 'users',
                                'inversedBy' => NULL,
                                'isOwningSide' => false,
                                'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                'fetch' => 2,
                                'cascade' => array(

                                ),
                                'isCascadeRemove' => false,
                                'isCascadePersist' => false,
                                'isCascadeRefresh' => false,
                                'isCascadeMerge' => false,
                                'isCascadeDetach' => false,
                                'orphanRemoval' => false,
                                'associationType' => 4,
                                'property' => 'payrolls',
                            ),
                            'position' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'association',
                                'fieldType' => 'entity',
                                'dataType' => 'association',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'position',
                                'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                'inversedBy' => 'users',
                                'joinColumns' => array(
                                    0 => array(
                                        'referencedColumnName' => 'id',
                                        'name' => 'position_id',
                                    ),
                                ),
                                'cascade' => array(

                                ),
                                'mappedBy' => NULL,
                                'isOwningSide' => true,
                                'sourceEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                'fetch' => 2,
                                'isCascadeRemove' => false,
                                'isCascadePersist' => false,
                                'isCascadeRefresh' => false,
                                'isCascadeMerge' => false,
                                'isCascadeDetach' => false,
                                'sourceToTargetKeyColumns' => array(
                                    'position_id' => 'id',
                                ),
                                'joinColumnFieldNames' => array(
                                    'position_id' => 'position_id',
                                ),
                                'targetToSourceKeyColumns' => array(
                                    'id' => 'position_id',
                                ),
                                'orphanRemoval' => false,
                                'associationType' => 2,
                                'property' => 'position',
                            ),
                        ),
                        'templates' => array(
                            'layout' => '@EasyAdmin/default/layout.html.twig',
                            'menu' => '@EasyAdmin/default/menu.html.twig',
                            'edit' => '@EasyAdmin/default/edit.html.twig',
                            'list' => '@EasyAdmin/default/list.html.twig',
                            'new' => '@EasyAdmin/default/new.html.twig',
                            'show' => '@EasyAdmin/default/show.html.twig',
                            'exception' => '@EasyAdmin/default/exception.html.twig',
                            'flash_messages' => '@EasyAdmin/default/flash_messages.html.twig',
                            'paginator' => '@EasyAdmin/default/paginator.html.twig',
                            'field_array' => '@EasyAdmin/default/field_array.html.twig',
                            'field_association' => '@EasyAdmin/default/field_association.html.twig',
                            'field_bigint' => '@EasyAdmin/default/field_bigint.html.twig',
                            'field_boolean' => '@EasyAdmin/default/field_boolean.html.twig',
                            'field_date' => '@EasyAdmin/default/field_date.html.twig',
                            'field_datetime' => '@EasyAdmin/default/field_datetime.html.twig',
                            'field_datetimetz' => '@EasyAdmin/default/field_datetimetz.html.twig',
                            'field_decimal' => '@EasyAdmin/default/field_decimal.html.twig',
                            'field_float' => '@EasyAdmin/default/field_float.html.twig',
                            'field_guid' => '@EasyAdmin/default/field_guid.html.twig',
                            'field_id' => '@EasyAdmin/default/field_id.html.twig',
                            'field_image' => '@EasyAdmin/default/field_image.html.twig',
                            'field_json_array' => '@EasyAdmin/default/field_json_array.html.twig',
                            'field_integer' => '@EasyAdmin/default/field_integer.html.twig',
                            'field_object' => '@EasyAdmin/default/field_object.html.twig',
                            'field_raw' => '@EasyAdmin/default/field_raw.html.twig',
                            'field_simple_array' => '@EasyAdmin/default/field_simple_array.html.twig',
                            'field_smallint' => '@EasyAdmin/default/field_smallint.html.twig',
                            'field_string' => '@EasyAdmin/default/field_string.html.twig',
                            'field_text' => '@EasyAdmin/default/field_text.html.twig',
                            'field_time' => '@EasyAdmin/default/field_time.html.twig',
                            'field_toggle' => '@EasyAdmin/default/field_toggle.html.twig',
                            'label_empty' => '@EasyAdmin/default/label_empty.html.twig',
                            'label_inaccessible' => '@EasyAdmin/default/label_inaccessible.html.twig',
                            'label_null' => '@EasyAdmin/default/label_null.html.twig',
                            'label_undefined' => '@EasyAdmin/default/label_undefined.html.twig',
                        ),
                    ),
                    'Department' => array(
                        'class' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department',
                        'name' => 'Department',
                        'label' => 'Department',
                        'edit' => array(
                            'fields' => array(
                                'department' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'department',
                                    'length' => 255,
                                    'columnName' => 'department',
                                    'property' => 'department',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                                'positions' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'positions',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                    'mappedBy' => 'department',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'positions',
                                ),
                            ),
                            'form_options' => array(

                            ),
                            'actions' => array(
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'btn btn-default action-delete',
                                    'icon' => 'trash-o',
                                ),
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'list' => array(
                            'fields' => array(
                                'id' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => 'ID',
                                    'type' => 'integer',
                                    'fieldType' => 'integer',
                                    'dataType' => 'integer',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_id.html.twig',
                                    'type_options' => array(

                                    ),
                                    'id' => true,
                                    'fieldName' => 'id',
                                    'columnName' => 'id',
                                    'property' => 'id',
                                ),
                                'department' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'department',
                                    'length' => 255,
                                    'columnName' => 'department',
                                    'property' => 'department',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                            ),
                            'actions' => array(
                                'edit' => array(
                                    'name' => 'edit',
                                    'type' => 'method',
                                    'label' => 'action.edit',
                                    'css_class' => 'text-primary action-edit',
                                    'icon' => NULL,
                                ),
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'text-danger action-delete',
                                    'icon' => NULL,
                                ),
                                'new' => array(
                                    'name' => 'new',
                                    'type' => 'method',
                                    'label' => 'action.new',
                                    'css_class' => 'btn btn-primary action-new',
                                    'icon' => NULL,
                                ),
                                'search' => array(
                                    'name' => 'search',
                                    'type' => 'method',
                                    'label' => 'action.search',
                                    'css_class' => ' action-search',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'new' => array(
                            'fields' => array(
                                'department' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'department',
                                    'length' => 255,
                                    'columnName' => 'department',
                                    'property' => 'department',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                                'positions' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'positions',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                    'mappedBy' => 'department',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'positions',
                                ),
                            ),
                            'form_options' => array(

                            ),
                            'actions' => array(
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'search' => array(
                            'fields' => array(
                                'id' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => 'ID',
                                    'type' => 'integer',
                                    'fieldType' => 'integer',
                                    'dataType' => 'integer',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'id' => true,
                                    'fieldName' => 'id',
                                    'columnName' => 'id',
                                    'property' => 'id',
                                ),
                                'department' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'department',
                                    'length' => 255,
                                    'columnName' => 'department',
                                    'property' => 'department',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                            ),
                        ),
                        'show' => array(
                            'fields' => array(
                                'id' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => 'ID',
                                    'type' => 'integer',
                                    'fieldType' => 'integer',
                                    'dataType' => 'integer',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_id.html.twig',
                                    'type_options' => array(

                                    ),
                                    'id' => true,
                                    'fieldName' => 'id',
                                    'columnName' => 'id',
                                    'property' => 'id',
                                ),
                                'department' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'department',
                                    'length' => 255,
                                    'columnName' => 'department',
                                    'property' => 'department',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                                'positions' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => '@EasyAdmin/default/field_association.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'positions',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                    'mappedBy' => 'department',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'positions',
                                ),
                            ),
                            'actions' => array(
                                'edit' => array(
                                    'name' => 'edit',
                                    'type' => 'method',
                                    'label' => 'action.edit',
                                    'css_class' => 'btn btn-primary action-edit',
                                    'icon' => 'edit',
                                ),
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'btn btn-default action-delete',
                                    'icon' => 'trash-o',
                                ),
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'disabled_actions' => array(

                        ),
                        'primary_key_field_name' => 'id',
                        'properties' => array(
                            'id' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'integer',
                                'fieldType' => 'integer',
                                'dataType' => 'integer',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'id' => true,
                                'fieldName' => 'id',
                                'columnName' => 'id',
                                'property' => 'id',
                            ),
                            'department' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'department',
                                'length' => 255,
                                'columnName' => 'department',
                                'property' => 'department',
                            ),
                            'description' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'description',
                                'length' => 255,
                                'columnName' => 'description',
                                'property' => 'description',
                            ),
                            'createdby' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'createdby',
                                'length' => 255,
                                'nullable' => true,
                                'columnName' => 'createdby',
                                'property' => 'createdby',
                            ),
                            'updatedby' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'updatedby',
                                'length' => 255,
                                'nullable' => true,
                                'columnName' => 'updatedby',
                                'property' => 'updatedby',
                            ),
                            'dateupdated' => array(
                                'css_class' => '',
                                'format' => 'F j, Y H:i',
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'datetime',
                                'fieldType' => 'datetime',
                                'dataType' => 'datetime',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'dateupdated',
                                'nullable' => true,
                                'columnName' => 'dateupdated',
                                'property' => 'dateupdated',
                            ),
                            'datecreated' => array(
                                'css_class' => '',
                                'format' => 'F j, Y H:i',
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'datetime',
                                'fieldType' => 'datetime',
                                'dataType' => 'datetime',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'datecreated',
                                'columnName' => 'datecreated',
                                'property' => 'datecreated',
                            ),
                            'positions' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'association',
                                'fieldType' => 'entity',
                                'dataType' => 'association',
                                'virtual' => false,
                                'sortable' => false,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'positions',
                                'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                'mappedBy' => 'department',
                                'inversedBy' => NULL,
                                'isOwningSide' => false,
                                'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department',
                                'fetch' => 2,
                                'cascade' => array(

                                ),
                                'isCascadeRemove' => false,
                                'isCascadePersist' => false,
                                'isCascadeRefresh' => false,
                                'isCascadeMerge' => false,
                                'isCascadeDetach' => false,
                                'orphanRemoval' => false,
                                'associationType' => 4,
                                'property' => 'positions',
                            ),
                        ),
                        'templates' => array(
                            'layout' => '@EasyAdmin/default/layout.html.twig',
                            'menu' => '@EasyAdmin/default/menu.html.twig',
                            'edit' => '@EasyAdmin/default/edit.html.twig',
                            'list' => '@EasyAdmin/default/list.html.twig',
                            'new' => '@EasyAdmin/default/new.html.twig',
                            'show' => '@EasyAdmin/default/show.html.twig',
                            'exception' => '@EasyAdmin/default/exception.html.twig',
                            'flash_messages' => '@EasyAdmin/default/flash_messages.html.twig',
                            'paginator' => '@EasyAdmin/default/paginator.html.twig',
                            'field_array' => '@EasyAdmin/default/field_array.html.twig',
                            'field_association' => '@EasyAdmin/default/field_association.html.twig',
                            'field_bigint' => '@EasyAdmin/default/field_bigint.html.twig',
                            'field_boolean' => '@EasyAdmin/default/field_boolean.html.twig',
                            'field_date' => '@EasyAdmin/default/field_date.html.twig',
                            'field_datetime' => '@EasyAdmin/default/field_datetime.html.twig',
                            'field_datetimetz' => '@EasyAdmin/default/field_datetimetz.html.twig',
                            'field_decimal' => '@EasyAdmin/default/field_decimal.html.twig',
                            'field_float' => '@EasyAdmin/default/field_float.html.twig',
                            'field_guid' => '@EasyAdmin/default/field_guid.html.twig',
                            'field_id' => '@EasyAdmin/default/field_id.html.twig',
                            'field_image' => '@EasyAdmin/default/field_image.html.twig',
                            'field_json_array' => '@EasyAdmin/default/field_json_array.html.twig',
                            'field_integer' => '@EasyAdmin/default/field_integer.html.twig',
                            'field_object' => '@EasyAdmin/default/field_object.html.twig',
                            'field_raw' => '@EasyAdmin/default/field_raw.html.twig',
                            'field_simple_array' => '@EasyAdmin/default/field_simple_array.html.twig',
                            'field_smallint' => '@EasyAdmin/default/field_smallint.html.twig',
                            'field_string' => '@EasyAdmin/default/field_string.html.twig',
                            'field_text' => '@EasyAdmin/default/field_text.html.twig',
                            'field_time' => '@EasyAdmin/default/field_time.html.twig',
                            'field_toggle' => '@EasyAdmin/default/field_toggle.html.twig',
                            'label_empty' => '@EasyAdmin/default/label_empty.html.twig',
                            'label_inaccessible' => '@EasyAdmin/default/label_inaccessible.html.twig',
                            'label_null' => '@EasyAdmin/default/label_null.html.twig',
                            'label_undefined' => '@EasyAdmin/default/label_undefined.html.twig',
                        ),
                    ),
                    'Position' => array(
                        'class' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                        'name' => 'Position',
                        'label' => 'Position',
                        'edit' => array(
                            'fields' => array(
                                'name' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'name',
                                    'length' => 255,
                                    'columnName' => 'name',
                                    'property' => 'name',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'nullable' => true,
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                                'users' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'users',
                                    'targetEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                    'mappedBy' => 'position',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'users',
                                ),
                                'department' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'department',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department',
                                    'inversedBy' => 'positions',
                                    'joinColumns' => array(
                                        0 => array(
                                            'referencedColumnName' => 'id',
                                            'name' => 'department_id',
                                        ),
                                    ),
                                    'cascade' => array(

                                    ),
                                    'mappedBy' => NULL,
                                    'isOwningSide' => true,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                    'fetch' => 2,
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'sourceToTargetKeyColumns' => array(
                                        'department_id' => 'id',
                                    ),
                                    'joinColumnFieldNames' => array(
                                        'department_id' => 'department_id',
                                    ),
                                    'targetToSourceKeyColumns' => array(
                                        'id' => 'department_id',
                                    ),
                                    'orphanRemoval' => false,
                                    'associationType' => 2,
                                    'property' => 'department',
                                ),
                            ),
                            'form_options' => array(

                            ),
                            'actions' => array(
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'btn btn-default action-delete',
                                    'icon' => 'trash-o',
                                ),
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'list' => array(
                            'fields' => array(
                                'id' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => 'ID',
                                    'type' => 'integer',
                                    'fieldType' => 'integer',
                                    'dataType' => 'integer',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_id.html.twig',
                                    'type_options' => array(

                                    ),
                                    'id' => true,
                                    'fieldName' => 'id',
                                    'columnName' => 'id',
                                    'property' => 'id',
                                ),
                                'name' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'name',
                                    'length' => 255,
                                    'columnName' => 'name',
                                    'property' => 'name',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'nullable' => true,
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                            ),
                            'actions' => array(
                                'edit' => array(
                                    'name' => 'edit',
                                    'type' => 'method',
                                    'label' => 'action.edit',
                                    'css_class' => 'text-primary action-edit',
                                    'icon' => NULL,
                                ),
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'text-danger action-delete',
                                    'icon' => NULL,
                                ),
                                'new' => array(
                                    'name' => 'new',
                                    'type' => 'method',
                                    'label' => 'action.new',
                                    'css_class' => 'btn btn-primary action-new',
                                    'icon' => NULL,
                                ),
                                'search' => array(
                                    'name' => 'search',
                                    'type' => 'method',
                                    'label' => 'action.search',
                                    'css_class' => ' action-search',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'new' => array(
                            'fields' => array(
                                'name' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'name',
                                    'length' => 255,
                                    'columnName' => 'name',
                                    'property' => 'name',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'nullable' => true,
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                                'users' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'users',
                                    'targetEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                    'mappedBy' => 'position',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'users',
                                ),
                                'department' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'department',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department',
                                    'inversedBy' => 'positions',
                                    'joinColumns' => array(
                                        0 => array(
                                            'referencedColumnName' => 'id',
                                            'name' => 'department_id',
                                        ),
                                    ),
                                    'cascade' => array(

                                    ),
                                    'mappedBy' => NULL,
                                    'isOwningSide' => true,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                    'fetch' => 2,
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'sourceToTargetKeyColumns' => array(
                                        'department_id' => 'id',
                                    ),
                                    'joinColumnFieldNames' => array(
                                        'department_id' => 'department_id',
                                    ),
                                    'targetToSourceKeyColumns' => array(
                                        'id' => 'department_id',
                                    ),
                                    'orphanRemoval' => false,
                                    'associationType' => 2,
                                    'property' => 'department',
                                ),
                            ),
                            'form_options' => array(

                            ),
                            'actions' => array(
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'search' => array(
                            'fields' => array(
                                'id' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => 'ID',
                                    'type' => 'integer',
                                    'fieldType' => 'integer',
                                    'dataType' => 'integer',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'id' => true,
                                    'fieldName' => 'id',
                                    'columnName' => 'id',
                                    'property' => 'id',
                                ),
                                'name' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'name',
                                    'length' => 255,
                                    'columnName' => 'name',
                                    'property' => 'name',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                            ),
                        ),
                        'show' => array(
                            'fields' => array(
                                'id' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => 'ID',
                                    'type' => 'integer',
                                    'fieldType' => 'integer',
                                    'dataType' => 'integer',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_id.html.twig',
                                    'type_options' => array(

                                    ),
                                    'id' => true,
                                    'fieldName' => 'id',
                                    'columnName' => 'id',
                                    'property' => 'id',
                                ),
                                'name' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'name',
                                    'length' => 255,
                                    'columnName' => 'name',
                                    'property' => 'name',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'nullable' => true,
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                                'users' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => '@EasyAdmin/default/field_association.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'users',
                                    'targetEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                    'mappedBy' => 'position',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'users',
                                ),
                                'department' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_association.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'department',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department',
                                    'inversedBy' => 'positions',
                                    'joinColumns' => array(
                                        0 => array(
                                            'referencedColumnName' => 'id',
                                            'name' => 'department_id',
                                        ),
                                    ),
                                    'cascade' => array(

                                    ),
                                    'mappedBy' => NULL,
                                    'isOwningSide' => true,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                    'fetch' => 2,
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'sourceToTargetKeyColumns' => array(
                                        'department_id' => 'id',
                                    ),
                                    'joinColumnFieldNames' => array(
                                        'department_id' => 'department_id',
                                    ),
                                    'targetToSourceKeyColumns' => array(
                                        'id' => 'department_id',
                                    ),
                                    'orphanRemoval' => false,
                                    'associationType' => 2,
                                    'property' => 'department',
                                ),
                            ),
                            'actions' => array(
                                'edit' => array(
                                    'name' => 'edit',
                                    'type' => 'method',
                                    'label' => 'action.edit',
                                    'css_class' => 'btn btn-primary action-edit',
                                    'icon' => 'edit',
                                ),
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'btn btn-default action-delete',
                                    'icon' => 'trash-o',
                                ),
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'disabled_actions' => array(

                        ),
                        'primary_key_field_name' => 'id',
                        'properties' => array(
                            'id' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'integer',
                                'fieldType' => 'integer',
                                'dataType' => 'integer',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'id' => true,
                                'fieldName' => 'id',
                                'columnName' => 'id',
                                'property' => 'id',
                            ),
                            'name' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'name',
                                'length' => 255,
                                'columnName' => 'name',
                                'property' => 'name',
                            ),
                            'description' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'description',
                                'length' => 255,
                                'columnName' => 'description',
                                'property' => 'description',
                            ),
                            'createdby' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'createdby',
                                'length' => 255,
                                'nullable' => true,
                                'columnName' => 'createdby',
                                'property' => 'createdby',
                            ),
                            'updatedby' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'updatedby',
                                'length' => 255,
                                'nullable' => true,
                                'columnName' => 'updatedby',
                                'property' => 'updatedby',
                            ),
                            'datecreated' => array(
                                'css_class' => '',
                                'format' => 'F j, Y H:i',
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'datetime',
                                'fieldType' => 'datetime',
                                'dataType' => 'datetime',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'datecreated',
                                'nullable' => true,
                                'columnName' => 'datecreated',
                                'property' => 'datecreated',
                            ),
                            'dateupdated' => array(
                                'css_class' => '',
                                'format' => 'F j, Y H:i',
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'datetime',
                                'fieldType' => 'datetime',
                                'dataType' => 'datetime',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'dateupdated',
                                'nullable' => true,
                                'columnName' => 'dateupdated',
                                'property' => 'dateupdated',
                            ),
                            'users' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'association',
                                'fieldType' => 'entity',
                                'dataType' => 'association',
                                'virtual' => false,
                                'sortable' => false,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'users',
                                'targetEntity' => 'EdgeWeb\\Project\\UserBundle\\Entity\\User',
                                'mappedBy' => 'position',
                                'inversedBy' => NULL,
                                'isOwningSide' => false,
                                'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                'fetch' => 2,
                                'cascade' => array(

                                ),
                                'isCascadeRemove' => false,
                                'isCascadePersist' => false,
                                'isCascadeRefresh' => false,
                                'isCascadeMerge' => false,
                                'isCascadeDetach' => false,
                                'orphanRemoval' => false,
                                'associationType' => 4,
                                'property' => 'users',
                            ),
                            'department' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'association',
                                'fieldType' => 'entity',
                                'dataType' => 'association',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'department',
                                'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Department',
                                'inversedBy' => 'positions',
                                'joinColumns' => array(
                                    0 => array(
                                        'referencedColumnName' => 'id',
                                        'name' => 'department_id',
                                    ),
                                ),
                                'cascade' => array(

                                ),
                                'mappedBy' => NULL,
                                'isOwningSide' => true,
                                'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Position',
                                'fetch' => 2,
                                'isCascadeRemove' => false,
                                'isCascadePersist' => false,
                                'isCascadeRefresh' => false,
                                'isCascadeMerge' => false,
                                'isCascadeDetach' => false,
                                'sourceToTargetKeyColumns' => array(
                                    'department_id' => 'id',
                                ),
                                'joinColumnFieldNames' => array(
                                    'department_id' => 'department_id',
                                ),
                                'targetToSourceKeyColumns' => array(
                                    'id' => 'department_id',
                                ),
                                'orphanRemoval' => false,
                                'associationType' => 2,
                                'property' => 'department',
                            ),
                        ),
                        'templates' => array(
                            'layout' => '@EasyAdmin/default/layout.html.twig',
                            'menu' => '@EasyAdmin/default/menu.html.twig',
                            'edit' => '@EasyAdmin/default/edit.html.twig',
                            'list' => '@EasyAdmin/default/list.html.twig',
                            'new' => '@EasyAdmin/default/new.html.twig',
                            'show' => '@EasyAdmin/default/show.html.twig',
                            'exception' => '@EasyAdmin/default/exception.html.twig',
                            'flash_messages' => '@EasyAdmin/default/flash_messages.html.twig',
                            'paginator' => '@EasyAdmin/default/paginator.html.twig',
                            'field_array' => '@EasyAdmin/default/field_array.html.twig',
                            'field_association' => '@EasyAdmin/default/field_association.html.twig',
                            'field_bigint' => '@EasyAdmin/default/field_bigint.html.twig',
                            'field_boolean' => '@EasyAdmin/default/field_boolean.html.twig',
                            'field_date' => '@EasyAdmin/default/field_date.html.twig',
                            'field_datetime' => '@EasyAdmin/default/field_datetime.html.twig',
                            'field_datetimetz' => '@EasyAdmin/default/field_datetimetz.html.twig',
                            'field_decimal' => '@EasyAdmin/default/field_decimal.html.twig',
                            'field_float' => '@EasyAdmin/default/field_float.html.twig',
                            'field_guid' => '@EasyAdmin/default/field_guid.html.twig',
                            'field_id' => '@EasyAdmin/default/field_id.html.twig',
                            'field_image' => '@EasyAdmin/default/field_image.html.twig',
                            'field_json_array' => '@EasyAdmin/default/field_json_array.html.twig',
                            'field_integer' => '@EasyAdmin/default/field_integer.html.twig',
                            'field_object' => '@EasyAdmin/default/field_object.html.twig',
                            'field_raw' => '@EasyAdmin/default/field_raw.html.twig',
                            'field_simple_array' => '@EasyAdmin/default/field_simple_array.html.twig',
                            'field_smallint' => '@EasyAdmin/default/field_smallint.html.twig',
                            'field_string' => '@EasyAdmin/default/field_string.html.twig',
                            'field_text' => '@EasyAdmin/default/field_text.html.twig',
                            'field_time' => '@EasyAdmin/default/field_time.html.twig',
                            'field_toggle' => '@EasyAdmin/default/field_toggle.html.twig',
                            'label_empty' => '@EasyAdmin/default/label_empty.html.twig',
                            'label_inaccessible' => '@EasyAdmin/default/label_inaccessible.html.twig',
                            'label_null' => '@EasyAdmin/default/label_null.html.twig',
                            'label_undefined' => '@EasyAdmin/default/label_undefined.html.twig',
                        ),
                    ),
                    'Comment' => array(
                        'class' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment',
                        'name' => 'Comment',
                        'label' => 'Comment',
                        'edit' => array(
                            'fields' => array(
                                'comment' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'comment',
                                    'length' => 255,
                                    'columnName' => 'comment',
                                    'property' => 'comment',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'nullable' => true,
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                                'task' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'task',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task',
                                    'inversedBy' => 'comments',
                                    'joinColumns' => array(
                                        0 => array(
                                            'referencedColumnName' => 'id',
                                            'name' => 'task_id',
                                        ),
                                    ),
                                    'cascade' => array(

                                    ),
                                    'mappedBy' => NULL,
                                    'isOwningSide' => true,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment',
                                    'fetch' => 2,
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'sourceToTargetKeyColumns' => array(
                                        'task_id' => 'id',
                                    ),
                                    'joinColumnFieldNames' => array(
                                        'task_id' => 'task_id',
                                    ),
                                    'targetToSourceKeyColumns' => array(
                                        'id' => 'task_id',
                                    ),
                                    'orphanRemoval' => false,
                                    'associationType' => 2,
                                    'property' => 'task',
                                ),
                            ),
                            'form_options' => array(

                            ),
                            'actions' => array(
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'btn btn-default action-delete',
                                    'icon' => 'trash-o',
                                ),
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'list' => array(
                            'fields' => array(
                                'id' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => 'ID',
                                    'type' => 'integer',
                                    'fieldType' => 'integer',
                                    'dataType' => 'integer',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_id.html.twig',
                                    'type_options' => array(

                                    ),
                                    'id' => true,
                                    'fieldName' => 'id',
                                    'columnName' => 'id',
                                    'property' => 'id',
                                ),
                                'comment' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'comment',
                                    'length' => 255,
                                    'columnName' => 'comment',
                                    'property' => 'comment',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'nullable' => true,
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                                'task' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_association.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'task',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task',
                                    'inversedBy' => 'comments',
                                    'joinColumns' => array(
                                        0 => array(
                                            'referencedColumnName' => 'id',
                                            'name' => 'task_id',
                                        ),
                                    ),
                                    'cascade' => array(

                                    ),
                                    'mappedBy' => NULL,
                                    'isOwningSide' => true,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment',
                                    'fetch' => 2,
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'sourceToTargetKeyColumns' => array(
                                        'task_id' => 'id',
                                    ),
                                    'joinColumnFieldNames' => array(
                                        'task_id' => 'task_id',
                                    ),
                                    'targetToSourceKeyColumns' => array(
                                        'id' => 'task_id',
                                    ),
                                    'orphanRemoval' => false,
                                    'associationType' => 2,
                                    'property' => 'task',
                                ),
                            ),
                            'actions' => array(
                                'edit' => array(
                                    'name' => 'edit',
                                    'type' => 'method',
                                    'label' => 'action.edit',
                                    'css_class' => 'text-primary action-edit',
                                    'icon' => NULL,
                                ),
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'text-danger action-delete',
                                    'icon' => NULL,
                                ),
                                'new' => array(
                                    'name' => 'new',
                                    'type' => 'method',
                                    'label' => 'action.new',
                                    'css_class' => 'btn btn-primary action-new',
                                    'icon' => NULL,
                                ),
                                'search' => array(
                                    'name' => 'search',
                                    'type' => 'method',
                                    'label' => 'action.search',
                                    'css_class' => ' action-search',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'new' => array(
                            'fields' => array(
                                'comment' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'comment',
                                    'length' => 255,
                                    'columnName' => 'comment',
                                    'property' => 'comment',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'nullable' => true,
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                                'task' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'task',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task',
                                    'inversedBy' => 'comments',
                                    'joinColumns' => array(
                                        0 => array(
                                            'referencedColumnName' => 'id',
                                            'name' => 'task_id',
                                        ),
                                    ),
                                    'cascade' => array(

                                    ),
                                    'mappedBy' => NULL,
                                    'isOwningSide' => true,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment',
                                    'fetch' => 2,
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'sourceToTargetKeyColumns' => array(
                                        'task_id' => 'id',
                                    ),
                                    'joinColumnFieldNames' => array(
                                        'task_id' => 'task_id',
                                    ),
                                    'targetToSourceKeyColumns' => array(
                                        'id' => 'task_id',
                                    ),
                                    'orphanRemoval' => false,
                                    'associationType' => 2,
                                    'property' => 'task',
                                ),
                            ),
                            'form_options' => array(

                            ),
                            'actions' => array(
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'search' => array(
                            'fields' => array(
                                'id' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => 'ID',
                                    'type' => 'integer',
                                    'fieldType' => 'integer',
                                    'dataType' => 'integer',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'id' => true,
                                    'fieldName' => 'id',
                                    'columnName' => 'id',
                                    'property' => 'id',
                                ),
                                'comment' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'comment',
                                    'length' => 255,
                                    'columnName' => 'comment',
                                    'property' => 'comment',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                            ),
                        ),
                        'show' => array(
                            'fields' => array(
                                'id' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => 'ID',
                                    'type' => 'integer',
                                    'fieldType' => 'integer',
                                    'dataType' => 'integer',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_id.html.twig',
                                    'type_options' => array(

                                    ),
                                    'id' => true,
                                    'fieldName' => 'id',
                                    'columnName' => 'id',
                                    'property' => 'id',
                                ),
                                'comment' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'comment',
                                    'length' => 255,
                                    'columnName' => 'comment',
                                    'property' => 'comment',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'nullable' => true,
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                                'task' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_association.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'task',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task',
                                    'inversedBy' => 'comments',
                                    'joinColumns' => array(
                                        0 => array(
                                            'referencedColumnName' => 'id',
                                            'name' => 'task_id',
                                        ),
                                    ),
                                    'cascade' => array(

                                    ),
                                    'mappedBy' => NULL,
                                    'isOwningSide' => true,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment',
                                    'fetch' => 2,
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'sourceToTargetKeyColumns' => array(
                                        'task_id' => 'id',
                                    ),
                                    'joinColumnFieldNames' => array(
                                        'task_id' => 'task_id',
                                    ),
                                    'targetToSourceKeyColumns' => array(
                                        'id' => 'task_id',
                                    ),
                                    'orphanRemoval' => false,
                                    'associationType' => 2,
                                    'property' => 'task',
                                ),
                            ),
                            'actions' => array(
                                'edit' => array(
                                    'name' => 'edit',
                                    'type' => 'method',
                                    'label' => 'action.edit',
                                    'css_class' => 'btn btn-primary action-edit',
                                    'icon' => 'edit',
                                ),
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'btn btn-default action-delete',
                                    'icon' => 'trash-o',
                                ),
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'disabled_actions' => array(

                        ),
                        'primary_key_field_name' => 'id',
                        'properties' => array(
                            'id' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'integer',
                                'fieldType' => 'integer',
                                'dataType' => 'integer',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'id' => true,
                                'fieldName' => 'id',
                                'columnName' => 'id',
                                'property' => 'id',
                            ),
                            'comment' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'comment',
                                'length' => 255,
                                'columnName' => 'comment',
                                'property' => 'comment',
                            ),
                            'createdby' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'createdby',
                                'length' => 255,
                                'nullable' => true,
                                'columnName' => 'createdby',
                                'property' => 'createdby',
                            ),
                            'updatedby' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'updatedby',
                                'length' => 255,
                                'nullable' => true,
                                'columnName' => 'updatedby',
                                'property' => 'updatedby',
                            ),
                            'datecreated' => array(
                                'css_class' => '',
                                'format' => 'F j, Y H:i',
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'datetime',
                                'fieldType' => 'datetime',
                                'dataType' => 'datetime',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'datecreated',
                                'nullable' => true,
                                'columnName' => 'datecreated',
                                'property' => 'datecreated',
                            ),
                            'dateupdated' => array(
                                'css_class' => '',
                                'format' => 'F j, Y H:i',
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'datetime',
                                'fieldType' => 'datetime',
                                'dataType' => 'datetime',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'dateupdated',
                                'nullable' => true,
                                'columnName' => 'dateupdated',
                                'property' => 'dateupdated',
                            ),
                            'task' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'association',
                                'fieldType' => 'entity',
                                'dataType' => 'association',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'task',
                                'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task',
                                'inversedBy' => 'comments',
                                'joinColumns' => array(
                                    0 => array(
                                        'referencedColumnName' => 'id',
                                        'name' => 'task_id',
                                    ),
                                ),
                                'cascade' => array(

                                ),
                                'mappedBy' => NULL,
                                'isOwningSide' => true,
                                'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment',
                                'fetch' => 2,
                                'isCascadeRemove' => false,
                                'isCascadePersist' => false,
                                'isCascadeRefresh' => false,
                                'isCascadeMerge' => false,
                                'isCascadeDetach' => false,
                                'sourceToTargetKeyColumns' => array(
                                    'task_id' => 'id',
                                ),
                                'joinColumnFieldNames' => array(
                                    'task_id' => 'task_id',
                                ),
                                'targetToSourceKeyColumns' => array(
                                    'id' => 'task_id',
                                ),
                                'orphanRemoval' => false,
                                'associationType' => 2,
                                'property' => 'task',
                            ),
                        ),
                        'templates' => array(
                            'layout' => '@EasyAdmin/default/layout.html.twig',
                            'menu' => '@EasyAdmin/default/menu.html.twig',
                            'edit' => '@EasyAdmin/default/edit.html.twig',
                            'list' => '@EasyAdmin/default/list.html.twig',
                            'new' => '@EasyAdmin/default/new.html.twig',
                            'show' => '@EasyAdmin/default/show.html.twig',
                            'exception' => '@EasyAdmin/default/exception.html.twig',
                            'flash_messages' => '@EasyAdmin/default/flash_messages.html.twig',
                            'paginator' => '@EasyAdmin/default/paginator.html.twig',
                            'field_array' => '@EasyAdmin/default/field_array.html.twig',
                            'field_association' => '@EasyAdmin/default/field_association.html.twig',
                            'field_bigint' => '@EasyAdmin/default/field_bigint.html.twig',
                            'field_boolean' => '@EasyAdmin/default/field_boolean.html.twig',
                            'field_date' => '@EasyAdmin/default/field_date.html.twig',
                            'field_datetime' => '@EasyAdmin/default/field_datetime.html.twig',
                            'field_datetimetz' => '@EasyAdmin/default/field_datetimetz.html.twig',
                            'field_decimal' => '@EasyAdmin/default/field_decimal.html.twig',
                            'field_float' => '@EasyAdmin/default/field_float.html.twig',
                            'field_guid' => '@EasyAdmin/default/field_guid.html.twig',
                            'field_id' => '@EasyAdmin/default/field_id.html.twig',
                            'field_image' => '@EasyAdmin/default/field_image.html.twig',
                            'field_json_array' => '@EasyAdmin/default/field_json_array.html.twig',
                            'field_integer' => '@EasyAdmin/default/field_integer.html.twig',
                            'field_object' => '@EasyAdmin/default/field_object.html.twig',
                            'field_raw' => '@EasyAdmin/default/field_raw.html.twig',
                            'field_simple_array' => '@EasyAdmin/default/field_simple_array.html.twig',
                            'field_smallint' => '@EasyAdmin/default/field_smallint.html.twig',
                            'field_string' => '@EasyAdmin/default/field_string.html.twig',
                            'field_text' => '@EasyAdmin/default/field_text.html.twig',
                            'field_time' => '@EasyAdmin/default/field_time.html.twig',
                            'field_toggle' => '@EasyAdmin/default/field_toggle.html.twig',
                            'label_empty' => '@EasyAdmin/default/label_empty.html.twig',
                            'label_inaccessible' => '@EasyAdmin/default/label_inaccessible.html.twig',
                            'label_null' => '@EasyAdmin/default/label_null.html.twig',
                            'label_undefined' => '@EasyAdmin/default/label_undefined.html.twig',
                        ),
                    ),
                    'Task' => array(
                        'class' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task',
                        'name' => 'Task',
                        'label' => 'Task',
                        'edit' => array(
                            'fields' => array(
                                'name' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'name',
                                    'length' => 255,
                                    'columnName' => 'name',
                                    'property' => 'name',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'start' => array(
                                    'css_class' => '',
                                    'format' => 'H:i:s',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'time',
                                    'fieldType' => 'time',
                                    'dataType' => 'time',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'start',
                                    'columnName' => 'start',
                                    'property' => 'start',
                                ),
                                'end' => array(
                                    'css_class' => '',
                                    'format' => 'H:i:s',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'time',
                                    'fieldType' => 'time',
                                    'dataType' => 'time',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'end',
                                    'columnName' => 'end',
                                    'property' => 'end',
                                ),
                                'path' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'path',
                                    'nullable' => true,
                                    'columnName' => 'path',
                                    'property' => 'path',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'nullable' => true,
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                                'comments' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'comments',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment',
                                    'mappedBy' => 'task',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'comments',
                                ),
                                'project' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'project',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Project',
                                    'inversedBy' => 'tasks',
                                    'joinColumns' => array(
                                        0 => array(
                                            'referencedColumnName' => 'id',
                                            'name' => 'project_id',
                                        ),
                                    ),
                                    'cascade' => array(

                                    ),
                                    'mappedBy' => NULL,
                                    'isOwningSide' => true,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task',
                                    'fetch' => 2,
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'sourceToTargetKeyColumns' => array(
                                        'project_id' => 'id',
                                    ),
                                    'joinColumnFieldNames' => array(
                                        'project_id' => 'project_id',
                                    ),
                                    'targetToSourceKeyColumns' => array(
                                        'id' => 'project_id',
                                    ),
                                    'orphanRemoval' => false,
                                    'associationType' => 2,
                                    'property' => 'project',
                                ),
                            ),
                            'form_options' => array(

                            ),
                            'actions' => array(
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'btn btn-default action-delete',
                                    'icon' => 'trash-o',
                                ),
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'list' => array(
                            'fields' => array(
                                'id' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => 'ID',
                                    'type' => 'integer',
                                    'fieldType' => 'integer',
                                    'dataType' => 'integer',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_id.html.twig',
                                    'type_options' => array(

                                    ),
                                    'id' => true,
                                    'fieldName' => 'id',
                                    'columnName' => 'id',
                                    'property' => 'id',
                                ),
                                'name' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'name',
                                    'length' => 255,
                                    'columnName' => 'name',
                                    'property' => 'name',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'start' => array(
                                    'css_class' => '',
                                    'format' => 'H:i:s',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'time',
                                    'fieldType' => 'time',
                                    'dataType' => 'time',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_time.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'start',
                                    'columnName' => 'start',
                                    'property' => 'start',
                                ),
                                'end' => array(
                                    'css_class' => '',
                                    'format' => 'H:i:s',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'time',
                                    'fieldType' => 'time',
                                    'dataType' => 'time',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_time.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'end',
                                    'columnName' => 'end',
                                    'property' => 'end',
                                ),
                                'path' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'path',
                                    'nullable' => true,
                                    'columnName' => 'path',
                                    'property' => 'path',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                            ),
                            'actions' => array(
                                'edit' => array(
                                    'name' => 'edit',
                                    'type' => 'method',
                                    'label' => 'action.edit',
                                    'css_class' => 'text-primary action-edit',
                                    'icon' => NULL,
                                ),
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'text-danger action-delete',
                                    'icon' => NULL,
                                ),
                                'new' => array(
                                    'name' => 'new',
                                    'type' => 'method',
                                    'label' => 'action.new',
                                    'css_class' => 'btn btn-primary action-new',
                                    'icon' => NULL,
                                ),
                                'search' => array(
                                    'name' => 'search',
                                    'type' => 'method',
                                    'label' => 'action.search',
                                    'css_class' => ' action-search',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'new' => array(
                            'fields' => array(
                                'name' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'name',
                                    'length' => 255,
                                    'columnName' => 'name',
                                    'property' => 'name',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'start' => array(
                                    'css_class' => '',
                                    'format' => 'H:i:s',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'time',
                                    'fieldType' => 'time',
                                    'dataType' => 'time',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'start',
                                    'columnName' => 'start',
                                    'property' => 'start',
                                ),
                                'end' => array(
                                    'css_class' => '',
                                    'format' => 'H:i:s',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'time',
                                    'fieldType' => 'time',
                                    'dataType' => 'time',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'end',
                                    'columnName' => 'end',
                                    'property' => 'end',
                                ),
                                'path' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'path',
                                    'nullable' => true,
                                    'columnName' => 'path',
                                    'property' => 'path',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'nullable' => true,
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                                'comments' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'comments',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment',
                                    'mappedBy' => 'task',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'comments',
                                ),
                                'project' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'project',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Project',
                                    'inversedBy' => 'tasks',
                                    'joinColumns' => array(
                                        0 => array(
                                            'referencedColumnName' => 'id',
                                            'name' => 'project_id',
                                        ),
                                    ),
                                    'cascade' => array(

                                    ),
                                    'mappedBy' => NULL,
                                    'isOwningSide' => true,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task',
                                    'fetch' => 2,
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'sourceToTargetKeyColumns' => array(
                                        'project_id' => 'id',
                                    ),
                                    'joinColumnFieldNames' => array(
                                        'project_id' => 'project_id',
                                    ),
                                    'targetToSourceKeyColumns' => array(
                                        'id' => 'project_id',
                                    ),
                                    'orphanRemoval' => false,
                                    'associationType' => 2,
                                    'property' => 'project',
                                ),
                            ),
                            'form_options' => array(

                            ),
                            'actions' => array(
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'search' => array(
                            'fields' => array(
                                'id' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => 'ID',
                                    'type' => 'integer',
                                    'fieldType' => 'integer',
                                    'dataType' => 'integer',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'id' => true,
                                    'fieldName' => 'id',
                                    'columnName' => 'id',
                                    'property' => 'id',
                                ),
                                'name' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'name',
                                    'length' => 255,
                                    'columnName' => 'name',
                                    'property' => 'name',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'path' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'path',
                                    'nullable' => true,
                                    'columnName' => 'path',
                                    'property' => 'path',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => NULL,
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                            ),
                        ),
                        'show' => array(
                            'fields' => array(
                                'id' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => 'ID',
                                    'type' => 'integer',
                                    'fieldType' => 'integer',
                                    'dataType' => 'integer',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_id.html.twig',
                                    'type_options' => array(

                                    ),
                                    'id' => true,
                                    'fieldName' => 'id',
                                    'columnName' => 'id',
                                    'property' => 'id',
                                ),
                                'name' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'name',
                                    'length' => 255,
                                    'columnName' => 'name',
                                    'property' => 'name',
                                ),
                                'description' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'description',
                                    'length' => 255,
                                    'columnName' => 'description',
                                    'property' => 'description',
                                ),
                                'start' => array(
                                    'css_class' => '',
                                    'format' => 'H:i:s',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'time',
                                    'fieldType' => 'time',
                                    'dataType' => 'time',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_time.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'start',
                                    'columnName' => 'start',
                                    'property' => 'start',
                                ),
                                'end' => array(
                                    'css_class' => '',
                                    'format' => 'H:i:s',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'time',
                                    'fieldType' => 'time',
                                    'dataType' => 'time',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_time.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'end',
                                    'columnName' => 'end',
                                    'property' => 'end',
                                ),
                                'path' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'path',
                                    'nullable' => true,
                                    'columnName' => 'path',
                                    'property' => 'path',
                                ),
                                'createdby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'createdby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'createdby',
                                    'property' => 'createdby',
                                ),
                                'updatedby' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'string',
                                    'fieldType' => 'text',
                                    'dataType' => 'string',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_string.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'updatedby',
                                    'length' => 255,
                                    'nullable' => true,
                                    'columnName' => 'updatedby',
                                    'property' => 'updatedby',
                                ),
                                'dateupdated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'dateupdated',
                                    'nullable' => true,
                                    'columnName' => 'dateupdated',
                                    'property' => 'dateupdated',
                                ),
                                'datecreated' => array(
                                    'css_class' => '',
                                    'format' => 'F j, Y H:i',
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'datetime',
                                    'fieldType' => 'datetime',
                                    'dataType' => 'datetime',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_datetime.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'datecreated',
                                    'nullable' => true,
                                    'columnName' => 'datecreated',
                                    'property' => 'datecreated',
                                ),
                                'comments' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => false,
                                    'template' => '@EasyAdmin/default/field_association.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'comments',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment',
                                    'mappedBy' => 'task',
                                    'inversedBy' => NULL,
                                    'isOwningSide' => false,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task',
                                    'fetch' => 2,
                                    'cascade' => array(

                                    ),
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'orphanRemoval' => false,
                                    'associationType' => 4,
                                    'property' => 'comments',
                                ),
                                'project' => array(
                                    'css_class' => '',
                                    'format' => NULL,
                                    'help' => NULL,
                                    'label' => NULL,
                                    'type' => 'association',
                                    'fieldType' => 'entity',
                                    'dataType' => 'association',
                                    'virtual' => false,
                                    'sortable' => true,
                                    'template' => '@EasyAdmin/default/field_association.html.twig',
                                    'type_options' => array(

                                    ),
                                    'fieldName' => 'project',
                                    'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Project',
                                    'inversedBy' => 'tasks',
                                    'joinColumns' => array(
                                        0 => array(
                                            'referencedColumnName' => 'id',
                                            'name' => 'project_id',
                                        ),
                                    ),
                                    'cascade' => array(

                                    ),
                                    'mappedBy' => NULL,
                                    'isOwningSide' => true,
                                    'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task',
                                    'fetch' => 2,
                                    'isCascadeRemove' => false,
                                    'isCascadePersist' => false,
                                    'isCascadeRefresh' => false,
                                    'isCascadeMerge' => false,
                                    'isCascadeDetach' => false,
                                    'sourceToTargetKeyColumns' => array(
                                        'project_id' => 'id',
                                    ),
                                    'joinColumnFieldNames' => array(
                                        'project_id' => 'project_id',
                                    ),
                                    'targetToSourceKeyColumns' => array(
                                        'id' => 'project_id',
                                    ),
                                    'orphanRemoval' => false,
                                    'associationType' => 2,
                                    'property' => 'project',
                                ),
                            ),
                            'actions' => array(
                                'edit' => array(
                                    'name' => 'edit',
                                    'type' => 'method',
                                    'label' => 'action.edit',
                                    'css_class' => 'btn btn-primary action-edit',
                                    'icon' => 'edit',
                                ),
                                'delete' => array(
                                    'name' => 'delete',
                                    'type' => 'method',
                                    'label' => 'action.delete',
                                    'css_class' => 'btn btn-default action-delete',
                                    'icon' => 'trash-o',
                                ),
                                'list' => array(
                                    'name' => 'list',
                                    'type' => 'method',
                                    'label' => 'action.list',
                                    'css_class' => 'btn btn-secondary action-list',
                                    'icon' => NULL,
                                ),
                            ),
                        ),
                        'disabled_actions' => array(

                        ),
                        'primary_key_field_name' => 'id',
                        'properties' => array(
                            'id' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'integer',
                                'fieldType' => 'integer',
                                'dataType' => 'integer',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'id' => true,
                                'fieldName' => 'id',
                                'columnName' => 'id',
                                'property' => 'id',
                            ),
                            'name' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'name',
                                'length' => 255,
                                'columnName' => 'name',
                                'property' => 'name',
                            ),
                            'description' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'description',
                                'length' => 255,
                                'columnName' => 'description',
                                'property' => 'description',
                            ),
                            'start' => array(
                                'css_class' => '',
                                'format' => 'H:i:s',
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'time',
                                'fieldType' => 'time',
                                'dataType' => 'time',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'start',
                                'columnName' => 'start',
                                'property' => 'start',
                            ),
                            'end' => array(
                                'css_class' => '',
                                'format' => 'H:i:s',
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'time',
                                'fieldType' => 'time',
                                'dataType' => 'time',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'end',
                                'columnName' => 'end',
                                'property' => 'end',
                            ),
                            'path' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'path',
                                'nullable' => true,
                                'columnName' => 'path',
                                'property' => 'path',
                            ),
                            'createdby' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'createdby',
                                'length' => 255,
                                'nullable' => true,
                                'columnName' => 'createdby',
                                'property' => 'createdby',
                            ),
                            'updatedby' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'string',
                                'fieldType' => 'text',
                                'dataType' => 'string',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'updatedby',
                                'length' => 255,
                                'nullable' => true,
                                'columnName' => 'updatedby',
                                'property' => 'updatedby',
                            ),
                            'dateupdated' => array(
                                'css_class' => '',
                                'format' => 'F j, Y H:i',
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'datetime',
                                'fieldType' => 'datetime',
                                'dataType' => 'datetime',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'dateupdated',
                                'nullable' => true,
                                'columnName' => 'dateupdated',
                                'property' => 'dateupdated',
                            ),
                            'datecreated' => array(
                                'css_class' => '',
                                'format' => 'F j, Y H:i',
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'datetime',
                                'fieldType' => 'datetime',
                                'dataType' => 'datetime',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'datecreated',
                                'nullable' => true,
                                'columnName' => 'datecreated',
                                'property' => 'datecreated',
                            ),
                            'comments' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'association',
                                'fieldType' => 'entity',
                                'dataType' => 'association',
                                'virtual' => false,
                                'sortable' => false,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'comments',
                                'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Comment',
                                'mappedBy' => 'task',
                                'inversedBy' => NULL,
                                'isOwningSide' => false,
                                'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task',
                                'fetch' => 2,
                                'cascade' => array(

                                ),
                                'isCascadeRemove' => false,
                                'isCascadePersist' => false,
                                'isCascadeRefresh' => false,
                                'isCascadeMerge' => false,
                                'isCascadeDetach' => false,
                                'orphanRemoval' => false,
                                'associationType' => 4,
                                'property' => 'comments',
                            ),
                            'project' => array(
                                'css_class' => '',
                                'format' => NULL,
                                'help' => NULL,
                                'label' => NULL,
                                'type' => 'association',
                                'fieldType' => 'entity',
                                'dataType' => 'association',
                                'virtual' => false,
                                'sortable' => true,
                                'template' => NULL,
                                'type_options' => array(

                                ),
                                'fieldName' => 'project',
                                'targetEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Project',
                                'inversedBy' => 'tasks',
                                'joinColumns' => array(
                                    0 => array(
                                        'referencedColumnName' => 'id',
                                        'name' => 'project_id',
                                    ),
                                ),
                                'cascade' => array(

                                ),
                                'mappedBy' => NULL,
                                'isOwningSide' => true,
                                'sourceEntity' => 'EdgeWeb\\Project\\EmployeeBundle\\Entity\\Task',
                                'fetch' => 2,
                                'isCascadeRemove' => false,
                                'isCascadePersist' => false,
                                'isCascadeRefresh' => false,
                                'isCascadeMerge' => false,
                                'isCascadeDetach' => false,
                                'sourceToTargetKeyColumns' => array(
                                    'project_id' => 'id',
                                ),
                                'joinColumnFieldNames' => array(
                                    'project_id' => 'project_id',
                                ),
                                'targetToSourceKeyColumns' => array(
                                    'id' => 'project_id',
                                ),
                                'orphanRemoval' => false,
                                'associationType' => 2,
                                'property' => 'project',
                            ),
                        ),
                        'templates' => array(
                            'layout' => '@EasyAdmin/default/layout.html.twig',
                            'menu' => '@EasyAdmin/default/menu.html.twig',
                            'edit' => '@EasyAdmin/default/edit.html.twig',
                            'list' => '@EasyAdmin/default/list.html.twig',
                            'new' => '@EasyAdmin/default/new.html.twig',
                            'show' => '@EasyAdmin/default/show.html.twig',
                            'exception' => '@EasyAdmin/default/exception.html.twig',
                            'flash_messages' => '@EasyAdmin/default/flash_messages.html.twig',
                            'paginator' => '@EasyAdmin/default/paginator.html.twig',
                            'field_array' => '@EasyAdmin/default/field_array.html.twig',
                            'field_association' => '@EasyAdmin/default/field_association.html.twig',
                            'field_bigint' => '@EasyAdmin/default/field_bigint.html.twig',
                            'field_boolean' => '@EasyAdmin/default/field_boolean.html.twig',
                            'field_date' => '@EasyAdmin/default/field_date.html.twig',
                            'field_datetime' => '@EasyAdmin/default/field_datetime.html.twig',
                            'field_datetimetz' => '@EasyAdmin/default/field_datetimetz.html.twig',
                            'field_decimal' => '@EasyAdmin/default/field_decimal.html.twig',
                            'field_float' => '@EasyAdmin/default/field_float.html.twig',
                            'field_guid' => '@EasyAdmin/default/field_guid.html.twig',
                            'field_id' => '@EasyAdmin/default/field_id.html.twig',
                            'field_image' => '@EasyAdmin/default/field_image.html.twig',
                            'field_json_array' => '@EasyAdmin/default/field_json_array.html.twig',
                            'field_integer' => '@EasyAdmin/default/field_integer.html.twig',
                            'field_object' => '@EasyAdmin/default/field_object.html.twig',
                            'field_raw' => '@EasyAdmin/default/field_raw.html.twig',
                            'field_simple_array' => '@EasyAdmin/default/field_simple_array.html.twig',
                            'field_smallint' => '@EasyAdmin/default/field_smallint.html.twig',
                            'field_string' => '@EasyAdmin/default/field_string.html.twig',
                            'field_text' => '@EasyAdmin/default/field_text.html.twig',
                            'field_time' => '@EasyAdmin/default/field_time.html.twig',
                            'field_toggle' => '@EasyAdmin/default/field_toggle.html.twig',
                            'label_empty' => '@EasyAdmin/default/label_empty.html.twig',
                            'label_inaccessible' => '@EasyAdmin/default/label_inaccessible.html.twig',
                            'label_null' => '@EasyAdmin/default/label_null.html.twig',
                            'label_undefined' => '@EasyAdmin/default/label_undefined.html.twig',
                        ),
                    ),
                ),
                'site_name' => 'EdgeWebMedia',
                'design' => array(
                    'assets' => array(
                        'css' => array(

                        ),
                        'js' => array(

                        ),
                        'favicon' => array(
                            'path' => 'favicon.ico',
                            'mime_type' => 'image/x-icon',
                        ),
                    ),
                    'theme' => 'default',
                    'color_scheme' => 'dark',
                    'brand_color' => '#205081',
                    'form_theme' => array(
                        0 => '@EasyAdmin/form/bootstrap_3_horizontal_layout.html.twig',
                    ),
                    'menu' => array(
                        0 => array(
                            'entity' => 'User',
                            'label' => 'User',
                            'icon' => 'fa-chevron-circle-right',
                            'children' => array(

                            ),
                            'default' => false,
                            'target' => false,
                            'menu_index' => 0,
                            'submenu_index' => -1,
                            'type' => 'entity',
                            'params' => array(

                            ),
                        ),
                        1 => array(
                            'entity' => 'Department',
                            'label' => 'Department',
                            'icon' => 'fa-chevron-circle-right',
                            'children' => array(

                            ),
                            'default' => false,
                            'target' => false,
                            'menu_index' => 1,
                            'submenu_index' => -1,
                            'type' => 'entity',
                            'params' => array(

                            ),
                        ),
                        2 => array(
                            'entity' => 'Position',
                            'label' => 'Position',
                            'icon' => 'fa-chevron-circle-right',
                            'children' => array(

                            ),
                            'default' => false,
                            'target' => false,
                            'menu_index' => 2,
                            'submenu_index' => -1,
                            'type' => 'entity',
                            'params' => array(

                            ),
                        ),
                        3 => array(
                            'entity' => 'Comment',
                            'label' => 'Comment',
                            'icon' => 'fa-chevron-circle-right',
                            'children' => array(

                            ),
                            'default' => false,
                            'target' => false,
                            'menu_index' => 3,
                            'submenu_index' => -1,
                            'type' => 'entity',
                            'params' => array(

                            ),
                        ),
                        4 => array(
                            'entity' => 'Task',
                            'label' => 'Task',
                            'icon' => 'fa-chevron-circle-right',
                            'children' => array(

                            ),
                            'default' => false,
                            'target' => false,
                            'menu_index' => 4,
                            'submenu_index' => -1,
                            'type' => 'entity',
                            'params' => array(

                            ),
                        ),
                    ),
                    'templates' => array(
                        'layout' => '@EasyAdmin/default/layout.html.twig',
                        'menu' => '@EasyAdmin/default/menu.html.twig',
                        'edit' => '@EasyAdmin/default/edit.html.twig',
                        'list' => '@EasyAdmin/default/list.html.twig',
                        'new' => '@EasyAdmin/default/new.html.twig',
                        'show' => '@EasyAdmin/default/show.html.twig',
                        'exception' => '@EasyAdmin/default/exception.html.twig',
                        'flash_messages' => '@EasyAdmin/default/flash_messages.html.twig',
                        'paginator' => '@EasyAdmin/default/paginator.html.twig',
                        'field_array' => '@EasyAdmin/default/field_array.html.twig',
                        'field_association' => '@EasyAdmin/default/field_association.html.twig',
                        'field_bigint' => '@EasyAdmin/default/field_bigint.html.twig',
                        'field_boolean' => '@EasyAdmin/default/field_boolean.html.twig',
                        'field_date' => '@EasyAdmin/default/field_date.html.twig',
                        'field_datetime' => '@EasyAdmin/default/field_datetime.html.twig',
                        'field_datetimetz' => '@EasyAdmin/default/field_datetimetz.html.twig',
                        'field_decimal' => '@EasyAdmin/default/field_decimal.html.twig',
                        'field_float' => '@EasyAdmin/default/field_float.html.twig',
                        'field_guid' => '@EasyAdmin/default/field_guid.html.twig',
                        'field_id' => '@EasyAdmin/default/field_id.html.twig',
                        'field_image' => '@EasyAdmin/default/field_image.html.twig',
                        'field_json_array' => '@EasyAdmin/default/field_json_array.html.twig',
                        'field_integer' => '@EasyAdmin/default/field_integer.html.twig',
                        'field_object' => '@EasyAdmin/default/field_object.html.twig',
                        'field_raw' => '@EasyAdmin/default/field_raw.html.twig',
                        'field_simple_array' => '@EasyAdmin/default/field_simple_array.html.twig',
                        'field_smallint' => '@EasyAdmin/default/field_smallint.html.twig',
                        'field_string' => '@EasyAdmin/default/field_string.html.twig',
                        'field_text' => '@EasyAdmin/default/field_text.html.twig',
                        'field_time' => '@EasyAdmin/default/field_time.html.twig',
                        'field_toggle' => '@EasyAdmin/default/field_toggle.html.twig',
                        'label_empty' => '@EasyAdmin/default/label_empty.html.twig',
                        'label_inaccessible' => '@EasyAdmin/default/label_inaccessible.html.twig',
                        'label_null' => '@EasyAdmin/default/label_null.html.twig',
                        'label_undefined' => '@EasyAdmin/default/label_undefined.html.twig',
                    ),
                ),
                'formats' => array(
                    'date' => 'Y-m-d',
                    'time' => 'H:i:s',
                    'datetime' => 'F j, Y H:i',
                ),
                'disabled_actions' => array(

                ),
                'list' => array(
                    'actions' => array(

                    ),
                    'max_results' => 15,
                ),
                'edit' => array(
                    'actions' => array(

                    ),
                ),
                'new' => array(
                    'actions' => array(

                    ),
                ),
                'show' => array(
                    'actions' => array(

                    ),
                ),
                'default_entity_name' => 'User',
                'default_menu_item' => NULL,
                'homepage' => array(
                    'route' => 'easyadmin',
                    'params' => array(
                        'action' => 'list',
                        'entity' => 'User',
                    ),
                ),
            ),
            'knp.doctrine_behaviors.reflection.class_analyzer.class' => 'Knp\\DoctrineBehaviors\\Reflection\\ClassAnalyzer',
            'knp.doctrine_behaviors.reflection.is_recursive' => true,
            'knp.doctrine_behaviors.translatable_subscriber.class' => 'Knp\\DoctrineBehaviors\\ORM\\Translatable\\TranslatableSubscriber',
            'knp.doctrine_behaviors.translatable_subscriber.current_locale_callable.class' => 'Knp\\DoctrineBehaviors\\ORM\\Translatable\\CurrentLocaleCallable',
            'knp.doctrine_behaviors.translatable_subscriber.default_locale_callable.class' => 'Knp\\DoctrineBehaviors\\ORM\\Translatable\\DefaultLocaleCallable',
            'knp.doctrine_behaviors.translatable_subscriber.translatable_trait' => 'Knp\\DoctrineBehaviors\\Model\\Translatable\\Translatable',
            'knp.doctrine_behaviors.translatable_subscriber.translation_trait' => 'Knp\\DoctrineBehaviors\\Model\\Translatable\\Translation',
            'knp.doctrine_behaviors.translatable_subscriber.translatable_fetch_method' => 'LAZY',
            'knp.doctrine_behaviors.translatable_subscriber.translation_fetch_method' => 'LAZY',
            'knp.doctrine_behaviors.softdeletable_subscriber.class' => 'Knp\\DoctrineBehaviors\\ORM\\SoftDeletable\\SoftDeletableSubscriber',
            'knp.doctrine_behaviors.softdeletable_subscriber.softdeletable_trait' => 'Knp\\DoctrineBehaviors\\Model\\SoftDeletable\\SoftDeletable',
            'knp.doctrine_behaviors.timestampable_subscriber.class' => 'Knp\\DoctrineBehaviors\\ORM\\Timestampable\\TimestampableSubscriber',
            'knp.doctrine_behaviors.timestampable_subscriber.timestampable_trait' => 'Knp\\DoctrineBehaviors\\Model\\Timestampable\\Timestampable',
            'knp.doctrine_behaviors.timestampable_subscriber.db_field_type' => 'datetime',
            'knp.doctrine_behaviors.blameable_subscriber.class' => 'Knp\\DoctrineBehaviors\\ORM\\Blameable\\BlameableSubscriber',
            'knp.doctrine_behaviors.blameable_subscriber.blameable_trait' => 'Knp\\DoctrineBehaviors\\Model\\Blameable\\Blameable',
            'knp.doctrine_behaviors.blameable_subscriber.user_callable.class' => 'Knp\\DoctrineBehaviors\\ORM\\Blameable\\UserCallable',
            'knp.doctrine_behaviors.blameable_subscriber.user_entity' => NULL,
            'knp.doctrine_behaviors.loggable_subscriber.class' => 'Knp\\DoctrineBehaviors\\ORM\\Loggable\\LoggableSubscriber',
            'knp.doctrine_behaviors.loggable_subscriber.logger_callable.class' => 'Knp\\DoctrineBehaviors\\ORM\\Loggable\\LoggerCallable',
            'knp.doctrine_behaviors.geocodable_subscriber.class' => 'Knp\\DoctrineBehaviors\\ORM\\Geocodable\\GeocodableSubscriber',
            'knp.doctrine_behaviors.geocodable_subscriber.geocodable_trait' => 'Knp\\DoctrineBehaviors\\Model\\Geocodable\\Geocodable',
            'knp.doctrine_behaviors.sluggable_subscriber.class' => 'Knp\\DoctrineBehaviors\\ORM\\Sluggable\\SluggableSubscriber',
            'knp.doctrine_behaviors.sluggable_subscriber.sluggable_trait' => 'Knp\\DoctrineBehaviors\\Model\\Sluggable\\Sluggable',
            'knp.doctrine_behaviors.tree_subscriber.class' => 'Knp\\DoctrineBehaviors\\ORM\\Tree\\TreeSubscriber',
            'knp.doctrine_behaviors.tree_subscriber.tree_trait' => 'Knp\\DoctrineBehaviors\\Model\\Tree\\Node',
            'knp.doctrine_behaviors.sortable_subscriber.class' => 'Knp\\DoctrineBehaviors\\ORM\\Sortable\\SortableSubscriber',
            'knp.doctrine_behaviors.sortable_subscriber.sortable_trait' => 'Knp\\DoctrineBehaviors\\Model\\Sortable\\Sortable',
            'sonata.core.flashmessage.manager.class' => 'Sonata\\CoreBundle\\FlashMessage\\FlashManager',
            'sonata.core.twig.extension.flashmessage.class' => 'Sonata\\CoreBundle\\Twig\\Extension\\FlashMessageExtension',
            'sonata.core.form_type' => 'standard',
            'sonata.block.service.container.class' => 'Sonata\\BlockBundle\\Block\\Service\\ContainerBlockService',
            'sonata.block.service.empty.class' => 'Sonata\\BlockBundle\\Block\\Service\\EmptyBlockService',
            'sonata.block.service.text.class' => 'Sonata\\BlockBundle\\Block\\Service\\TextBlockService',
            'sonata.block.service.rss.class' => 'Sonata\\BlockBundle\\Block\\Service\\RssBlockService',
            'sonata.block.service.menu.class' => 'Sonata\\BlockBundle\\Block\\Service\\MenuBlockService',
            'sonata.block.service.template.class' => 'Sonata\\BlockBundle\\Block\\Service\\TemplateBlockService',
            'sonata.block.exception.strategy.manager.class' => 'Sonata\\BlockBundle\\Exception\\Strategy\\StrategyManager',
            'sonata.block.container.types' => array(
                0 => 'sonata.block.service.container',
                1 => 'sonata.page.block.container',
                2 => 'cmf.block.container',
                3 => 'cmf.block.slideshow',
            ),
            'sonata_block.blocks' => array(
                'sonata.admin.block.admin_list' => array(
                    'contexts' => array(
                        0 => 'admin',
                    ),
                    'cache' => 'sonata.cache.noop',
                    'settings' => array(

                    ),
                ),
            ),
            'sonata_block.blocks_by_class' => array(

            ),
            'sonata_block.cache_blocks' => array(
                'by_type' => array(
                    'sonata.admin.block.admin_list' => 'sonata.cache.noop',
                ),
            ),
            'knp_menu.factory.class' => 'Knp\\Menu\\MenuFactory',
            'knp_menu.factory_extension.routing.class' => 'Knp\\Menu\\Integration\\Symfony\\RoutingExtension',
            'knp_menu.helper.class' => 'Knp\\Menu\\Twig\\Helper',
            'knp_menu.matcher.class' => 'Knp\\Menu\\Matcher\\Matcher',
            'knp_menu.menu_provider.chain.class' => 'Knp\\Menu\\Provider\\ChainProvider',
            'knp_menu.menu_provider.container_aware.class' => 'Knp\\Bundle\\MenuBundle\\Provider\\ContainerAwareProvider',
            'knp_menu.menu_provider.builder_alias.class' => 'Knp\\Bundle\\MenuBundle\\Provider\\BuilderAliasProvider',
            'knp_menu.renderer_provider.class' => 'Knp\\Bundle\\MenuBundle\\Renderer\\ContainerAwareProvider',
            'knp_menu.renderer.list.class' => 'Knp\\Menu\\Renderer\\ListRenderer',
            'knp_menu.renderer.list.options' => array(

            ),
            'knp_menu.listener.voters.class' => 'Knp\\Bundle\\MenuBundle\\EventListener\\VoterInitializerListener',
            'knp_menu.voter.router.class' => 'Knp\\Menu\\Matcher\\Voter\\RouteVoter',
            'knp_menu.twig.extension.class' => 'Knp\\Menu\\Twig\\MenuExtension',
            'knp_menu.renderer.twig.class' => 'Knp\\Menu\\Renderer\\TwigRenderer',
            'knp_menu.renderer.twig.options' => array(

            ),
            'knp_menu.renderer.twig.template' => 'knp_menu.html.twig',
            'knp_menu.default_renderer' => 'twig',
            'sonata.admin.manipulator.acl.object.orm.class' => 'Sonata\\DoctrineORMAdminBundle\\Util\\ObjectAclManipulator',
            'sonata_doctrine_orm_admin.entity_manager' => NULL,
            'sonata_doctrine_orm_admin.templates' => array(
                'types' => array(
                    'list' => array(
                        'array' => 'SonataAdminBundle:CRUD:list_array.html.twig',
                        'boolean' => 'SonataAdminBundle:CRUD:list_boolean.html.twig',
                        'date' => 'SonataAdminBundle:CRUD:list_date.html.twig',
                        'time' => 'SonataAdminBundle:CRUD:list_time.html.twig',
                        'datetime' => 'SonataAdminBundle:CRUD:list_datetime.html.twig',
                        'text' => 'SonataAdminBundle:CRUD:list_string.html.twig',
                        'textarea' => 'SonataAdminBundle:CRUD:list_string.html.twig',
                        'email' => 'SonataAdminBundle:CRUD:list_string.html.twig',
                        'trans' => 'SonataAdminBundle:CRUD:list_trans.html.twig',
                        'string' => 'SonataAdminBundle:CRUD:list_string.html.twig',
                        'smallint' => 'SonataAdminBundle:CRUD:list_string.html.twig',
                        'bigint' => 'SonataAdminBundle:CRUD:list_string.html.twig',
                        'integer' => 'SonataAdminBundle:CRUD:list_string.html.twig',
                        'decimal' => 'SonataAdminBundle:CRUD:list_string.html.twig',
                        'identifier' => 'SonataAdminBundle:CRUD:list_string.html.twig',
                        'currency' => 'SonataAdminBundle:CRUD:list_currency.html.twig',
                        'percent' => 'SonataAdminBundle:CRUD:list_percent.html.twig',
                        'choice' => 'SonataAdminBundle:CRUD:list_choice.html.twig',
                        'url' => 'SonataAdminBundle:CRUD:list_url.html.twig',
                        'html' => 'SonataAdminBundle:CRUD:list_html.html.twig',
                    ),
                    'show' => array(
                        'array' => 'SonataAdminBundle:CRUD:show_array.html.twig',
                        'boolean' => 'SonataAdminBundle:CRUD:show_boolean.html.twig',
                        'date' => 'SonataAdminBundle:CRUD:show_date.html.twig',
                        'time' => 'SonataAdminBundle:CRUD:show_time.html.twig',
                        'datetime' => 'SonataAdminBundle:CRUD:show_datetime.html.twig',
                        'text' => 'SonataAdminBundle:CRUD:base_show_field.html.twig',
                        'trans' => 'SonataAdminBundle:CRUD:show_trans.html.twig',
                        'string' => 'SonataAdminBundle:CRUD:base_show_field.html.twig',
                        'smallint' => 'SonataAdminBundle:CRUD:base_show_field.html.twig',
                        'bigint' => 'SonataAdminBundle:CRUD:base_show_field.html.twig',
                        'integer' => 'SonataAdminBundle:CRUD:base_show_field.html.twig',
                        'decimal' => 'SonataAdminBundle:CRUD:base_show_field.html.twig',
                        'currency' => 'SonataAdminBundle:CRUD:show_currency.html.twig',
                        'percent' => 'SonataAdminBundle:CRUD:show_percent.html.twig',
                        'choice' => 'SonataAdminBundle:CRUD:show_choice.html.twig',
                        'url' => 'SonataAdminBundle:CRUD:show_url.html.twig',
                        'html' => 'SonataAdminBundle:CRUD:show_html.html.twig',
                    ),
                ),
                'form' => array(
                    0 => 'SonataDoctrineORMAdminBundle:Form:form_admin_fields.html.twig',
                ),
                'filter' => array(
                    0 => 'SonataDoctrineORMAdminBundle:Form:filter_admin_fields.html.twig',
                ),
            ),
            'sonata.admin.configuration.templates' => array(
                'search' => 'SonataAdminBundle:Core:search.html.twig',
                'search_result_block' => 'SonataAdminBundle:Block:block_search_result.html.twig',
                'user_block' => 'SonataAdminBundle:Core:user_block.html.twig',
                'add_block' => 'SonataAdminBundle:Core:add_block.html.twig',
                'layout' => 'SonataAdminBundle::standard_layout.html.twig',
                'ajax' => 'SonataAdminBundle::ajax_layout.html.twig',
                'dashboard' => 'SonataAdminBundle:Core:dashboard.html.twig',
                'list' => 'SonataAdminBundle:CRUD:list.html.twig',
                'filter' => 'SonataAdminBundle:Form:filter_admin_fields.html.twig',
                'show' => 'SonataAdminBundle:CRUD:show.html.twig',
                'show_compare' => 'SonataAdminBundle:CRUD:show_compare.html.twig',
                'edit' => 'SonataAdminBundle:CRUD:edit.html.twig',
                'preview' => 'SonataAdminBundle:CRUD:preview.html.twig',
                'history' => 'SonataAdminBundle:CRUD:history.html.twig',
                'acl' => 'SonataAdminBundle:CRUD:acl.html.twig',
                'history_revision_timestamp' => 'SonataAdminBundle:CRUD:history_revision_timestamp.html.twig',
                'action' => 'SonataAdminBundle:CRUD:action.html.twig',
                'select' => 'SonataAdminBundle:CRUD:list__select.html.twig',
                'list_block' => 'SonataAdminBundle:Block:block_admin_list.html.twig',
                'short_object_description' => 'SonataAdminBundle:Helper:short-object-description.html.twig',
                'delete' => 'SonataAdminBundle:CRUD:delete.html.twig',
                'batch' => 'SonataAdminBundle:CRUD:list__batch.html.twig',
                'batch_confirmation' => 'SonataAdminBundle:CRUD:batch_confirmation.html.twig',
                'inner_list_row' => 'SonataAdminBundle:CRUD:list_inner_row.html.twig',
                'base_list_field' => 'SonataAdminBundle:CRUD:base_list_field.html.twig',
                'pager_links' => 'SonataAdminBundle:Pager:links.html.twig',
                'pager_results' => 'SonataAdminBundle:Pager:results.html.twig',
                'tab_menu_template' => 'SonataAdminBundle:Core:tab_menu_template.html.twig',
            ),
            'sonata.admin.configuration.admin_services' => array(

            ),
            'sonata.admin.configuration.dashboard_groups' => array(

            ),
            'sonata.admin.configuration.dashboard_blocks' => array(
                0 => array(
                    'position' => 'left',
                    'settings' => array(

                    ),
                    'type' => 'sonata.admin.block.admin_list',
                ),
            ),
            'sonata.admin.security.acl_user_manager' => 'fos_user.user_manager',
            'sonata.admin.configuration.security.information' => array(

            ),
            'sonata.admin.configuration.security.admin_permissions' => array(
                0 => 'CREATE',
                1 => 'LIST',
                2 => 'DELETE',
                3 => 'UNDELETE',
                4 => 'EXPORT',
                5 => 'OPERATOR',
                6 => 'MASTER',
            ),
            'sonata.admin.configuration.security.object_permissions' => array(
                0 => 'VIEW',
                1 => 'EDIT',
                2 => 'DELETE',
                3 => 'UNDELETE',
                4 => 'OPERATOR',
                5 => 'MASTER',
                6 => 'OWNER',
            ),
            'sonata.admin.security.handler.noop.class' => 'Sonata\\AdminBundle\\Security\\Handler\\NoopSecurityHandler',
            'sonata.admin.security.handler.role.class' => 'Sonata\\AdminBundle\\Security\\Handler\\RoleSecurityHandler',
            'sonata.admin.security.handler.acl.class' => 'Sonata\\AdminBundle\\Security\\Handler\\AclSecurityHandler',
            'sonata.admin.security.mask.builder.class' => 'Sonata\\AdminBundle\\Security\\Acl\\Permission\\MaskBuilder',
            'sonata.admin.manipulator.acl.admin.class' => 'Sonata\\AdminBundle\\Util\\AdminAclManipulator',
            'sonata.admin.object.manipulator.acl.admin.class' => 'Sonata\\AdminBundle\\Util\\AdminObjectAclManipulator',
            'sonata.admin.extension.map' => array(
                'admins' => array(

                ),
                'excludes' => array(

                ),
                'implements' => array(

                ),
                'extends' => array(

                ),
                'instanceof' => array(

                ),
            ),
            'sonata.admin.configuration.filters.persist' => false,
            'knp_paginator.class' => 'Knp\\Component\\Pager\\Paginator',
            'knp_paginator.helper.processor.class' => 'Knp\\Bundle\\PaginatorBundle\\Helper\\Processor',
            'knp_paginator.template.pagination' => 'KnpPaginatorBundle:Pagination:twitter_bootstrap_v3_pagination.html.twig',
            'knp_paginator.template.filtration' => 'KnpPaginatorBundle:Pagination:filtration.html.twig',
            'knp_paginator.template.sortable' => 'KnpPaginatorBundle:Pagination:sortable_link.html.twig',
            'knp_paginator.page_range' => 5,
            'web_profiler.controller.profiler.class' => 'Symfony\\Bundle\\WebProfilerBundle\\Controller\\ProfilerController',
            'web_profiler.controller.router.class' => 'Symfony\\Bundle\\WebProfilerBundle\\Controller\\RouterController',
            'web_profiler.controller.exception.class' => 'Symfony\\Bundle\\WebProfilerBundle\\Controller\\ExceptionController',
            'twig.extension.webprofiler.class' => 'Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension',
            'web_profiler.debug_toolbar.position' => 'bottom',
            'web_profiler.debug_toolbar.class' => 'Symfony\\Bundle\\WebProfilerBundle\\EventListener\\WebDebugToolbarListener',
            'web_profiler.debug_toolbar.intercept_redirects' => false,
            'web_profiler.debug_toolbar.mode' => 2,
            'sensio_distribution.webconfigurator.class' => 'Sensio\\Bundle\\DistributionBundle\\Configurator\\Configurator',
            'sensio_distribution.webconfigurator.doctrine_step.class' => 'Sensio\\Bundle\\DistributionBundle\\Configurator\\Step\\DoctrineStep',
            'sensio_distribution.webconfigurator.secret_step.class' => 'Sensio\\Bundle\\DistributionBundle\\Configurator\\Step\\SecretStep',
            'sensio_distribution.security_checker.class' => 'SensioLabs\\Security\\SecurityChecker',
            'sensio_distribution.security_checker.command.class' => 'SensioLabs\\Security\\Command\\SecurityCheckerCommand',
            'data_collector.templates' => array(
                'data_collector.config' => array(
                    0 => 'config',
                    1 => '@WebProfiler/Collector/config.html.twig',
                ),
                'data_collector.request' => array(
                    0 => 'request',
                    1 => '@WebProfiler/Collector/request.html.twig',
                ),
                'data_collector.ajax' => array(
                    0 => 'ajax',
                    1 => '@WebProfiler/Collector/ajax.html.twig',
                ),
                'data_collector.exception' => array(
                    0 => 'exception',
                    1 => '@WebProfiler/Collector/exception.html.twig',
                ),
                'data_collector.events' => array(
                    0 => 'events',
                    1 => '@WebProfiler/Collector/events.html.twig',
                ),
                'data_collector.logger' => array(
                    0 => 'logger',
                    1 => '@WebProfiler/Collector/logger.html.twig',
                ),
                'data_collector.time' => array(
                    0 => 'time',
                    1 => '@WebProfiler/Collector/time.html.twig',
                ),
                'data_collector.memory' => array(
                    0 => 'memory',
                    1 => '@WebProfiler/Collector/memory.html.twig',
                ),
                'data_collector.router' => array(
                    0 => 'router',
                    1 => '@WebProfiler/Collector/router.html.twig',
                ),
                'data_collector.form' => array(
                    0 => 'form',
                    1 => '@WebProfiler/Collector/form.html.twig',
                ),
                'data_collector.translation' => array(
                    0 => 'translation',
                    1 => '@WebProfiler/Collector/translation.html.twig',
                ),
                'data_collector.twig' => array(
                    0 => 'twig',
                    1 => '@WebProfiler/Collector/twig.html.twig',
                ),
                'data_collector.doctrine' => array(
                    0 => 'db',
                    1 => '@Doctrine/Collector/db.html.twig',
                ),
                'swiftmailer.data_collector' => array(
                    0 => 'swiftmailer',
                    1 => '@Swiftmailer/Collector/swiftmailer.html.twig',
                ),
                'data_collector.security' => array(
                    0 => 'security',
                    1 => '@Security/Collector/security.html.twig',
                ),
                'easyadmin.data_collector' => array(
                    0 => 'easyadmin',
                    1 => '@EasyAdmin/data_collector/easyadmin.html.twig',
                ),
                'sonata.block.data_collector' => array(
                    0 => 'block',
                    1 => 'SonataBlockBundle:Profiler:block.html.twig',
                ),
                'data_collector.dump' => array(
                    0 => 'dump',
                    1 => '@Debug/Profiler/dump.html.twig',
                ),
            ),
            'console.command.ids' => array(
                0 => 'sensio_distribution.security_checker.command',
            ),
            'sonata.core.form.types' => array(
                0 => 'app.form.registration',
                1 => 'app.form.profile',
                2 => 'form.type.form',
                3 => 'form.type.birthday',
                4 => 'form.type.checkbox',
                5 => 'form.type.choice',
                6 => 'form.type.collection',
                7 => 'form.type.country',
                8 => 'form.type.date',
                9 => 'form.type.datetime',
                10 => 'form.type.email',
                11 => 'form.type.file',
                12 => 'form.type.hidden',
                13 => 'form.type.integer',
                14 => 'form.type.language',
                15 => 'form.type.locale',
                16 => 'form.type.money',
                17 => 'form.type.number',
                18 => 'form.type.password',
                19 => 'form.type.percent',
                20 => 'form.type.radio',
                21 => 'form.type.repeated',
                22 => 'form.type.search',
                23 => 'form.type.textarea',
                24 => 'form.type.text',
                25 => 'form.type.time',
                26 => 'form.type.timezone',
                27 => 'form.type.url',
                28 => 'form.type.button',
                29 => 'form.type.submit',
                30 => 'form.type.reset',
                31 => 'form.type.currency',
                32 => 'form.type.entity',
                33 => 'fos_user.username_form_type',
                34 => 'fos_user.profile.form.type',
                35 => 'fos_user.registration.form.type',
                36 => 'fos_user.change_password.form.type',
                37 => 'fos_user.resetting.form.type',
                38 => 'easyadmin.form.type',
                39 => 'sonata.core.form.type.array',
                40 => 'sonata.core.form.type.boolean',
                41 => 'sonata.core.form.type.collection',
                42 => 'sonata.core.form.type.translatable_choice',
                43 => 'sonata.core.form.type.date_range',
                44 => 'sonata.core.form.type.datetime_range',
                45 => 'sonata.core.form.type.date_picker',
                46 => 'sonata.core.form.type.datetime_picker',
                47 => 'sonata.core.form.type.date_range_picker',
                48 => 'sonata.core.form.type.datetime_range_picker',
                49 => 'sonata.core.form.type.equal',
                50 => 'sonata.core.form.type.color_selector',
                51 => 'sonata.block.form.type.block',
                52 => 'sonata.block.form.type.container_template',
                53 => 'sonata.admin.form.type.admin',
                54 => 'sonata.admin.form.type.model_choice',
                55 => 'sonata.admin.form.type.model_list',
                56 => 'sonata.admin.form.type.model_reference',
                57 => 'sonata.admin.form.type.model_hidden',
                58 => 'sonata.admin.form.type.model_autocomplete',
                59 => 'sonata.admin.form.type.collection',
                60 => 'sonata.admin.form.filter.type.number',
                61 => 'sonata.admin.form.filter.type.choice',
                62 => 'sonata.admin.form.filter.type.default',
                63 => 'sonata.admin.form.filter.type.date',
                64 => 'sonata.admin.form.filter.type.daterange',
                65 => 'sonata.admin.form.filter.type.datetime',
                66 => 'sonata.admin.form.filter.type.datetime_range',
            ),
            'sonata.core.form.type_extensions' => array(
                0 => 'form.type_extension.form.http_foundation',
                1 => 'form.type_extension.form.validator',
                2 => 'form.type_extension.repeated.validator',
                3 => 'form.type_extension.submit.validator',
                4 => 'form.type_extension.csrf',
                5 => 'form.type_extension.form.data_collector',
                6 => 'easyadmin.form.type.extension',
                7 => 'sonata.admin.form.extension.field',
                8 => 'sonata.admin.form.extension.field.mopa',
            ),
        );
    }
}
