<?php

namespace EdgeWeb\Project\EmployeeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EmployeeBundle extends Bundle
{
}
