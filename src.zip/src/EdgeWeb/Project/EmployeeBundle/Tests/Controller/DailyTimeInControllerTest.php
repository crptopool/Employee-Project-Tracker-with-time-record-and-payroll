<?php

namespace EdgeWeb\Project\EmployeeBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class DailyTimeInControllerTest extends WebTestCase
{
}
