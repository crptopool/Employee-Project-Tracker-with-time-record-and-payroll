<?php

namespace EdgeWeb\Project\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UserBundle extends Bundle
{
	//we will extends FOSUserBundle here
	/*public function getParent()
	{
		return 'FOSUserBundle';
	}*/
}
