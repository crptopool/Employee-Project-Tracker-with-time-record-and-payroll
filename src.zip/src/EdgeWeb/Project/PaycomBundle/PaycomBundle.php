<?php

namespace EdgeWeb\Project\PaycomBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PaycomBundle extends Bundle
{
}
